# ARCHITECTURE.md — وثيقة المعمارية الهندسية الشاملة لتطبيق "المشغول دائمًا" (Always Busy - Life OS)

> **الإصدار المعماري:** 2.0.0 (Enterprise-Grade, Local-First, AI-Ready)  
> **المنصة:** Android Native (Kotlin 100% + Jetpack Compose + Material Design 3)  
> **الفلسفة الأساسية:** Local-First التام، حماية الخصوصية بالتشفير، وفصل طبقات الأعمال لتمكين استدعاء العمليات برمجياً بواسطة وكلاء الذكاء الاصطناعي (AI Tool Calling & Command Bus).

---

## 1. الفلسفة المعمارية ومبادئ التصميم (Core Architectural Principles)

### 1.1 معمارية محلية أولاً (Strict Local-First Architecture)
1. **العمل دون اتصال بنسبة 100% (Offline-First by Design):** لا توجد أي وظيفة أساسية (مهام، خطط، ملاحظات، ميزات مالية، ديون، أصول، تقويم، أهداف، تقارير) تتطلب اتصالاً بالإنترنت أو تعتمد على خادم خارجي.
2. **السيادة التامة على البيانات (Zero Data Leakage):** بيانات المستخدم بالكامل مخزنة محلياً في ذاكرة التطبيق الخاصة المعزولة (`/data/data/com.aistudio.alwaysbusy.zkqlmp/databases/`).
3. **لا تسجيل دخول إجباري:** لا يُطلب من المستخدم إنشاء حساب أو إدخال بريد إلكتروني لبدء استخدام النظام.
4. **تشفير التخزين (Data at Rest Encryption):** دعم تشفير قاعدة البيانات SQLite/Room عبر تقنيات SQLCipher والمفاتيح المشتقة محلياً عبر **Android Keystore System**.
5. **الإنترنت ميزة اختيارية فقط (Opt-In):** تنحصر الاتصالات الخارجية المستقبلية في:
   - النسخ الاحتياطي السحابي المشفر من الطرف إلى الطرف (E2EE Google Drive Backup) بطلب المستخدم.
   - وكيل الذكاء الاصطناعي المستقبلي (LLM API Call) بطلب ومفتاح المستخدم الصريح.
   - ولا يؤثر انقطاع الإنترنت قيد أنملة على سير عمل النظام.

### 1.2 الجاهزية للذكاء الاصطناعي (AI-Ready Architecture)
الهدف هو أن يتحول التطبيق مستقبلاً إلى منصة يمكن لوكلاء الذكاء الاصطناعي (AI Agents / LLM Function Calling / Command Bots) إدارتها دون إعادة كتابة سطر واحد من منطق الأعمال:
- **طبقة الخدمات المعزولة (Isolated Service Layer):** كل عملية في التطبيق معرّفة داخل Interface مستقل ومجرد، يقبل ويعيد بيانات منمطة (Data Transfer Objects & Entities).
- **بوابة الأوامر الداخلية والمحطة الطرفية (Command Bus & Internal Gateway):** لا يستدعي أي وكيل خارجي أو أمر نصي قاعدة البيانات مباشرة، بل يمر عبر `CommandBus` يتحقق من الصلاحيات (`ScopesEngine`) ثم ينفذ الأمر عبر الخدمة المناسبة.
- **سجل تدقيق زمني شامل (Event-Sourced Audit Trail):** كل عملية (إنشاء، تعديل، إنجاز، سداد، حذف) تسجل في جدول `audit_logs` كحدث زمني يحمل الحالة السابقة والجديدة، مما يمنح الـ AI ذاكرة تاريخية وتحليلية لفهم سلوك المستخدم وسياق قراراته.
- **مخططات بيانات منمطة (Strict JSON Schemas):** كل كيان وأمر موثق وفق معايير JSON Schema ليكون جاهزاً للحقن في System Prompts و Function Calling.

---

## 2. مخطط الطبقات المعمارية (Layer Diagram)

```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                       PRESENTATION LAYER (UI)                                          │
│  ┌──────────────────────────────────────────────────────────────────────────────────────────────────┐  │
│  │  Jetpack Compose M3 Screens (Clean White #FFFFFF / Emerald #1B5E20 / Dark Mode #111413 / RTL)    │  │
│  │  • Dashboard (Calm Metric & Today Focus)       • Tasks Hub (Daily/Weekly/Monthly/Yearly/Kanban) │  │
│  │  • Task Tree (Recursive Subtasks)              • Notes & Markdown Editor                         │  │
│  │  • Finance Dashboard (SYP & USD Dual Ledger)   • Debts & Partial Payments Ledger                 │  │
│  │  • Assets & Net Worth Tracker                  • Internal Calendar & Time-Blocking               │  │
│  │  • Goals & Progress Trackers                   • Settings & Security (Biometric Lock)           │  │
│  └──────────────────────────────────────────────────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────────────────────────────────────────────────┐  │
│  │  ViewModels & State Production (Unidirectional Data Flow - UDF via StateFlow & SharedFlow)       │  │
│  └──────────────────────────────────────────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────┬────────────────────────────────────────────────────┘
                                                    │
                 ┌──────────────────────────────────┴───────────────────────────────────┐
                 │                                                                      │
                 ▼                                                                      ▼
┌──────────────────────────────────────────────────┐   ┌────────────────────────────────────────────────┐
│      COMMAND BUS & INTERNAL GATEWAY (AI-READY)   │   │             DOMAIN LAYER (USE CASES)           │
│  ┌────────────────────────────────────────────┐  │   │  ┌──────────────────────────────────────────┐  │
│  │ Command Lexer & Text Parser                │  │   │  │ Pure Business Rules & Calculations:      │  │
│  │ (Transforms CLI text to Typed Commands)    │  │   │  │ • Net Worth Calculator (SYP/USD)         │  │
│  ├────────────────────────────────────────────┤  │   │  │ • Debt Amortization & Payoff Predictor   │  │
│  │ Security Scopes & Permissions Engine       │  │   │  │ • Task Tree Progress Aggregator          │  │
│  │ (Enforces tasks:*, finance:*, audit:*)     │  │   │  │ • Time-Blocking Conflict Resolver        │  │
│  ├────────────────────────────────────────────┤  │   │  │ • Budget Alert Engine                    │  │
│  │ Internal Gateway / Facade API              │  │   │  └──────────────────────────────────────────┘  │
│  │ (Tool Calling Endpoints for Local AI/CLI)  │  │   └────────────────────────┬───────────────────────┘
│  └─────────────────────┬──────────────────────┘                               │
│                        │                                                      │
└────────────────────────┼──────────────────────────────────────────────────────┘
                         │
                         ▼
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                       SERVICE LAYER (CONTRACTS & IMPL)                                 │
│  ┌──────────────────────────────────────────────────────────────────────────────────────────────────┐  │
│  │ Isolated Interfaces (Public API of the Core Application):                                        │  │
│  │ • ITaskService          • INoteService          • IFinanceService (SYP/USD)                     │  │
│  │ • IDebtService          • IAssetService         • IGoalService                                  │  │
│  │ • ICalendarService      • IBudgetService        • IAuditService (Event Logger)                  │  │
│  │ • IExchangeRateService  • IBackupService        • ISecurityService (Keystore & Biometrics)      │  │
│  └────────────────────────────────────────────────┬─────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────┼────────────────────────────────────────────────────┘
                                                    │
                                                    ▼
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                       DATA LAYER (LOCAL PERSISTENCE)                                   │
│  ┌──────────────────────────────────────────────────────────────────────────────────────────────────┐  │
│  │ Repositories (TaskRepository, FinanceRepository, DebtRepository, AuditRepository, etc.)          │  │
│  ├──────────────────────────────────────────────────────────────────────────────────────────────────┤  │
│  │ Room Database Engine (Encrypted with SQLCipher / Passphrase managed in Android Keystore)          │  │
│  │ • 14 Tables with foreign keys, cascading rules, and strategic indices                           │  │
│  │ • Room DAOs with Coroutine suspend functions & reactive Kotlin Flows (Flow<List<T>>)             │  │
│  │ • Type Converters (Date, Currency, RecurrenceRule, Scope, TaskPriority, EntityType)              │  │
│  └────────────────────────────────────────────────┬─────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────┼────────────────────────────────────────────────────┘
                                                    │
                                                    ▼
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                      ANDROID SYSTEM HARDWARE INTEGRATION                               │
│  • Android Keystore (Hardware-backed AES-256-GCM Key Generation)                                      │
│  • BiometricPrompt API (BiometricManager authenticators: BIOMETRIC_STRONG | DEVICE_CREDENTIAL)        │
│  • Android Calendar Provider (Optional opt-in two-way synchronization via ContentResolver)            │
│  • AlarmManager & WorkManager (Precise background alarms & recurring transaction engine)              │
└────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. مخطط تدفق البيانات (Data Flow Diagram - UDF)

```
[ User Input / Gesture / CLI Command ]
                 │
                 ▼
     [ ViewModel / Terminal ]
                 │ (Dispatches Intent / Command)
                 ▼
       [ CommandBus / Scopes ]
                 │ (Validates Scopes & Integrity)
                 ▼
          [ Service Layer ] ─────────────────────────┐
                 │                                   │ (Appends Event)
                 ▼                                   ▼
          [ Domain Rules ]                   [ AuditService ]
                 │                                   │
                 ▼                                   ▼
        [ Room Repository ] ──────────────► [ audit_logs table ]
                 │
                 ▼
    [ Encrypted SQLite Tables ]
                 │
                 ▼ (Emits Updated Flow<T>)
         [ Room DAO Flow ]
                 │
                 ▼
       [ ViewModel StateFlow ]
                 │
                 ▼
    [ Jetpack Compose Recomposition ]
                 │
                 ▼
    [ Instant Responsive UI Update ]
```

---

## 4. تصميم النواحي الحرجة (Deep Engineering Details)

### 4.1 الأمان، التشفير، وإدارة المفاتيح (Security & Keystore Architecture)
1. **Android Keystore:**
   - يتم توليد زوج مفاتيح أو مفتاح متماثل من نوع `AES/GCM/NoPadding` بحجم 256 بت داخل شريحة الأمان الصلبة للمعدات (TEE / StrongBox Keymaster).
   - المفتاح لا يغادر عتاد الهاتف أبداً ويُستخدم لتشفير مفتاح تشفير قاعدة البيانات (Database Passphrase Wrapper).
2. **SQLCipher / Room Encryption:**
   - يتم تشفير كافة صفحات قاعدة بيانات SQLite في القرص عبر خوارزمية `AES-256-CBC` بدعم مكتبة SQLCipher المدمجة مع `SupportFactory`.
3. **المصادقة البيومترية (Biometrics):**
   - حماية كاملة للتطبيق أو القفل المالي عبر واجهة `androidx.biometric.BiometricPrompt`.
   - دعم بصمة الإصبع، التعرف على الوجه، أو رمز PIN / النمط التابع لنظام أندرويد عند غياب الحساس البيومتري.
4. **حماية الكود (R8 / ProGuard):**
   - تعتيم كامل (Obfuscation) لجميع النماذج والكيانات باستثناء ما يُعفى بواسطة القواعد المحددة.
   - حظر Dynamic Code Loading وحماية أصول التشفير.

### 4.2 النظام المالي متعدد العملات (Dual Currency Architecture: SYP & USD)
- **العملة الأساسية (Primary Default):** الليرة السورية (`SYP`).
- **العملة الثانوية (Secondary):** الدولار الأمريكي (`USD`).
- **المعالجة الحسابية:**
  - كل حركة مالية (دخل، مصروف، دين، دفعة دين، أصل) تحتوي على حقلين إلزاميين: `amount` (المبلغ) و `currency` (SYP أو USD).
  - تخزين سعر الصرف اليدوي في جدول `exchange_rates` مع طابع زمني.
  - إمكانية حساب صافي القيمة (Net Worth) وعرض التقارير بإحدى طريقتين:
    1. منفصلة تماماً (SYP مستقل عن USD).
    2. مجمعة (Unified Total) حسب آخر سعر صرف أدخله المستخدم يدوياً دون استدعاء أي سيرفر خارجي.

### 4.3 جناح الإنتاجية وعروض المهام المتعددة
- **العرض اليومي (Daily):** مهام اليوم حسب الوقت، مصفوفة أيزنهاور (عاجل/مهم)، وتوزيع الفترات الزمنية (Time-Blocking).
- **العرض الأسبوعي (Weekly):** نظرة على وتيرة الأسبوع، أيام الضغط، ومهام التخطيط الأسبوعي.
- **العرض الشهري والسنوي (Monthly/Yearly):** الالتزامات الكبرى، المعالم (Milestones)، والأهداف الاستراتيجية.
- **عرض Kanban للمشاريع:** أعمدة مرنة (قيد الانتظار، قيد التنفيذ، قيد المراجعة، مكتمل) مع سحب وإفلات تفاعلي.
- **شجرة المهام الفرعية (Recursive Subtasks):** شجرة مهام غير محدودة العمق، مع خوارزمية تجميع تراكمية تحسب نسبة إنجاز المهمة الأم تلقائياً عند تغيير حالات المهام الفرعية.
- **المؤقت الزمني الداخلي (Time Tracking):** مؤقت داخلي للمهام (بدء، إيقاف مؤقت، حفظ الساعات الفعلية مقارنة بالمقدرة).

### 4.4 المحطة الطرفية وبوابة الأوامر (Internal Terminal & Gateway)
- **بنية الأوامر النصية (CLI Syntax):**
  `[entity] [action] [arguments...] [--flags]`
  - أمثلة حية:
    - `task add "إعداد العقد المالي" priority:high due:2026-10-01 project:2`
    - `debt pay 250000 currency:SYP debt_id:4 note:"دفعة نقدية"`
    - `note add "فكرة مشروع استشاري" tags:business,plan`
    - `finance add expense 50 currency:USD category:"طعام" note:"غداء عمل"`
    - `audit list limit:10`
- **نظام الصلاحيات الداخلي (Scopes System):**
  الوكيل الذكي أو المحطة الطرفية تعمل وفق صلاحيات محددة:
  - `tasks:read`, `tasks:write`, `tasks:delete`
  - `finance:read`, `finance:write`
  - `debts:read`, `debts:write`
  - `notes:read`, `notes:write`
  - `audit:read`
  إذا حاول أمر غير مصرح به التعديل، يُرفض فوراً مع تسجيل محاولة الوصول في سجل التدقيق.

---

## 5. مصفوفة الأداء والتوافقية (Non-Functional Requirements)

| المعيار | الهدف المحدد | آلية التحقق |
|---|---|---|
| **زمن الإقلاع البارد (Cold Startup)** | أقل من 800 مللي ثانية | تحسين ملفات الـ Application وكسل التهيئة (Lazy DI) |
| **سلاسة العرض (Frame Rate)** | 60 إطار في الثانية دون تقطيع (Zero Jank) | استخدام Compose Keys، `derivedStateOf`، وتجنب Recomposition غير الضروري |
| **استهلاك الذاكرة** | أقل من 90 ميغابايت أثناء تصفح آلاف السجلات | استعلامات Paging و Room Projection لعدم تحميل نصوص Markdown في القوائم |
| **أداء قاعدة البيانات** | استعلام أقل من 15 مللي ثانية مع 10,000 سجل | إضافة فهارس (Indices) على كافة المفاتيح الخارجية والتواريخ والحالات |
| **حجم التطبيق (APK Size)** | أقل من 25 ميغابايت | تفعيل ProGuard/R8 وحذف المكتبات غير المستخدمة |
| **التوافقية** | Android 7.0 (API 24) فما فوق حتى Android 15+ (API 36) | اختبارات آلية على مختلف مستويات الـ API |

---

## 6. Dynamic Template Engine — Extension Point

تم إرساء هذا المكون كنقطة تمديد معمارية استباقية (Architectural Extension Point) تسمح للنظام بالتحول من "إدارة مهام قياسية ذات حقول ثابتة" إلى "منصة نمذجة وتصميم مهام ديناميكية مرنة" (Dynamic Task Modeling Platform) دون الحاجة لإعادة كتابة كود طبقة البيانات أو ترحيل الجداول الأساسية.

### 6.1 فلسفة الفصل المعماري المزدوج (Dual Architectural Separation)
1. **مسار المهام السريعة القياسية (Fast Fixed-Field Path):**
   - للمهام اليومية الخفيفة التي لا تتطلب تعقيداً (عنوان، أولوية أيزنهاور، أفق زمني، وقت، مدة).
   - لا تتكبد أي أعباء ربط (Joins) أو معالجة ديناميكية؛ عمود `template_id` يبقى `NULL` وتبقى سرعة الاستعلام عند حدودها القصوى.
2. **مسار القوالب الديناميكية المخصصة (Dynamic Template Path):**
   - للمهام المتخصصة العميقة (مثل زراعة الأصص، صيانة المركبات الدورية، البروتوكولات الطبية).
   - يتم اشتقاق المهمة بربطها بـ `template_id`. تُحفظ قيم حقولها المخصصة في جدول `task_custom_values` المنفصل والمرتبط بـ `template_fields`.

```
                      ┌──────────────────────────────────────┐
                      │           ITaskService               │
                      └──────────────────┬───────────────────┘
                                         │
                    ┌────────────────────┴────────────────────┐
                    │                                         │
        (templateId == null)                     (templateId != null)
                    ▼                                         ▼
         ┌─────────────────────┐                   ┌─────────────────────┐
         │     tasks table     │                   │     tasks table     │
         │ (Fast Standard Path)│                   │ (template_id set)   │
         └─────────────────────┘                   └──────────┬──────────┘
                                                              │ 1:N
                                                   ┌──────────▼──────────┐
                                                   │  task_custom_values │
                                                   └──────────▲──────────┘
                                                              │ N:1
                                                   ┌──────────┴──────────┐
                                                   │   template_fields   │
                                                   └─────────────────────┘
```

### 6.2 المقارنة الهندسية: جداول منفصلة (EAV) مقابل عمود JSON في جدول tasks
تم اعتماد معمارية الجداول المنفصلة الثلاثة (`task_templates`، `template_fields`، `task_custom_values`) للأسباب الهندسية التالية:
1. **سلامة المخطط والنزاهة العلاقية (Referential Integrity):**
   - الحذف المتتالي التلقائي (`ON DELETE CASCADE`): عند حذف قالب أو حقل، تطهر قاعدة البيانات تلقائياً دون ترك حقول أيتام (Orphan Data).
   - الفهارس المخصصة والفريدة: إمكانية فهرسة القيم العددية (`value_number`) والتاريخية (`value_date`) لإجراء استعلامات الإحصاء والفرز بسرعة $O(\log N)$ بدلاً من المسح الكامل لكتل النصوص (Table Scan).
2. **عزل الأداء (Performance Isolation):**
   - جدول `tasks` يظل صغيراً ومضغوطاً وخفيف الوزن، مما يضمن تحميل مهام اليوم والداشبورد بصفحات ذاكرة صغيرة جداً (Low Cache Footprint).
3. **تطوير واجهات المستخدم المعيارية (Type-Safe UI Composition):**
   - يدعم المحرك 13 نوع حقل معياري، بحيث يعرض في Compose المكون الملائم تلقائياً (Slider لمقياس 1-10، DatePicker للتواريخ، ChoiceChips للاختيارات، OutlinedTextField مع بادئة وحدة القياس للـ Measurements).

### 6.3 محرك التوليد والاشتقاق التلقائي (Task Chaining & Progression Rule Engine)
يدعم حقل `auto_next_task_rule` في جدول `task_templates` تخزين كائن قواعد الاشتقاق مثل:
```json
{
  "chainEnabled": true,
  "triggerOnStatus": "COMPLETED",
  "offsetFieldKey": "current_pot_size",
  "nextTargetFieldKey": "target_pot_size",
  "incrementStep": 2.0,
  "unit": "سم",
  "nextDueDelayDays": 30,
  "titleTemplate": "نقل الورد من {current_pot_size}{unit} إلى {target_pot_size}{unit}"
}
```
عند إنجاز المهمة الحالية، يقوم `ITaskService` بقراءة قاعدة القالب، ثم يولد المهمة اللاحقة تلقائياً بتاريخ استحقاق جديد وقيم مستهدفة متزايدة، مما يلغي عناء إعادة الإدخال بالكامل.
