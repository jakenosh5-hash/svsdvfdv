# SCHEMA.md — مخطط وتوصيف قاعدة البيانات الشامل لتطبيق "المشغول دائمًا" (Always Busy - Life OS)

> **محرك قاعدة البيانات:** SQLite عبر Android Room Database  
> **التشفير:** مشفرة بالكامل بواسطة SQLCipher (AES-256) ومحمية بـ Android Keystore  
> **العملات المدعومة:** `SYP` (الليرة السورية - افتراضية وأساسية)، `USD` (الدولار الأمريكي - ثانوية)

---

## 1. مخطط علاقات الكيانات (Entity-Relationship Diagram)

```
       ┌───────────────┐
       │   projects    │◄─────────────────────────────┐
       └───────┬───────┘                              │
               │ 1                                    │
               │ N                                    │
       ┌───────▼───────┐                     ┌────────┴────────┐
 ┌────►│     tasks     │◄───────────────────┤      notes      │
 │     └───────┬───────┘                     └────────┬────────┘
 │ parent      │ 1                                    │
 └─────────────┤                                      │
               │ N                                    │
       ┌───────▼───────┐                              │
       │ time_entries  │                              │
       └───────────────┘                              │
                                                      │
       ┌───────────────┐                              │
       │  categories   │◄───────────────┐             │
       └───────┬───────┘                │             │
               │ 1                      │             │
               │ N                      │             │
       ┌───────▼──────────────┐         │             │
       │ finance_transactions │         │             │
       └──────────────────────┘         │             │
                                        │             │
       ┌───────────────┐                │             │
       │     debts     │◄───────────────┼─────────────┘
       └───────┬───────┘                │
               │ 1                      │
               │ N                      │
       ┌───────▼───────┐                │
       │ debt_payments │                │
       └───────────────┘                │
                                        │
       ┌───────────────┐                │
       │    assets     │                │
       └───────────────┘                │
                                        │
       ┌───────────────┐                │
       │    budgets    │────────────────┘
       └───────────────┘

       ┌───────────────┐
       │     goals     │◄──────────────┐
       └───────┬───────┘               │
               │ 1                     │
               │ N                     │
       ┌───────▼───────┐               │
       │goal_milestones│               │
       └───────────────┘               │
                                       │
       ┌────────────────┐              │
       │ exchange_rates │              │
       └────────────────┘              │
                                       │
       ┌────────────────┐              │
       │   audit_logs   │──────────────┴─── (Event Log for all entities)
       └────────────────┘

       ┌────────────────┐
       │security_scopes │
       └────────────────┘
```

---

## 2. توصيف الجداول والحقول (Table & Field Specifications)

### 2.1 جدول المشاريع (`projects`)
يجمع المهام والملاحظات في سياق تنفيذي موحد.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للمشروع |
| `name` | `TEXT` | `NOT NULL` | اسم المشروع |
| `description` | `TEXT` | `NULLABLE` | وصف المشروع وتفاصيله |
| `color_hex` | `TEXT` | `NOT NULL DEFAULT '#2E7D32'` | رمز اللون المميز في الواجهة |
| `icon_name` | `TEXT` | `NOT NULL DEFAULT 'folder'` | اسم الأيقونة المعروضة |
| `status` | `TEXT` | `NOT NULL DEFAULT 'ACTIVE'` | الحالة (`ACTIVE`, `COMPLETED`, `ARCHIVED`, `ON_HOLD`) |
| `target_end_date` | `INTEGER` | `NULLABLE` | تاريخ الانتهاء المستهدف (Timestamp ms) |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ الإنشاء (Timestamp ms) |
| `updated_at` | `INTEGER` | `NOT NULL` | تاريخ آخر تحديث (Timestamp ms) |

- **الفهارس (Indices):**
  - `idx_projects_status` على `status`
  - `idx_projects_updated_at` على `updated_at`

---

### 2.2 جدول المهام (`tasks`)
يدعم المهام بجميع آفاقها الزمنية، والمهام الفرعية التداخلية غير المحدودة.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للمهمة |
| `parent_task_id` | `INTEGER` | `NULLABLE, FK -> tasks(id) ON DELETE CASCADE` | معرف المهمة الأم (لتفريع شجرة المهام بلا حدود) |
| `project_id` | `INTEGER` | `NULLABLE, FK -> projects(id) ON DELETE SET NULL` | المشروع التابعة له |
| `template_id` | `INTEGER` | `NULLABLE, FK -> task_templates(id) ON DELETE SET NULL` | معرف القالب الديناميكي المشتقة منه (فارغ للمهام القياسية) |
| `title` | `TEXT` | `NOT NULL` | عنوان المهمة |
| `description` | `TEXT` | `NULLABLE` | تفاصيل إضافية / نص توضيحي |
| `time_horizon` | `TEXT` | `NOT NULL DEFAULT 'DAILY'` | الأفق الزمني (`DAILY`, `WEEKLY`, `MONTHLY`, `YEARLY`) |
| `priority` | `TEXT` | `NOT NULL DEFAULT 'MEDIUM'` | الأولوية (`URGENT_IMPORTANT`, `IMPORTANT_NOT_URGENT`, `URGENT_NOT_IMPORTANT`, `NEITHER`) |
| `status` | `TEXT` | `NOT NULL DEFAULT 'PENDING'` | الحالة (`PENDING`, `IN_PROGRESS`, `COMPLETED`, `POSTPONED`, `CANCELLED`) |
| `due_date` | `INTEGER` | `NULLABLE` | تاريخ الاستحقاق (Timestamp ms) |
| `due_time_minutes`| `INTEGER` | `NULLABLE` | وقت الاستحقاق بالدقائق من بداية اليوم (0-1439) لجدولة التقويم |
| `duration_minutes`| `INTEGER` | `NULLABLE` | المدة التقديرية بالدقائق للـ Time-blocking |
| `is_recurring` | `INTEGER` | `NOT NULL DEFAULT 0` | هل هي متكررة (0 أو 1) |
| `recurrence_rule`| `TEXT` | `NULLABLE` | نمط التكرار (`DAILY`, `WEEKLY:MON,THU`, `MONTHLY:15`, `YEARLY:10-01`, `CUSTOM`) |
| `tags` | `TEXT` | `NULLABLE` | وسوم وسياقات مفصولة بفاصلة (`@عمل,@منزل`) |
| `sync_to_calendar`| `INTEGER`| `NOT NULL DEFAULT 0` | هل يُسمح بمزامنتها مع تقويم أندرويد الخارجي |
| `calendar_event_id`| `INTEGER`| `NULLABLE` | معرف الحدث في تقويم النظام عند المزامنة |
| `completed_at` | `INTEGER` | `NULLABLE` | تاريخ الإنجاز الفعلي (Timestamp ms) |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ الإنشاء (Timestamp ms) |
| `updated_at` | `INTEGER` | `NOT NULL` | تاريخ آخر تحديث (Timestamp ms) |

- **الفهارس (Indices):**
  - `idx_tasks_parent_id` على `parent_task_id`
  - `idx_tasks_project_id` على `project_id`
  - `idx_tasks_template_id` على `template_id`
  - `idx_tasks_status_due` على `(status, due_date)`
  - `idx_tasks_time_horizon` على `time_horizon`

---

### 2.3 جدول تتبع الوقت الفعلي (`time_entries`)
تسجيل وقت العمل الفعلي لكل مهمة مقارنة بالوقت المقدر.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد لجلسة العمل |
| `task_id` | `INTEGER` | `NOT NULL, FK -> tasks(id) ON DELETE CASCADE` | المهمة المرتبطة |
| `start_time` | `INTEGER` | `NOT NULL` | بداية الجلسة (Timestamp ms) |
| `end_time` | `INTEGER` | `NULLABLE` | نهاية الجلسة (Timestamp ms) - Null أثناء العمل |
| `duration_seconds`| `INTEGER`| `NOT NULL DEFAULT 0` | المدة المنقضية بالثواني |
| `notes` | `TEXT` | `NULLABLE` | ملاحظة سريعة عما أُنجز |

- **الفهارس (Indices):**
  - `idx_time_entries_task_id` على `task_id`
  - `idx_time_entries_start_time` على `start_time`

---

### 2.4 جدول الملاحظات (`notes`)
يدعم Markdown والربط الذكي بالمهام والمشاريع والديون.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للملاحظة |
| `title` | `TEXT` | `NOT NULL` | عنوان الملاحظة |
| `content_markdown`| `TEXT` | `NOT NULL` | نص الملاحظة بتنسيق Markdown |
| `project_id` | `INTEGER` | `NULLABLE, FK -> projects(id) ON DELETE SET NULL` | مشروع مرتبط |
| `task_id` | `INTEGER` | `NULLABLE, FK -> tasks(id) ON DELETE SET NULL` | مهمة مرتبطة |
| `debt_id` | `INTEGER` | `NULLABLE, FK -> debts(id) ON DELETE SET NULL` | دين مرتبط |
| `is_pinned` | `INTEGER` | `NOT NULL DEFAULT 0` | مثبتة في الأعلى (0 أو 1) |
| `is_archived` | `INTEGER` | `NOT NULL DEFAULT 0` | مؤرشفة (0 أو 1) |
| `tags` | `TEXT` | `NULLABLE` | وسوم مفصولة بفاصلة |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ الإنشاء |
| `updated_at` | `INTEGER` | `NOT NULL` | تاريخ التحديث |

- **الفهارس (Indices):**
  - `idx_notes_pinned_updated` على `(is_pinned, updated_at)`
  - `idx_notes_task_project` على `(task_id, project_id)`

---

### 2.5 جدول التصنيفات المالية (`categories`)

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للتصنيف |
| `name` | `TEXT` | `NOT NULL UNIQUE` | اسم التصنيف (سكن، طعام، عمل...) |
| `type` | `TEXT` | `NOT NULL` | النوع (`INCOME`, `EXPENSE`, `BOTH`) |
| `icon_name` | `TEXT` | `NOT NULL DEFAULT 'tag'` | أيقونة التصنيف |
| `color_hex` | `TEXT` | `NOT NULL DEFAULT '#4CAF50'` | لون التصنيف |
| `is_default` | `INTEGER` | `NOT NULL DEFAULT 0` | تصنيف افتراضي في النظام |

---

### 2.6 جدول المعاملات المالية (`finance_transactions`)
يدعم العملتين `SYP` و `USD` من اليوم الأول.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للمعاملة |
| `type` | `TEXT` | `NOT NULL` | النوع (`INCOME`, `EXPENSE`, `TRANSFER`) |
| `amount` | `REAL` | `NOT NULL` | المبلغ المدفوع أو المقبوض |
| `currency` | `TEXT` | `NOT NULL DEFAULT 'SYP'` | العملة (`SYP` أو `USD`) |
| `category_id` | `INTEGER` | `NOT NULL, FK -> categories(id) ON DELETE RESTRICT` | تصنيف الحركة |
| `project_id` | `INTEGER` | `NULLABLE, FK -> projects(id) ON DELETE SET NULL` | مشروع مرتبط |
| `transaction_date`| `INTEGER`| `NOT NULL` | تاريخ ووقت الحركة (Timestamp ms) |
| `note` | `TEXT` | `NULLABLE` | ملاحظة / تفاصيل |
| `is_recurring` | `INTEGER` | `NOT NULL DEFAULT 0` | هل هي معاملة متكررة دورية |
| `recurrence_rule`| `TEXT` | `NULLABLE` | قاعدة التكرار (شهري، أسبوعي...) |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ التدوين |

- **الفهارس (Indices):**
  - `idx_finance_date_type` على `(transaction_date, type)`
  - `idx_finance_currency` على `currency`
  - `idx_finance_category` على `category_id`

---

### 2.7 جدول الديون والالتزامات (`debts`)
حصر دقيق لكل ما للمستخدم وما عليه، مع دعم `SYP` و `USD`.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للدين |
| `type` | `TEXT` | `NOT NULL` | النوع (`I_OWE` عليّ دين، `OWED_TO_ME` لي دين) |
| `person_name` | `TEXT` | `NOT NULL` | اسم الطرف الآخر (الدائن أو المدين) |
| `phone_number` | `TEXT` | `NULLABLE` | رقم الهاتف للاتصال السريع |
| `original_amount` | `REAL` | `NOT NULL` | أصل مبلغ الدين |
| `remaining_amount`| `REAL` | `NOT NULL` | المبلغ المتبقي بعد السداد الجزئي |
| `currency` | `TEXT` | `NOT NULL DEFAULT 'SYP'` | عملة الدين (`SYP` أو `USD`) |
| `due_date` | `INTEGER` | `NULLABLE` | تاريخ الاستحقاق المتفق عليه |
| `status` | `TEXT` | `NOT NULL DEFAULT 'ACTIVE'` | الحالة (`ACTIVE`, `PAID`, `DEFAULTED`, `CANCELLED`) |
| `interest_rate_percent`| `REAL` | `NOT NULL DEFAULT 0.0` | نسبة الفائدة إن وُجدت |
| `note` | `TEXT` | `NULLABLE` | شروط أو مبرر الدين |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ تسجيل الدين |
| `updated_at` | `INTEGER` | `NOT NULL` | تاريخ آخر تحديث |

- **الفهارس (Indices):**
  - `idx_debts_status_due` على `(status, due_date)`
  - `idx_debts_type_currency` على `(type, currency)`

---

### 2.8 جدول دفعات الديون الجزئية (`debt_payments`)

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للدفعة |
| `debt_id` | `INTEGER` | `NOT NULL, FK -> debts(id) ON DELETE CASCADE` | الدين المستهدف |
| `amount` | `REAL` | `NOT NULL` | المبلغ المسدد في هذه الدفعة |
| `currency` | `TEXT` | `NOT NULL DEFAULT 'SYP'` | عملة الدفعة |
| `payment_date`| `INTEGER` | `NOT NULL` | تاريخ السداد الفعلي |
| `receipt_note` | `TEXT` | `NULLABLE` | رقم إيصال، طريقة الدفع، أو ملاحظة |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ تسجيل الدفعة |

- **الفهارس (Indices):**
  - `idx_debt_payments_debt_id` على `debt_id`
  - `idx_debt_payments_date` على `payment_date`

---

### 2.9 جدول الأصول والممتلكات (`assets`)

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للأصل |
| `name` | `TEXT` | `NOT NULL` | اسم الأصل (نقد، حساب بنكي، عقار، ذهب، أسهم...) |
| `category` | `TEXT` | `NOT NULL` | نوع الأصل (`CASH`, `BANK`, `GOLD`, `REAL_ESTATE`, `STOCKS`, `OTHER`) |
| `current_value` | `REAL` | `NOT NULL` | القيمة التقديرية الحالية |
| `purchase_cost` | `REAL` | `NULLABLE` | تكلفة الشراء الأصلية |
| `currency` | `TEXT` | `NOT NULL DEFAULT 'SYP'` | العملة (`SYP` أو `USD`) |
| `last_valued_at`| `INTEGER` | `NOT NULL` | تاريخ آخر تقييم للقيمة |
| `note` | `TEXT` | `NULLABLE` | ملاحظات وموقع الأصل |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ التدوين |

---

### 2.10 جدول الميزانيات الشهرية (`budgets`)

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للميزانية |
| `category_id` | `INTEGER` | `NOT NULL, FK -> categories(id) ON DELETE CASCADE` | التصنيف المستهدف |
| `monthly_limit` | `REAL` | `NOT NULL` | الحد الأقصى الشهري للإنفاق |
| `currency` | `TEXT` | `NOT NULL DEFAULT 'SYP'` | العملة (`SYP` أو `USD`) |
| `year_month` | `TEXT` | `NOT NULL` | الشهر بصيغة `YYYY-MM` |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ الإنشاء |

- **الفهارس (Indices):**
  - `idx_budgets_category_month` على `(category_id, year_month)` - `UNIQUE`

---

### 2.11 جدول الأهداف (`goals`)

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للهدف |
| `title` | `TEXT` | `NOT NULL` | اسم الهدف |
| `description` | `TEXT` | `NULLABLE` | تفاصيل ومبررات الهدف |
| `horizon` | `TEXT` | `NOT NULL DEFAULT 'MEDIUM'` | المدى (`SHORT_TERM`, `MEDIUM_TERM`, `LONG_TERM`) |
| `metric_type` | `TEXT` | `NOT NULL DEFAULT 'PERCENTAGE'` | نوع القياس (`PERCENTAGE`, `NUMERIC`, `TASK_BASED`) |
| `target_value`| `REAL` | `NOT NULL DEFAULT 100.0` | القيمة المستهدفة |
| `current_value`| `REAL` | `NOT NULL DEFAULT 0.0` | القيمة الحالية المحققة |
| `target_date` | `INTEGER` | `NULLABLE` | الموعد النهائي لتحقيق الهدف |
| `status` | `TEXT` | `NOT NULL DEFAULT 'IN_PROGRESS'` | الحالة (`IN_PROGRESS`, `ACHIEVED`, `POSTPONED`, `ABANDONED`) |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ الإنشاء |
| `updated_at` | `INTEGER` | `NOT NULL` | تاريخ التحديث |

---

### 2.12 جدول أسعار الصرف اليدوية (`exchange_rates`)
يخزن إدخال المستخدم اليدوي لأسعار الصرف (Local-First).

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد لسجل الصرف |
| `base_currency` | `TEXT` | `NOT NULL DEFAULT 'USD'` | عملة الأساس |
| `target_currency`| `TEXT` | `NOT NULL DEFAULT 'SYP'` | عملة الهدف |
| `rate` | `REAL` | `NOT NULL` | سعر صرف 1 دولار بالليرة السورية (مثلاً: 14500) |
| `recorded_at` | `INTEGER` | `NOT NULL` | وقت تدوين السعر (Timestamp ms) |
| `note` | `TEXT` | `NULLABLE` | ملاحظة عن مصدر السعر المحلي |

---

### 2.13 جدول سجل التدقيق والأحداث (`audit_logs`)
عصب معمارية الـ AI-Ready؛ يسجل تاريخ وسياق كل عملية.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للحدث |
| `entity_type` | `TEXT` | `NOT NULL` | نوع الكيان (`TASK`, `DEBT`, `PAYMENT`, `NOTE`, `FINANCE`, `GOAL`, `ASSET`) |
| `entity_id` | `INTEGER` | `NOT NULL` | معرف السجل المتأثر |
| `action` | `TEXT` | `NOT NULL` | العملية (`CREATE`, `UPDATE`, `COMPLETE`, `PAY`, `DELETE`) |
| `actor` | `TEXT` | `NOT NULL DEFAULT 'USER'` | المنفذ (`USER`, `COMMAND_TERMINAL`, `AUTOMATION`, `AI_AGENT`) |
| `payload_before_json`| `TEXT` | `NULLABLE` | لقطة من بيانات السجل قبل العملية بتنسيق JSON |
| `payload_after_json` | `TEXT` | `NULLABLE` | لقطة من بيانات السجل بعد العملية بتنسيق JSON |
| `timestamp` | `INTEGER` | `NOT NULL` | الطابع الزمني الدقيق للحدث (ms) |

- **الفهارس (Indices):**
  - `idx_audit_entity` على `(entity_type, entity_id)`
  - `idx_audit_timestamp` على `timestamp`

---

### 2.14 جدول الصلاحيات والنطاقات الأمنية (`security_scopes`)
يحدد صلاحيات أي وصول برمجي أو عبر المحطة الطرفية لحماية خصوصية المستخدم.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للصلاحية |
| `scope_name` | `TEXT` | `NOT NULL UNIQUE` | اسم النطاق (`tasks:read`, `tasks:write`, `finance:read`, `debts:pay`...) |
| `description` | `TEXT` | `NOT NULL` | وصف الصلاحية للمستخدم |
| `is_granted` | `INTEGER` | `NOT NULL DEFAULT 1` | هل الصلاحية ممنوحة حالياً (0 أو 1) |
| `granted_at` | `INTEGER` | `NOT NULL` | تاريخ المنح |

---

## 3. Future Extension: Task Templates & Custom Fields

تم تصميم هذه الجداول المنفصلة كنقاط تمديد معمارية استباقية (Architectural Extension Points) لإتاحة إنشاء مهام مخصصة ديناميكية بالكامل (مثل "العناية بالورد"، "صيانة السيارات"، "المتابعات الصحية الدورية")، دون الحاجة مستقبلاً لتعديل جداول المهام الأساسية أو إعادة كتابة أي كود في طبقة قاعدة البيانات.

### 3.1 مخطط علاقات القوالب الديناميكية

```
 ┌─────────────────────┐
 │   task_templates    │ (تعريف القالب وسلوك التوليد الذاتي)
 └──────────┬──────────┘
            │ 1
            │ N
 ┌──────────▼──────────┐                 ┌─────────────────────┐
 │   template_fields   │                 │        tasks        │
 └──────────┬──────────┘                 └──────────┬──────────┘
            │ 1                                     │ 1
            │ N                                     │ N
            └────────────────►┌─────────────────────▼◄──────┘
                              │  task_custom_values │
                              └─────────────────────┘
```

---

### 3.2 جدول قوالب المهام (`task_templates`)
يحفظ بيانات القالب الوصفية وقواعد اشتقاق المهمة التالية (Task Chaining).

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للقالب |
| `name` | `TEXT` | `NOT NULL UNIQUE` | اسم القالب (مثل: "العناية بالورد"، "صيانة السيارة") |
| `description` | `TEXT` | `NULLABLE` | شرح استخدام القالب |
| `icon_name` | `TEXT` | `NOT NULL DEFAULT 'spa'` | أيقونة القالب في الواجهة |
| `color_hex` | `TEXT` | `NOT NULL DEFAULT '#2E7D32'` | لون القالب المميز |
| `auto_next_task_rule` | `TEXT` | `NULLABLE` | قاعدة التوليد التلقائي بصيغة JSON (مثلاً زيادة القطر 2سم وتنبيه بعد 30 يوماً) |
| `created_at` | `INTEGER` | `NOT NULL` | تاريخ الإنشاء (Timestamp ms) |
| `updated_at` | `INTEGER` | `NOT NULL` | تاريخ التحديث (Timestamp ms) |

- **الفهارس (Indices):**
  - `idx_task_templates_name` على `name` (فريد)

---

### 3.3 جدول تعريف حقول القالب (`template_fields`)
يحدد أنواع الحقول المخصصة التابعة لكل قالب وترتيب ظهورها وقيودها.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد لتعريف الحقل |
| `template_id` | `INTEGER` | `NOT NULL, FK -> task_templates(id) ON DELETE CASCADE` | القالب التابع له الحقل |
| `field_name` | `TEXT` | `NOT NULL` | اسم الحقل المعروض للمستخدم (مثل: "حجم الأصيص الحالي") |
| `field_key` | `TEXT` | `NOT NULL` | مفتاح الحقل البرمجي الفريد داخل القالب (مثل: `current_pot_size`) |
| `field_type` | `TEXT` | `NOT NULL` | نوع الحقل المعتمد من الأنواع الـ 13 المدعومة |
| `unit` | `TEXT` | `NULLABLE` | وحدة القياس (مثل: "سم"، "كغ"، "لتر"، "كم") |
| `min_value` | `REAL` | `NULLABLE` | الحد الأدنى للقيم العددية أو السلايدر |
| `max_value` | `REAL` | `NULLABLE` | الحد الأقصى للقيم العددية أو السلايدر |
| `step_value` | `REAL` | `NULLABLE` | خطوة الزيادة للسلايدر والمقاييس |
| `options_json` | `TEXT` | `NULLABLE` | مصفوفة خيارات JSON للقوائم والاختيارات المتعددة |
| `is_required` | `INTEGER` | `NOT NULL DEFAULT 0` | هل الحقل إلزامي (0 أو 1) |
| `display_order` | `INTEGER` | `NOT NULL DEFAULT 0` | ترتيب العرض في الواجهة |

- **الفهارس (Indices):**
  - `idx_template_fields_template_id` على `template_id`
  - `idx_template_fields_key_unique` على `(template_id, field_key)` (فريد)

---

### 3.4 جدول قيم الحقول المخصصة لكل مهمة (`task_custom_values`)
يخزن القيم الفعلية التي أدخلها المستخدم لكل حقل مخصص عند إنشاء المهمة من القالب.

| اسم الحقل | النوع في SQLite | القيود (Constraints) | الوصف |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | المعرف الفريد للقيمة المسجلة |
| `task_id` | `INTEGER` | `NOT NULL, FK -> tasks(id) ON DELETE CASCADE` | المهمة المرتبطة |
| `field_id` | `INTEGER` | `NOT NULL, FK -> template_fields(id) ON DELETE CASCADE` | الحقل المخصص المرتبط |
| `value_text` | `TEXT` | `NULLABLE` | القيمة النصية أو خيار القائمة |
| `value_number` | `REAL` | `NULLABLE` | القيمة العددية المفهرسة للحسابات والمقاييس والقياسات |
| `value_date` | `INTEGER` | `NULLABLE` | القيمة التاريخية (Timestamp ms) |
| `raw_json_value` | `TEXT` | `NULLABLE` | مصفوفة خيارات متعددة بصيغة JSON أو مسارات وسائط |

- **الفهارس (Indices):**
  - `idx_custom_values_task_id` على `task_id`
  - `idx_custom_values_field_id` على `field_id`
  - `idx_custom_values_unique_task_field` على `(task_id, field_id)` (فريد لمنع التكرار)

---

### 3.5 الأنواع الـ 13 المدعومة في المحرك الديناميكي (`field_type`)

1. **`TEXT`**: نص قصير أحادي السطر (مثل اسم النبتة، رقم الورشة).
2. **`LONG_TEXT`**: نص طويل متعدد الأسطر (الملاحظات، التقرير الزراعي).
3. **`NUMBER`**: أرقام صحيحة أو كسرية للحسابات (الكيلومترات، قراءات الأجهزة).
4. **`MEASUREMENT`**: رقم مقترن بوحدة قياس معرّفة (`unit`: سم، كغ، لتر).
5. **`SLIDER`**: شريط تمرير بنطاق أدنى وأعلى وخطوة محددة.
6. **`SCALE_1_10`**: مقياس تقييم حدي من 1 إلى 10 (مثل صحة النبتة، شدة الألم).
7. **`SINGLE_CHOICE`**: اختيار واحد من عدة خيارات محددة في `options_json`.
8. **`MULTI_CHOICE`**: اختيار متعدد من مصفوفة خيارات (أنواع الأسمدة، الأدوية).
9. **`DATE`**: تاريخ محدد باليوم والشهر والسنة.
10. **`TIME`**: وقت بالدقائق أو الساعات.
11. **`BOOLEAN`**: قيمة منطقية (نعم/لا، صواب/خطأ).
12. **`IMAGE`**: مسار الصورة المحلية المحفوظة على الجهاز.
13. **`DROPDOWN`**: قائمة منسدلة لاختيار عنصر واحد من خيارات واسعة.
