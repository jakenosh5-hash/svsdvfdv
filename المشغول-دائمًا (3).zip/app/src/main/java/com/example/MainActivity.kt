package com.example

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.presentation.ai.AiHubScreen
import com.example.presentation.ai.AiHubViewModel
import com.example.presentation.calendar.CalendarGoalsScreen
import com.example.presentation.dashboard.DashboardScreen
import com.example.presentation.dashboard.DashboardViewModel
import com.example.presentation.finance.FinanceScreen
import com.example.presentation.navigation.Screen
import com.example.presentation.productivity.ProductivityScreen
import com.example.presentation.security.BiometricLockScreen
import com.example.presentation.settings.SettingsScreen
import com.example.ui.theme.AlwaysBusyTheme

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appContainer = (application as AlwaysBusyApp).container

        val deepLinkData = intent?.data

        setContent {
            AlwaysBusyTheme {
                val viewModel: DashboardViewModel = viewModel(
                    factory = DashboardViewModel.provideFactory(appContainer)
                )
                val uiState by viewModel.uiState.collectAsState()

                if (uiState.isSessionLocked) {
                    BiometricLockScreen(
                        onUnlockSuccess = {
                            viewModel.setBiometricLockEnabled(false)
                            viewModel.unlockSession()
                        }
                    )
                } else {
                    AlwaysBusyMainApp(viewModel = viewModel, deepLinkUri = deepLinkData)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val appContainer = (application as AlwaysBusyApp).container
        appContainer.securityPreferences.checkInactivityLock()
    }

    override fun onPause() {
        super.onPause()
        val appContainer = (application as AlwaysBusyApp).container
        appContainer.securityPreferences.updateLastActiveTime()
    }
}

@Composable
fun AlwaysBusyMainApp(
    viewModel: DashboardViewModel,
    deepLinkUri: android.net.Uri? = null
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    LaunchedEffect(deepLinkUri) {
        deepLinkUri?.let { uri ->
            val host = uri.host?.lowercase() ?: uri.path?.removePrefix("/")?.lowercase()
            val targetRoute = when {
                host?.contains("prod") == true || host?.contains("task") == true -> Screen.Productivity.route
                host?.contains("fin") == true -> Screen.Finance.route
                host?.contains("cal") == true || host?.contains("goal") == true -> Screen.CalendarGoals.route
                host?.contains("ai") == true || host?.contains("term") == true -> Screen.AiHub.route
                host?.contains("set") == true -> Screen.Settings.route
                else -> null
            }
            targetRoute?.let { navController.navigate(it) }
        }
    }

    val navigationItems = listOf(
        Screen.Dashboard,
        Screen.Productivity,
        Screen.Finance,
        Screen.CalendarGoals,
        Screen.AiHub,
        Screen.Settings
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = NavigationBarDefaults.Elevation
            ) {
                navigationItems.forEach { screen ->
                    val isSelected = currentRoute == screen.route
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.titleArabic) },
                        label = { Text(screen.titleArabic) },
                        selected = isSelected,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToProductivity = { navController.navigate(Screen.Productivity.route) },
                    onNavigateToFinance = { navController.navigate(Screen.Finance.route) },
                    onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                )
            }
            composable(Screen.Productivity.route) {
                ProductivityScreen(viewModel = viewModel)
            }
            composable(Screen.Finance.route) {
                FinanceScreen(viewModel = viewModel)
            }
            composable(Screen.CalendarGoals.route) {
                CalendarGoalsScreen(viewModel = viewModel)
            }
            composable(Screen.AiHub.route) {
                val context = androidx.compose.ui.platform.LocalContext.current
                val appContainer = (context.applicationContext as AlwaysBusyApp).container
                val aiViewModel: AiHubViewModel = viewModel(
                    factory = AiHubViewModel.provideFactory(appContainer)
                )
                AiHubScreen(
                    viewModel = aiViewModel,
                    onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
