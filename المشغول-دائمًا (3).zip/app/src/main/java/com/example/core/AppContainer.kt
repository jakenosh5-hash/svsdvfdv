package com.example.core

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.security.SecurityPreferences
import com.example.services.*

/**
 * Dependency container providing single-source instantiation for all services,
 * Room database DAOs, and hardware-security controllers.
 */
class AppContainer(private val context: Context) {

    val securityPreferences: SecurityPreferences by lazy {
        SecurityPreferences(context)
    }

    val database: AppDatabase by lazy {
        AppDatabase.getInstance(context)
    }

    val auditService: IAuditService by lazy {
        AuditServiceImpl(database.auditLogDao())
    }

    val securityScopeService: ISecurityScopeService by lazy {
        SecurityScopeServiceImpl(database.securityScopeDao())
    }

    val taskService: ITaskService by lazy {
        TaskServiceImpl(
            taskDao = database.taskDao(),
            projectDao = database.projectDao(),
            templateDao = database.templateDao(),
            auditService = auditService,
            context = context
        )
    }

    val noteService: INoteService by lazy {
        NoteServiceImpl(
            noteDao = database.noteDao(),
            auditService = auditService
        )
    }

    val financeService: IFinanceService by lazy {
        FinanceServiceImpl(
            financeDao = database.financeDao(),
            auditService = auditService
        )
    }

    val debtService: IDebtService by lazy {
        DebtServiceImpl(
            debtDao = database.debtDao(),
            auditService = auditService
        )
    }

    val timeTrackingService: ITimeTrackingService by lazy {
        TimeTrackingServiceImpl(
            timeEntryDao = database.timeEntryDao(),
            auditService = auditService
        )
    }

    val goalService: IGoalService by lazy {
        GoalServiceImpl(
            goalDao = database.goalDao(),
            auditService = auditService
        )
    }

    val deviceCalendarService: IDeviceCalendarService by lazy {
        DeviceCalendarServiceImpl(context)
    }

    val reminderScheduler: TaskReminderScheduler by lazy {
        TaskReminderScheduler(context)
    }

    val internalGateway: com.example.domain.gateway.AppInternalGateway by lazy {
        com.example.domain.gateway.AppInternalGateway(
            database = database,
            taskService = taskService,
            financeService = financeService,
            debtService = debtService,
            noteService = noteService,
            auditService = auditService,
            securityScopeService = securityScopeService
        )
    }

    val commandBus: com.example.domain.command.CommandBus by lazy {
        com.example.domain.command.CommandBus(
            gateway = internalGateway,
            securityScopeService = securityScopeService,
            auditService = auditService
        )
    }

    val toolCallDispatcher: com.example.domain.gateway.AiToolCallDispatcher by lazy {
        com.example.domain.gateway.AiToolCallDispatcher(commandBus)
    }

    val memoryEngine: com.example.domain.memory.CumulativeMemoryEngine by lazy {
        com.example.domain.memory.CumulativeMemoryEngine(
            aiDao = database.aiDao(),
            gateway = internalGateway
        )
    }

    val backupEngine: com.example.domain.backup.BackupAndExportEngine by lazy {
        com.example.domain.backup.BackupAndExportEngine(database)
    }

    val aiPreferences: com.example.security.AiPreferences by lazy {
        com.example.security.AiPreferences(context)
    }

    val personaProfileStore: com.example.security.PersonaProfileStore by lazy {
        com.example.security.PersonaProfileStore(context)
    }

    val knowledgeService: com.example.domain.knowledge.AutonomousKnowledgeService by lazy {
        com.example.domain.knowledge.AutonomousKnowledgeService(database.knowledgeDao())
    }

    val llmClient: com.example.network.LlmApiClient by lazy {
        com.example.network.LlmApiClient(aiPreferences, personaProfileStore)
    }

    val autonomousAgentCoordinator: com.example.domain.agent.AutonomousAgentCoordinator by lazy {
        com.example.domain.agent.AutonomousAgentCoordinator(
            aiDao = database.aiDao(),
            knowledgeService = knowledgeService,
            commandBus = commandBus,
            toolCallDispatcher = toolCallDispatcher,
            auditService = auditService,
            aiPreferences = aiPreferences,
            llmClient = llmClient,
            memoryEngine = memoryEngine
        )
    }

    val aiAutomationService: IAiAutomationService by lazy {
        AiAutomationServiceImpl(
            database = database,
            gateway = internalGateway,
            commandBus = commandBus,
            toolCallDispatcher = toolCallDispatcher,
            memoryEngine = memoryEngine,
            backupEngine = backupEngine
        )
    }
}
