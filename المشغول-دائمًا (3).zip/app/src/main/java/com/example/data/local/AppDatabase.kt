package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.converters.AppTypeConverters
import com.example.data.local.dao.*
import com.example.data.local.entities.*
import com.example.domain.models.TransactionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProjectEntity::class,
        TaskEntity::class,
        TimeEntryEntity::class,
        NoteEntity::class,
        CategoryEntity::class,
        FinanceTransactionEntity::class,
        BudgetEntity::class,
        AssetEntity::class,
        ExchangeRateEntity::class,
        DebtEntity::class,
        DebtPaymentEntity::class,
        GoalEntity::class,
        GoalMilestoneEntity::class,
        AuditLogEntity::class,
        SecurityScopeEntity::class,
        TaskTemplateEntity::class,
        TemplateFieldEntity::class,
        TaskCustomValueEntity::class,
        AiConversationEntity::class,
        AiMessageEntity::class,
        AiMemoryItemEntity::class,
        KnowledgeIndexEntity::class,
        KnowledgeSectionEntity::class,
        KnowledgeMemoryEntity::class,
        AgentJobEntity::class,
        ScheduledAgentTaskEntity::class,
        NotificationPlanEntity::class,
        ToolCallRecordEntity::class,
        PersonaProfileEntity::class,
        PersonaKeySlotEntity::class
    ],
    version = 5,
    exportSchema = false
)
@TypeConverters(AppTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun taskDao(): TaskDao
    abstract fun projectDao(): ProjectDao
    abstract fun timeEntryDao(): TimeEntryDao
    abstract fun noteDao(): NoteDao
    abstract fun financeDao(): FinanceDao
    abstract fun debtDao(): DebtDao
    abstract fun goalDao(): GoalDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun securityScopeDao(): SecurityScopeDao
    abstract fun templateDao(): TemplateDao
    abstract fun aiDao(): AiDao
    abstract fun knowledgeDao(): KnowledgeDao
    abstract fun agentRuntimeDao(): AgentRuntimeDao

    companion object {
        private const val DB_NAME = "always_busy_life_os.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): AppDatabase {
            return Room.databaseBuilder(
                appContext,
                AppDatabase::class.java,
                DB_NAME
            )
                .addMigrations(MIGRATION_4_5)
                .addCallback(DatabasePrepopulateCallback(appContext))
                .build()
        }

        val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS agent_jobs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, persona TEXT NOT NULL, kind TEXT NOT NULL, conversation_id INTEGER, payload_json TEXT NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL, available_at INTEGER NOT NULL, idempotency_key TEXT NOT NULL, last_error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_agent_jobs_idempotency_key ON agent_jobs(idempotency_key)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_agent_jobs_status_available_at ON agent_jobs(status, available_at)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_agent_jobs_persona ON agent_jobs(persona)")
                db.execSQL("CREATE TABLE IF NOT EXISTS scheduled_agent_tasks (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, persona TEXT NOT NULL, prompt TEXT NOT NULL, due_at INTEGER NOT NULL, status TEXT NOT NULL, notification_plan_id INTEGER, idempotency_key TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_scheduled_agent_tasks_idempotency_key ON scheduled_agent_tasks(idempotency_key)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_scheduled_agent_tasks_status_due_at ON scheduled_agent_tasks(status, due_at)")
                db.execSQL("CREATE TABLE IF NOT EXISTS notification_plans (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, job_id INTEGER NOT NULL, decision TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, tone TEXT NOT NULL, actions_json TEXT NOT NULL, created_at INTEGER NOT NULL, read_at INTEGER)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_notification_plans_job_id ON notification_plans(job_id)")
                db.execSQL("CREATE TABLE IF NOT EXISTS tool_call_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, job_id INTEGER NOT NULL, tool_call_id TEXT NOT NULL, tool_name TEXT NOT NULL, arguments_json TEXT NOT NULL, result_json TEXT, status TEXT NOT NULL, created_at INTEGER NOT NULL, completed_at INTEGER)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_tool_call_records_job_id_tool_call_id ON tool_call_records(job_id, tool_call_id)")
                db.execSQL("CREATE TABLE IF NOT EXISTS persona_profiles (persona TEXT NOT NULL PRIMARY KEY, provider TEXT NOT NULL, base_url TEXT NOT NULL, model TEXT NOT NULL, max_iterations INTEGER NOT NULL, autonomous INTEGER NOT NULL, updated_at INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS persona_key_slots (persona TEXT NOT NULL, slot_index INTEGER NOT NULL, encrypted_key TEXT NOT NULL, status TEXT NOT NULL, failure_count INTEGER NOT NULL, cooldown_until INTEGER, updated_at INTEGER NOT NULL, PRIMARY KEY(persona, slot_index))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_persona_key_slots_persona_status ON persona_key_slots(persona, status)")
            }
        }
    }

    private class DatabasePrepopulateCallback(
        private val context: Context
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            CoroutineScope(Dispatchers.IO).launch {
                val database = getInstance(context)
                seedInitialData(database)
            }
        }

        private suspend fun seedInitialData(database: AppDatabase) {
            val financeDao = database.financeDao()
            val initialCategories = listOf(
                CategoryEntity(name = "راتب ودخل", type = TransactionType.INCOME, iconName = "payments", colorHex = "#2E7D32", isDefault = true),
                CategoryEntity(name = "عمل حر واستشارات", type = TransactionType.INCOME, iconName = "work", colorHex = "#00796B", isDefault = true),
                CategoryEntity(name = "سكن وإيجار", type = TransactionType.EXPENSE, iconName = "home", colorHex = "#D32F2F", isDefault = true),
                CategoryEntity(name = "طعام ومشتريات", type = TransactionType.EXPENSE, iconName = "restaurant", colorHex = "#F57C00", isDefault = true),
                CategoryEntity(name = "فواتير وطاقة ومولدات", type = TransactionType.EXPENSE, iconName = "bolt", colorHex = "#7B1FA2", isDefault = true),
                CategoryEntity(name = "مواصلات ووقود", type = TransactionType.EXPENSE, iconName = "directions_car", colorHex = "#0288D1", isDefault = true),
                CategoryEntity(name = "صحة وعلاج", type = TransactionType.EXPENSE, iconName = "medical_services", colorHex = "#C2185B", isDefault = true),
                CategoryEntity(name = "سداد التزامات وديون", type = TransactionType.EXPENSE, iconName = "receipt_long", colorHex = "#5D4037", isDefault = true)
            )
            for (category in initialCategories) {
                financeDao.insertCategory(category)
            }

            // No exchange-rate assumption is seeded. The user must provide a current manual rate.

            // Seed security scopes
            val scopeDao = database.securityScopeDao()
            val initialScopes = listOf(
                SecurityScopeEntity(scopeName = "tasks:read", description = "قراءة المهام والمشاريع والخطط", isGranted = true),
                SecurityScopeEntity(scopeName = "tasks:write", description = "إنشاء وتعديل وإنجاز المهام", isGranted = true),
                SecurityScopeEntity(scopeName = "notes:read", description = "قراءة الملاحظات وسياقات المعرفة", isGranted = true),
                SecurityScopeEntity(scopeName = "notes:write", description = "كتابة وتعديل الملاحظات", isGranted = false),
                SecurityScopeEntity(scopeName = "finance:read", description = "الاطلاع على الحركات المالية والأرصدة", isGranted = true),
                SecurityScopeEntity(scopeName = "finance:write", description = "تسجيل المعاملات المالية والميزانيات", isGranted = false),
                SecurityScopeEntity(scopeName = "debts:read", description = "قراءة دفتر الديون والالتزامات", isGranted = true),
                SecurityScopeEntity(scopeName = "debts:write", description = "تسجيل الديون وسداد الدفعات", isGranted = false),
                SecurityScopeEntity(scopeName = "audit:read", description = "استعراض سجل التدقيق والأحداث", isGranted = true)
            )
            for (scope in initialScopes) {
                scopeDao.insertScope(scope)
            }

            // Seed example template "العناية بالنباتات والورد" as documented in requirements
            val templateDao = database.templateDao()
            val plantTemplateId = templateDao.insertTemplate(
                TaskTemplateEntity(
                    name = "العناية بالورد والنباتات",
                    description = "قالب مخصص لمتابعة نقل أصص الورد ومقاساتها والسقاية والتسميد",
                    iconName = "spa",
                    colorHex = "#2E7D32",
                    autoNextTaskRule = """{"nextTargetOffset": 2, "unit": "سم", "scheduleDays": 30}"""
                )
            )

            val plantFields = listOf(
                TemplateFieldEntity(templateId = plantTemplateId, fieldName = "اسم النبتة", fieldKey = "plant_name", fieldType = "TEXT", isRequired = true, displayOrder = 1),
                TemplateFieldEntity(templateId = plantTemplateId, fieldName = "حجم الأصيص الحالي", fieldKey = "current_pot_size", fieldType = "MEASUREMENT", unit = "سم", minValue = 5.0, maxValue = 100.0, isRequired = true, displayOrder = 2),
                TemplateFieldEntity(templateId = plantTemplateId, fieldName = "حجم الأصيص المستهدف", fieldKey = "target_pot_size", fieldType = "MEASUREMENT", unit = "سم", minValue = 5.0, maxValue = 100.0, isRequired = true, displayOrder = 3),
                TemplateFieldEntity(templateId = plantTemplateId, fieldName = "نوع التربة", fieldKey = "soil_type", fieldType = "SINGLE_CHOICE", optionsJson = """["طينية", "رملية", "خليط مع بيتموس", "عضوية"]""", displayOrder = 4),
                TemplateFieldEntity(templateId = plantTemplateId, fieldName = "صحة النبتة", fieldKey = "plant_health", fieldType = "SCALE_1_10", minValue = 1.0, maxValue = 10.0, displayOrder = 5),
                TemplateFieldEntity(templateId = plantTemplateId, fieldName = "نوع السماد", fieldKey = "fertilizer_type", fieldType = "MULTI_CHOICE", optionsJson = """["نيتروجيني", "فوسفاتي", "بوتاسي", "عضوي سائل"]""", displayOrder = 6),
                TemplateFieldEntity(templateId = plantTemplateId, fieldName = "تاريخ آخر سقاية", fieldKey = "last_watered_date", fieldType = "DATE", displayOrder = 7),
                TemplateFieldEntity(templateId = plantTemplateId, fieldName = "ملاحظات وتطور النمو", fieldKey = "growth_notes", fieldType = "LONG_TEXT", displayOrder = 8)
            )
            templateDao.insertFields(plantFields)

            // Seed initial AI memories (Cumulative memory foundation)
            val aiDao = database.aiDao()
            val initialConvId = aiDao.insertConversation(
                AiConversationEntity(
                    title = "محادثة البدء والترحيب الذكي"
                )
            )
            aiDao.insertMessage(
                AiMessageEntity(
                    conversationId = initialConvId,
                    sender = "ASSISTANT",
                    content = "مرحباً بك! أنا رفيقك ومساعدك الذكي لإدارة نظام حياتك (Life OS). أستطيع تنفيذ أي إجراء، تنظيم مهامك، تسجيل نفقاتك وديونك، وحفظ كل تفضيلاتك في ذاكرتي التراكمية."
                )
            )

            val initialMemories = listOf(
                AiMemoryItemEntity(
                    category = "USER_PREFERENCE",
                    memoryKey = "currency_priority",
                    content = "يفضل المستخدم التعامل بالليرة السورية للنفقات اليومية، والدولار للمدخرات والأصول الكبرى.",
                    importance = 5
                ),
                AiMemoryItemEntity(
                    category = "HABIT",
                    memoryKey = "planning_rhythm",
                    content = "مراجعة المهام صباحاً، وإدخال النفقات المالية في المساء لضمان هدوء البال.",
                    importance = 4
                ),
                AiMemoryItemEntity(
                    category = "SEMANTIC_FACT",
                    memoryKey = "calm_score_philosophy",
                    content = "الهدف الأساسي هو خفض التشتت والوصول لمؤشر هدوء مرتفع عبر عدم تكديس أكثر من 5 مهام حرجة يومياً.",
                    importance = 5
                )
            )
            for (mem in initialMemories) {
                aiDao.insertOrUpdateMemory(mem)
            }

            // Seed initial Knowledge Indexes & Sections (Autonomous Memory foundation)
            val knowledgeDao = database.knowledgeDao()
            val workIndexId = knowledgeDao.insertIndex(
                com.example.data.local.entities.KnowledgeIndexEntity(
                    name = "عمل المستخدم",
                    description = "فهرس شامل لأنشطة العمل المهنية والمشاريع الميدانية",
                    colorHex = "#2196F3"
                )
            )
            val agricultureSecId = knowledgeDao.insertSection(
                com.example.data.local.entities.KnowledgeSectionEntity(
                    indexId = workIndexId,
                    indexName = "عمل المستخدم",
                    name = "باب الزراعة",
                    description = "مواعيد المحاصيل، دورات الري، وملاحظات الإنتاج الزراعي"
                )
            )
            val projectsSecId = knowledgeDao.insertSection(
                com.example.data.local.entities.KnowledgeSectionEntity(
                    indexId = workIndexId,
                    indexName = "عمل المستخدم",
                    name = "مشاريع العمل",
                    description = "المعالم الرئيسية وخطط التطوير"
                )
            )

            val financeIndexId = knowledgeDao.insertIndex(
                com.example.data.local.entities.KnowledgeIndexEntity(
                    name = "الإدارة المالية والالتزامات",
                    description = "فهرس الالتزامات المالية والديون وخطط سداد المستحقات",
                    colorHex = "#4CAF50"
                )
            )
            val debtsSecId = knowledgeDao.insertSection(
                com.example.data.local.entities.KnowledgeSectionEntity(
                    indexId = financeIndexId,
                    indexName = "الإدارة المالية والالتزامات",
                    name = "سداد الالتزامات والديون",
                    description = "أولويات السداد والمستحقات المتبقية"
                )
            )

            // Seed initial distilled memories
            knowledgeDao.insertMemory(
                com.example.data.local.entities.KnowledgeMemoryEntity(
                    sectionId = agricultureSecId,
                    indexName = "عمل المستخدم",
                    sectionName = "باب الزراعة",
                    query = "مواعيد ري القمح في الصباح",
                    summary = "دورة ري القمح كل 5 إلى 7 أيام في ساعات الصباح الباكر لتقليل التبخر المائي",
                    importance = 9,
                    tags = "زراعة,قمح,ري"
                )
            )
            knowledgeDao.insertMemory(
                com.example.data.local.entities.KnowledgeMemoryEntity(
                    sectionId = debtsSecId,
                    indexName = "الإدارة المالية والالتزامات",
                    sectionName = "سداد الالتزامات والديون",
                    query = "خطة سداد قرض المحل التجاري",
                    summary = "أولوية سداد دفعة 100 دولار شهرياً قبل نهاية كل شهر ميلادي لتقليل الفائدة التراكمية",
                    importance = 8,
                    tags = "ديون,مالية,قرض"
                )
            )
        }
    }
}
