package com.example.data.local.converters

import androidx.room.TypeConverter
import com.example.domain.models.*

class AppTypeConverters {

    @TypeConverter
    fun fromCurrency(value: CurrencyType?): String? = value?.name

    @TypeConverter
    fun toCurrency(value: String?): CurrencyType =
        value?.let { runCatching { CurrencyType.valueOf(it) }.getOrDefault(CurrencyType.SYP) } ?: CurrencyType.SYP

    @TypeConverter
    fun fromTaskPriority(value: TaskPriority?): String? = value?.name

    @TypeConverter
    fun toTaskPriority(value: String?): TaskPriority =
        value?.let { runCatching { TaskPriority.valueOf(it) }.getOrDefault(TaskPriority.IMPORTANT_NOT_URGENT) } ?: TaskPriority.IMPORTANT_NOT_URGENT

    @TypeConverter
    fun fromTaskStatus(value: TaskStatus?): String? = value?.name

    @TypeConverter
    fun toTaskStatus(value: String?): TaskStatus =
        value?.let { runCatching { TaskStatus.valueOf(it) }.getOrDefault(TaskStatus.PENDING) } ?: TaskStatus.PENDING

    @TypeConverter
    fun fromTimeHorizon(value: TimeHorizon?): String? = value?.name

    @TypeConverter
    fun toTimeHorizon(value: String?): TimeHorizon =
        value?.let { runCatching { TimeHorizon.valueOf(it) }.getOrDefault(TimeHorizon.DAILY) } ?: TimeHorizon.DAILY

    @TypeConverter
    fun fromDebtType(value: DebtType?): String? = value?.name

    @TypeConverter
    fun toDebtType(value: String?): DebtType =
        value?.let { runCatching { DebtType.valueOf(it) }.getOrDefault(DebtType.I_OWE) } ?: DebtType.I_OWE

    @TypeConverter
    fun fromDebtStatus(value: DebtStatus?): String? = value?.name

    @TypeConverter
    fun toDebtStatus(value: String?): DebtStatus =
        value?.let { runCatching { DebtStatus.valueOf(it) }.getOrDefault(DebtStatus.ACTIVE) } ?: DebtStatus.ACTIVE

    @TypeConverter
    fun fromTransactionType(value: TransactionType?): String? = value?.name

    @TypeConverter
    fun toTransactionType(value: String?): TransactionType =
        value?.let { runCatching { TransactionType.valueOf(it) }.getOrDefault(TransactionType.EXPENSE) } ?: TransactionType.EXPENSE

    @TypeConverter
    fun fromGoalHorizon(value: GoalHorizon?): String? = value?.name

    @TypeConverter
    fun toGoalHorizon(value: String?): GoalHorizon =
        value?.let { runCatching { GoalHorizon.valueOf(it) }.getOrDefault(GoalHorizon.MEDIUM_TERM) } ?: GoalHorizon.MEDIUM_TERM

    @TypeConverter
    fun fromGoalStatus(value: GoalStatus?): String? = value?.name

    @TypeConverter
    fun toGoalStatus(value: String?): GoalStatus =
        value?.let { runCatching { GoalStatus.valueOf(it) }.getOrDefault(GoalStatus.IN_PROGRESS) } ?: GoalStatus.IN_PROGRESS

    @TypeConverter
    fun fromAuditAction(value: AuditAction?): String? = value?.name

    @TypeConverter
    fun toAuditAction(value: String?): AuditAction =
        value?.let { runCatching { AuditAction.valueOf(it) }.getOrDefault(AuditAction.UPDATE) } ?: AuditAction.UPDATE

    @TypeConverter
    fun fromAuditActor(value: AuditActor?): String? = value?.name

    @TypeConverter
    fun toAuditActor(value: String?): AuditActor =
        value?.let { runCatching { AuditActor.valueOf(it) }.getOrDefault(AuditActor.USER) } ?: AuditActor.USER
}
