package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entities.*

@Dao
interface AgentRuntimeDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertJob(job: AgentJobEntity): Long

    @Query("SELECT * FROM agent_jobs WHERE status IN ('QUEUED','RETRY') AND available_at <= :now ORDER BY available_at, id LIMIT :limit")
    suspend fun claimableJobs(now: Long, limit: Int = 20): List<AgentJobEntity>

    @Query("SELECT * FROM agent_jobs WHERE id = :id LIMIT 1")
    suspend fun getJob(id: Long): AgentJobEntity?

    @Query("UPDATE agent_jobs SET status = :status, attempts = :attempts, last_error = :error, updated_at = :now WHERE id = :id")
    suspend fun updateJob(id: Long, status: String, attempts: Int, error: String?, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM agent_jobs WHERE idempotency_key = :key LIMIT 1")
    suspend fun getJobByIdempotencyKey(key: String): AgentJobEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertScheduled(task: ScheduledAgentTaskEntity): Long

    @Query("SELECT * FROM scheduled_agent_tasks WHERE id = :id LIMIT 1")
    suspend fun getScheduled(id: Long): ScheduledAgentTaskEntity?

    @Query("SELECT * FROM scheduled_agent_tasks WHERE status = 'SCHEDULED' AND due_at <= :now ORDER BY due_at LIMIT :limit")
    suspend fun dueScheduled(now: Long, limit: Int = 20): List<ScheduledAgentTaskEntity>

    @Query("SELECT * FROM scheduled_agent_tasks WHERE status = 'SCHEDULED' ORDER BY due_at")
    suspend fun allScheduled(): List<ScheduledAgentTaskEntity>

    @Query("UPDATE scheduled_agent_tasks SET status = :status, updated_at = :now WHERE id = :id")
    suspend fun updateScheduledStatus(id: Long, status: String, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM scheduled_agent_tasks WHERE idempotency_key = :key LIMIT 1")
    suspend fun getScheduledByIdempotencyKey(key: String): ScheduledAgentTaskEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPlan(plan: NotificationPlanEntity): Long

    @Query("SELECT * FROM notification_plans WHERE id = :id LIMIT 1")
    suspend fun getPlan(id: Long): NotificationPlanEntity?

    @Query("UPDATE notification_plans SET read_at = :now WHERE id = :id")
    suspend fun markPlanRead(id: Long, now: Long = System.currentTimeMillis())

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertToolCall(call: ToolCallRecordEntity): Long

    @Query("UPDATE tool_call_records SET result_json = :result, status = :status, completed_at = :now WHERE job_id = :jobId AND tool_call_id = :toolCallId")
    suspend fun completeToolCall(jobId: Long, toolCallId: String, result: String, status: String, now: Long = System.currentTimeMillis())

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: PersonaProfileEntity)

    @Query("SELECT * FROM persona_profiles WHERE persona = :persona LIMIT 1")
    suspend fun getProfile(persona: String): PersonaProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertKeySlot(slot: PersonaKeySlotEntity)

    @Query("SELECT * FROM persona_key_slots WHERE persona = :persona ORDER BY slot_index")
    suspend fun getKeySlots(persona: String): List<PersonaKeySlotEntity>

    @Query("SELECT * FROM persona_key_slots WHERE persona = :persona AND status = 'ACTIVE' AND (cooldown_until IS NULL OR cooldown_until <= :now) ORDER BY slot_index")
    suspend fun getActiveKeySlots(persona: String, now: Long = System.currentTimeMillis()): List<PersonaKeySlotEntity>

    @Query("UPDATE persona_key_slots SET status = 'DEMOTED', failure_count = failure_count + 1, cooldown_until = :until, updated_at = :now WHERE persona = :persona AND slot_index = :slotIndex")
    suspend fun demoteKeySlot(persona: String, slotIndex: Int, until: Long, now: Long = System.currentTimeMillis())
}
