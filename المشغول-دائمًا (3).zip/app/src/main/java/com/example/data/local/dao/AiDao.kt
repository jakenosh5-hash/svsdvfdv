package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.AiConversationEntity
import com.example.data.local.entities.AiMemoryItemEntity
import com.example.data.local.entities.AiMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AiDao {

    // --- Conversations ---
    @Query("SELECT * FROM ai_conversations WHERE is_archived = 0 ORDER BY updated_at DESC")
    fun getActiveConversations(): Flow<List<AiConversationEntity>>

    @Query("SELECT * FROM ai_conversations WHERE id = :id LIMIT 1")
    suspend fun getConversationById(id: Long): AiConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: AiConversationEntity): Long

    @Update
    suspend fun updateConversation(conversation: AiConversationEntity)

    @Query("DELETE FROM ai_conversations WHERE id = :id")
    suspend fun deleteConversation(id: Long)

    // --- Messages ---
    @Query("SELECT * FROM ai_messages WHERE conversation_id = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: Long): Flow<List<AiMessageEntity>>

    @Query("SELECT * FROM ai_messages WHERE conversation_id = :conversationId ORDER BY timestamp ASC")
    suspend fun getMessagesList(conversationId: Long): List<AiMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: AiMessageEntity): Long

    @Query("DELETE FROM ai_messages WHERE conversation_id = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: Long)

    // --- Memories (Cumulative Long-Term Memory) ---
    @Query("SELECT * FROM ai_memories ORDER BY importance DESC, last_accessed_at DESC")
    fun getAllMemories(): Flow<List<AiMemoryItemEntity>>

    @Query("SELECT * FROM ai_memories ORDER BY importance DESC, last_accessed_at DESC")
    suspend fun getAllMemoriesList(): List<AiMemoryItemEntity>

    @Query("SELECT * FROM ai_memories WHERE category = :category ORDER BY importance DESC")
    fun getMemoriesByCategory(category: String): Flow<List<AiMemoryItemEntity>>

    @Query("SELECT * FROM ai_memories WHERE memory_key = :key LIMIT 1")
    suspend fun getMemoryByKey(key: String): AiMemoryItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateMemory(memory: AiMemoryItemEntity): Long

    @Update
    suspend fun updateMemory(memory: AiMemoryItemEntity)

    @Query("DELETE FROM ai_memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    @Query("UPDATE ai_memories SET last_accessed_at = :timestamp, access_count = access_count + 1 WHERE id = :id")
    suspend fun recordMemoryAccess(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("SELECT * FROM ai_memories WHERE content LIKE '%' || :query || '%' OR memory_key LIKE '%' || :query || '%' ORDER BY importance DESC")
    suspend fun searchMemories(query: String): List<AiMemoryItemEntity>
}
