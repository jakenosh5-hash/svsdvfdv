package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.*
import com.example.domain.models.CurrencyType
import com.example.domain.models.DebtStatus
import com.example.domain.models.DebtType
import com.example.domain.models.GoalHorizon
import kotlinx.coroutines.flow.Flow

@Dao
interface FinanceDao {
    @Query("SELECT * FROM finance_transactions ORDER BY transaction_date DESC")
    fun getAllTransactions(): Flow<List<FinanceTransactionEntity>>

    @Query("SELECT * FROM finance_transactions WHERE currency = :currency ORDER BY transaction_date DESC")
    fun getTransactionsByCurrency(currency: CurrencyType): Flow<List<FinanceTransactionEntity>>

    @Query("SELECT * FROM finance_transactions WHERE category_id = :categoryId ORDER BY transaction_date DESC")
    fun getTransactionsByCategory(categoryId: Long): Flow<List<FinanceTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FinanceTransactionEntity): Long

    @Delete
    suspend fun deleteTransaction(transaction: FinanceTransactionEntity)

    // Categories
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories WHERE id = :id LIMIT 1")
    suspend fun getCategoryById(id: Long): CategoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryEntity): Long

    // Budgets
    @Query("SELECT * FROM budgets WHERE year_month = :yearMonth")
    fun getBudgetsForMonth(yearMonth: String): Flow<List<BudgetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudget(budget: BudgetEntity): Long

    // Assets
    @Query("SELECT * FROM assets ORDER BY current_value DESC")
    fun getAllAssets(): Flow<List<AssetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAsset(asset: AssetEntity): Long

    @Update
    suspend fun updateAsset(asset: AssetEntity)

    @Delete
    suspend fun deleteAsset(asset: AssetEntity)

    // Exchange Rates
    @Query("SELECT * FROM exchange_rates ORDER BY recorded_at DESC LIMIT 1")
    fun getLatestExchangeRateFlow(): Flow<ExchangeRateEntity?>

    @Query("SELECT * FROM exchange_rates ORDER BY recorded_at DESC LIMIT 1")
    suspend fun getLatestExchangeRate(): ExchangeRateEntity?

    @Query("SELECT * FROM exchange_rates ORDER BY recorded_at DESC")
    fun getAllExchangeRates(): Flow<List<ExchangeRateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExchangeRate(rate: ExchangeRateEntity): Long
}

@Dao
interface DebtDao {
    @Query("SELECT * FROM debts ORDER BY created_at DESC")
    fun getAllDebts(): Flow<List<DebtEntity>>

    @Query("SELECT * FROM debts WHERE type = :type ORDER BY status ASC, due_date ASC")
    fun getDebtsByType(type: DebtType): Flow<List<DebtEntity>>

    @Query("SELECT * FROM debts WHERE status = :status ORDER BY due_date ASC")
    fun getDebtsByStatus(status: DebtStatus): Flow<List<DebtEntity>>

    @Query("SELECT * FROM debts WHERE id = :id LIMIT 1")
    suspend fun getDebtById(id: Long): DebtEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: DebtEntity): Long

    @Update
    suspend fun updateDebt(debt: DebtEntity)

    @Delete
    suspend fun deleteDebt(debt: DebtEntity)

    // Payments
    @Query("SELECT * FROM debt_payments WHERE debt_id = :debtId ORDER BY payment_date DESC")
    fun getPaymentsForDebt(debtId: Long): Flow<List<DebtPaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: DebtPaymentEntity): Long

    @Transaction
    suspend fun applyDebtPayment(payment: DebtPaymentEntity) {
        insertPayment(payment)
        val debt = getDebtById(payment.debtId) ?: return
        val newRemaining = (debt.remainingAmount - payment.amount).coerceAtLeast(0.0)
        val newStatus = if (newRemaining <= 0.0) DebtStatus.PAID else debt.status
        updateDebt(debt.copy(remainingAmount = newRemaining, status = newStatus, updatedAt = System.currentTimeMillis()))
    }
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals ORDER BY created_at DESC")
    fun getAllGoals(): Flow<List<GoalEntity>>

    @Query("SELECT * FROM goals WHERE horizon = :horizon ORDER BY status ASC, target_date ASC")
    fun getGoalsByHorizon(horizon: GoalHorizon): Flow<List<GoalEntity>>

    @Query("SELECT * FROM goals WHERE id = :id LIMIT 1")
    suspend fun getGoalById(id: Long): GoalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: GoalEntity): Long

    @Update
    suspend fun updateGoal(goal: GoalEntity)

    @Delete
    suspend fun deleteGoal(goal: GoalEntity)

    @Query("SELECT * FROM goal_milestones WHERE goal_id = :goalId ORDER BY id ASC")
    fun getMilestonesForGoal(goalId: Long): Flow<List<GoalMilestoneEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMilestone(milestone: GoalMilestoneEntity): Long

    @Update
    suspend fun updateMilestone(milestone: GoalMilestoneEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 500")
    fun getRecentAuditLogs(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs WHERE entity_type = :entityType AND entity_id = :entityId ORDER BY timestamp DESC")
    fun getLogsForEntity(entityType: String, entityId: Long): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long
}

@Dao
interface SecurityScopeDao {
    @Query("SELECT * FROM security_scopes ORDER BY scope_name ASC")
    fun getAllScopes(): Flow<List<SecurityScopeEntity>>

    @Query("SELECT * FROM security_scopes WHERE scope_name = :scopeName LIMIT 1")
    suspend fun getScope(scopeName: String): SecurityScopeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScope(scope: SecurityScopeEntity): Long

    @Update
    suspend fun updateScope(scope: SecurityScopeEntity)
}
