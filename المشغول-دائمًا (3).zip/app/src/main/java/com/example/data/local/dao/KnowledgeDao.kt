package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.KnowledgeIndexEntity
import com.example.data.local.entities.KnowledgeMemoryEntity
import com.example.data.local.entities.KnowledgeSectionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface KnowledgeDao {

    // --- Indexes (الفهارس) ---
    @Query("SELECT * FROM knowledge_indexes ORDER BY name ASC")
    fun getAllIndexes(): Flow<List<KnowledgeIndexEntity>>

    @Query("SELECT * FROM knowledge_indexes ORDER BY name ASC")
    suspend fun getAllIndexesList(): List<KnowledgeIndexEntity>

    @Query("SELECT * FROM knowledge_indexes WHERE name = :name LIMIT 1")
    suspend fun getIndexByName(name: String): KnowledgeIndexEntity?

    @Query("SELECT * FROM knowledge_indexes WHERE id = :id LIMIT 1")
    suspend fun getIndexById(id: Long): KnowledgeIndexEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIndex(index: KnowledgeIndexEntity): Long

    @Query("DELETE FROM knowledge_indexes WHERE id = :id")
    suspend fun deleteIndex(id: Long)

    // --- Sections (الأبواب) ---
    @Query("SELECT * FROM knowledge_sections WHERE index_id = :indexId ORDER BY name ASC")
    fun getSectionsForIndex(indexId: Long): Flow<List<KnowledgeSectionEntity>>

    @Query("SELECT * FROM knowledge_sections ORDER BY index_name ASC, name ASC")
    fun getAllSections(): Flow<List<KnowledgeSectionEntity>>

    @Query("SELECT * FROM knowledge_sections ORDER BY index_name ASC, name ASC")
    suspend fun getAllSectionsList(): List<KnowledgeSectionEntity>

    @Query("SELECT * FROM knowledge_sections WHERE index_id = :indexId AND name = :name LIMIT 1")
    suspend fun getSectionByName(indexId: Long, name: String): KnowledgeSectionEntity?

    @Query("SELECT * FROM knowledge_sections WHERE index_name = :indexName AND name = :name LIMIT 1")
    suspend fun getSectionByNames(indexName: String, name: String): KnowledgeSectionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSection(section: KnowledgeSectionEntity): Long

    @Query("DELETE FROM knowledge_sections WHERE id = :id")
    suspend fun deleteSection(id: Long)

    // --- Memories (الذواكر المقطرة) ---
    @Query("SELECT * FROM knowledge_memories WHERE section_id = :sectionId ORDER BY created_at DESC")
    fun getMemoriesForSection(sectionId: Long): Flow<List<KnowledgeMemoryEntity>>

    @Query("SELECT * FROM knowledge_memories ORDER BY created_at DESC")
    fun getAllMemories(): Flow<List<KnowledgeMemoryEntity>>

    @Query("SELECT * FROM knowledge_memories ORDER BY created_at DESC")
    suspend fun getAllMemoriesList(): List<KnowledgeMemoryEntity>

    @Query("SELECT * FROM knowledge_memories WHERE index_name = :indexName AND section_name = :sectionName ORDER BY created_at DESC")
    suspend fun getMemoriesBySectionNames(indexName: String, sectionName: String): List<KnowledgeMemoryEntity>

    @Query("""
        SELECT * FROM knowledge_memories 
        WHERE summary LIKE '%' || :query || '%' 
           OR query LIKE '%' || :query || '%' 
           OR index_name LIKE '%' || :query || '%' 
           OR section_name LIKE '%' || :query || '%' 
           OR tags LIKE '%' || :query || '%'
        ORDER BY importance DESC, created_at DESC
        LIMIT 50
    """)
    suspend fun searchMemories(query: String): List<KnowledgeMemoryEntity>

    @Query("SELECT * FROM knowledge_memories WHERE id = :id LIMIT 1")
    suspend fun getMemoryById(id: Long): KnowledgeMemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: KnowledgeMemoryEntity): Long

    @Query("DELETE FROM knowledge_memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    @Query("SELECT COUNT(*) FROM knowledge_memories")
    suspend fun getMemoriesCount(): Int
}
