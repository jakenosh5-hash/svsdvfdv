package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.*
import com.example.domain.models.TaskPriority
import com.example.domain.models.TaskStatus
import com.example.domain.models.TimeHorizon
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY created_at DESC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE time_horizon = :horizon ORDER BY priority ASC, due_date ASC")
    fun getTasksByHorizon(horizon: TimeHorizon): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE due_date BETWEEN :startOfDay AND :endOfDay OR (time_horizon = 'DAILY' AND status != 'COMPLETED') ORDER BY priority ASC, due_date ASC")
    fun getTodayTasks(startOfDay: Long, endOfDay: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE due_date BETWEEN :startTime AND :endTime ORDER BY due_date ASC, due_time_minutes ASC")
    fun getTasksInDateRange(startTime: Long, endTime: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE parent_task_id = :parentTaskId ORDER BY created_at ASC")
    fun getSubtasks(parentTaskId: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE parent_task_id = :parentTaskId ORDER BY created_at ASC")
    suspend fun getSubtasksList(parentTaskId: Long): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE project_id = :projectId ORDER BY priority ASC, created_at DESC")
    fun getTasksByProject(projectId: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE is_recurring = 1")
    suspend fun getRecurringTasks(): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: Long): TaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("UPDATE tasks SET status = :newStatus, completed_at = :completedAt, updated_at = :updatedAt WHERE id = :id")
    suspend fun updateTaskStatus(id: Long, newStatus: TaskStatus, completedAt: Long?, updatedAt: Long)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updated_at DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE status = 'ACTIVE' ORDER BY updated_at DESC")
    fun getActiveProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)
}

@Dao
interface TimeEntryDao {
    @Query("SELECT * FROM time_entries ORDER BY start_time DESC")
    fun getAllEntries(): Flow<List<TimeEntryEntity>>

    @Query("SELECT * FROM time_entries WHERE start_time BETWEEN :startTime AND :endTime ORDER BY start_time DESC")
    fun getEntriesBetween(startTime: Long, endTime: Long): Flow<List<TimeEntryEntity>>

    @Query("SELECT * FROM time_entries WHERE task_id = :taskId ORDER BY start_time DESC")
    fun getEntriesForTask(taskId: Long): Flow<List<TimeEntryEntity>>

    @Query("SELECT * FROM time_entries WHERE end_time IS NULL ORDER BY start_time DESC LIMIT 1")
    suspend fun getRunningEntry(): TimeEntryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimeEntry(entry: TimeEntryEntity): Long

    @Update
    suspend fun updateTimeEntry(entry: TimeEntryEntity)

    @Delete
    suspend fun deleteTimeEntry(entry: TimeEntryEntity)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE is_archived = 0 ORDER BY is_pinned DESC, updated_at DESC")
    fun getActiveNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE is_archived = 1 ORDER BY updated_at DESC")
    fun getArchivedNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE title LIKE '%' || :query || '%' OR content_markdown LIKE '%' || :query || '%' ORDER BY updated_at DESC")
    fun searchNotes(query: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE project_id = :projectId ORDER BY updated_at DESC")
    fun getNotesForProject(projectId: Long): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE debt_id = :debtId ORDER BY updated_at DESC")
    fun getNotesForDebt(debtId: Long): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE id = :id LIMIT 1")
    suspend fun getNoteById(id: Long): NoteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity): Long

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Delete
    suspend fun deleteNote(note: NoteEntity)
}
