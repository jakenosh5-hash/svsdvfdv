package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.TaskCustomValueEntity
import com.example.data.local.entities.TaskTemplateEntity
import com.example.data.local.entities.TemplateFieldEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TemplateDao {

    // --- Templates ---
    @Query("SELECT * FROM task_templates ORDER BY name ASC")
    fun getAllTemplates(): Flow<List<TaskTemplateEntity>>

    @Query("SELECT * FROM task_templates WHERE id = :id LIMIT 1")
    suspend fun getTemplateById(id: Long): TaskTemplateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: TaskTemplateEntity): Long

    @Update
    suspend fun updateTemplate(template: TaskTemplateEntity)

    @Delete
    suspend fun deleteTemplate(template: TaskTemplateEntity)

    // --- Fields ---
    @Query("SELECT * FROM template_fields WHERE template_id = :templateId ORDER BY display_order ASC")
    fun getFieldsForTemplate(templateId: Long): Flow<List<TemplateFieldEntity>>

    @Query("SELECT * FROM template_fields WHERE template_id = :templateId ORDER BY display_order ASC")
    suspend fun getFieldsForTemplateList(templateId: Long): List<TemplateFieldEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertField(field: TemplateFieldEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFields(fields: List<TemplateFieldEntity>)

    // --- Custom Values ---
    @Query("SELECT * FROM task_custom_values WHERE task_id = :taskId")
    fun getCustomValuesForTask(taskId: Long): Flow<List<TaskCustomValueEntity>>

    @Query("SELECT * FROM task_custom_values WHERE task_id = :taskId")
    suspend fun getCustomValuesForTaskList(taskId: Long): List<TaskCustomValueEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomValue(value: TaskCustomValueEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomValues(values: List<TaskCustomValueEntity>)

    @Query("DELETE FROM task_custom_values WHERE task_id = :taskId")
    suspend fun deleteCustomValuesForTask(taskId: Long)
}
