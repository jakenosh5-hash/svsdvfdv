package com.example.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "agent_jobs",
    indices = [
        Index(value = ["status", "available_at"]),
        Index(value = ["idempotency_key"], unique = true),
        Index(value = ["persona"])
    ]
)
data class AgentJobEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val persona: String,
    val kind: String,
    @ColumnInfo(name = "conversation_id") val conversationId: Long? = null,
    @ColumnInfo(name = "payload_json") val payloadJson: String,
    val status: String = "QUEUED",
    val attempts: Int = 0,
    @ColumnInfo(name = "available_at") val availableAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "idempotency_key") val idempotencyKey: String,
    @ColumnInfo(name = "last_error") val lastError: String? = null,
    @ColumnInfo(name = "created_at") val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at") val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "scheduled_agent_tasks",
    indices = [Index(value = ["status", "due_at"]), Index(value = ["idempotency_key"], unique = true)]
)
data class ScheduledAgentTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val persona: String,
    val prompt: String,
    @ColumnInfo(name = "due_at") val dueAt: Long,
    val status: String = "SCHEDULED",
    @ColumnInfo(name = "notification_plan_id") val notificationPlanId: Long? = null,
    @ColumnInfo(name = "idempotency_key") val idempotencyKey: String,
    @ColumnInfo(name = "created_at") val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at") val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "notification_plans",
    indices = [Index(value = ["job_id"], unique = true)]
)
data class NotificationPlanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "job_id") val jobId: Long,
    val decision: String,
    val title: String,
    val body: String,
    val tone: String,
    @ColumnInfo(name = "actions_json") val actionsJson: String,
    @ColumnInfo(name = "created_at") val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "read_at") val readAt: Long? = null
)

@Entity(
    tableName = "tool_call_records",
    indices = [Index(value = ["job_id", "tool_call_id"], unique = true)]
)
data class ToolCallRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "job_id") val jobId: Long,
    @ColumnInfo(name = "tool_call_id") val toolCallId: String,
    @ColumnInfo(name = "tool_name") val toolName: String,
    @ColumnInfo(name = "arguments_json") val argumentsJson: String,
    @ColumnInfo(name = "result_json") val resultJson: String? = null,
    val status: String = "STARTED",
    @ColumnInfo(name = "created_at") val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "completed_at") val completedAt: Long? = null
)

@Entity(tableName = "persona_profiles")
data class PersonaProfileEntity(
    @PrimaryKey val persona: String,
    val provider: String,
    @ColumnInfo(name = "base_url") val baseUrl: String,
    val model: String,
    @ColumnInfo(name = "max_iterations") val maxIterations: Int = 8,
    val autonomous: Boolean = true,
    @ColumnInfo(name = "updated_at") val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "persona_key_slots",
    primaryKeys = ["persona", "slot_index"],
    indices = [Index(value = ["persona", "status"])]
)
data class PersonaKeySlotEntity(
    val persona: String,
    @ColumnInfo(name = "slot_index") val slotIndex: Int,
    @ColumnInfo(name = "encrypted_key") val encryptedKey: String,
    val status: String = "ACTIVE",
    @ColumnInfo(name = "failure_count") val failureCount: Int = 0,
    @ColumnInfo(name = "cooldown_until") val cooldownUntil: Long? = null,
    @ColumnInfo(name = "updated_at") val updatedAt: Long = System.currentTimeMillis()
)
