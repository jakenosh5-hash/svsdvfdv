package com.example.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "ai_conversations"
)
data class AiConversationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    @ColumnInfo(name = "persona")
    val persona: String = "REM", // REM or RAM
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "is_archived")
    val isArchived: Boolean = false
)

@Entity(
    tableName = "ai_messages",
    foreignKeys = [
        ForeignKey(
            entity = AiConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversation_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["conversation_id"], name = "idx_messages_conversation_id")
    ]
)
data class AiMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "conversation_id")
    val conversationId: Long,
    val sender: String, // USER, ASSISTANT, SYSTEM, TOOL
    val content: String,
    @ColumnInfo(name = "reply_to_id")
    val replyToId: Long? = null,
    @ColumnInfo(name = "reply_to_text")
    val replyToText: String? = null,
    @ColumnInfo(name = "reply_to_sender")
    val replyToSender: String? = null,
    @ColumnInfo(name = "tool_calls_json")
    val toolCallsJson: String? = null,
    @ColumnInfo(name = "tool_result_json")
    val toolResultJson: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "ai_memories",
    indices = [
        Index(value = ["category"], name = "idx_memories_category"),
        Index(value = ["memory_key"], unique = true, name = "idx_memories_key")
    ]
)
data class AiMemoryItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // USER_PREFERENCE, SEMANTIC_FACT, HABIT, EPISODIC_SUMMARY, GOAL_NOTE
    @ColumnInfo(name = "memory_key")
    val memoryKey: String,
    val content: String,
    val importance: Int = 3, // 1 to 5
    @ColumnInfo(name = "source_conversation_id")
    val sourceConversationId: Long? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "last_accessed_at")
    val lastAccessedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "access_count")
    val accessCount: Int = 0
)
