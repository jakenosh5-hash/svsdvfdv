package com.example.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.domain.models.CurrencyType
import com.example.domain.models.DebtStatus
import com.example.domain.models.DebtType

@Entity(
    tableName = "debts",
    indices = [
        Index(value = ["status", "due_date"], name = "idx_debts_status_due"),
        Index(value = ["type", "currency"], name = "idx_debts_type_currency")
    ]
)
data class DebtEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: DebtType, // I_OWE or OWED_TO_ME
    @ColumnInfo(name = "person_name")
    val personName: String,
    @ColumnInfo(name = "phone_number")
    val phoneNumber: String? = null,
    @ColumnInfo(name = "original_amount")
    val originalAmount: Double,
    @ColumnInfo(name = "remaining_amount")
    val remainingAmount: Double,
    val currency: CurrencyType = CurrencyType.SYP,
    @ColumnInfo(name = "due_date")
    val dueDate: Long? = null,
    val status: DebtStatus = DebtStatus.ACTIVE,
    @ColumnInfo(name = "interest_rate_percent")
    val interestRatePercent: Double = 0.0,
    val note: String? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "debt_payments",
    foreignKeys = [
        ForeignKey(
            entity = DebtEntity::class,
            parentColumns = ["id"],
            childColumns = ["debt_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["debt_id"], name = "idx_debt_payments_debt_id"),
        Index(value = ["payment_date"], name = "idx_debt_payments_date")
    ]
)
data class DebtPaymentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "debt_id")
    val debtId: Long,
    val amount: Double,
    val currency: CurrencyType = CurrencyType.SYP,
    @ColumnInfo(name = "payment_date")
    val paymentDate: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "receipt_note")
    val receiptNote: String? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)
