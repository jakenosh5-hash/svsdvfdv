package com.example.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.domain.models.CurrencyType
import com.example.domain.models.TransactionType

@Entity(
    tableName = "categories",
    indices = [
        Index(value = ["name"], unique = true, name = "idx_categories_name")
    ]
)
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: TransactionType = TransactionType.EXPENSE, // INCOME, EXPENSE, BOTH
    @ColumnInfo(name = "icon_name")
    val iconName: String = "tag",
    @ColumnInfo(name = "color_hex")
    val colorHex: String = "#2E7D32",
    @ColumnInfo(name = "is_default")
    val isDefault: Boolean = false
)

@Entity(
    tableName = "finance_transactions",
    foreignKeys = [
        ForeignKey(
            entity = CategoryEntity::class,
            parentColumns = ["id"],
            childColumns = ["category_id"],
            onDelete = ForeignKey.RESTRICT
        ),
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["transaction_date", "type"], name = "idx_finance_date_type"),
        Index(value = ["currency"], name = "idx_finance_currency"),
        Index(value = ["category_id"], name = "idx_finance_category"),
        Index(value = ["project_id"], name = "idx_finance_project_id")
    ]
)
data class FinanceTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: TransactionType,
    val amount: Double,
    val currency: CurrencyType = CurrencyType.SYP,
    @ColumnInfo(name = "category_id")
    val categoryId: Long,
    @ColumnInfo(name = "project_id")
    val projectId: Long? = null,
    @ColumnInfo(name = "transaction_date")
    val transactionDate: Long = System.currentTimeMillis(),
    val note: String? = null,
    @ColumnInfo(name = "is_recurring")
    val isRecurring: Boolean = false,
    @ColumnInfo(name = "recurrence_rule")
    val recurrenceRule: String? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "budgets",
    foreignKeys = [
        ForeignKey(
            entity = CategoryEntity::class,
            parentColumns = ["id"],
            childColumns = ["category_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["category_id", "year_month"], unique = true, name = "idx_budgets_category_month")
    ]
)
data class BudgetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "category_id")
    val categoryId: Long,
    @ColumnInfo(name = "monthly_limit")
    val monthlyLimit: Double,
    val currency: CurrencyType = CurrencyType.SYP,
    @ColumnInfo(name = "year_month")
    val yearMonth: String, // e.g. "2026-09"
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "assets"
)
data class AssetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String, // CASH, BANK, GOLD, REAL_ESTATE, STOCKS, OTHER
    @ColumnInfo(name = "current_value")
    val currentValue: Double,
    @ColumnInfo(name = "purchase_cost")
    val purchaseCost: Double? = null,
    val currency: CurrencyType = CurrencyType.SYP,
    @ColumnInfo(name = "last_valued_at")
    val lastValuedAt: Long = System.currentTimeMillis(),
    val note: String? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "exchange_rates"
)
data class ExchangeRateEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "base_currency")
    val baseCurrency: String = "USD",
    @ColumnInfo(name = "target_currency")
    val targetCurrency: String = "SYP",
    val rate: Double, // e.g. 14500.0 (1 USD = 14,500 SYP)
    @ColumnInfo(name = "recorded_at")
    val recordedAt: Long = System.currentTimeMillis(),
    val note: String? = null
)
