package com.example.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.domain.models.AuditAction
import com.example.domain.models.AuditActor
import com.example.domain.models.GoalHorizon
import com.example.domain.models.GoalStatus

@Entity(
    tableName = "goals"
)
data class GoalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String? = null,
    val horizon: GoalHorizon = GoalHorizon.MEDIUM_TERM,
    @ColumnInfo(name = "metric_type")
    val metricType: String = "PERCENTAGE", // PERCENTAGE, NUMERIC, TASK_BASED
    @ColumnInfo(name = "target_value")
    val targetValue: Double = 100.0,
    @ColumnInfo(name = "current_value")
    val currentValue: Double = 0.0,
    @ColumnInfo(name = "target_date")
    val targetDate: Long? = null,
    val status: GoalStatus = GoalStatus.IN_PROGRESS,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "goal_milestones",
    foreignKeys = [
        ForeignKey(
            entity = GoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goal_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["goal_id"], name = "idx_milestones_goal_id")
    ]
)
data class GoalMilestoneEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "goal_id")
    val goalId: Long,
    val title: String,
    @ColumnInfo(name = "target_value")
    val targetValue: Double = 1.0,
    @ColumnInfo(name = "current_value")
    val currentValue: Double = 0.0,
    @ColumnInfo(name = "is_completed")
    val isCompleted: Boolean = false,
    @ColumnInfo(name = "target_date")
    val targetDate: Long? = null
)

@Entity(
    tableName = "audit_logs",
    indices = [
        Index(value = ["entity_type", "entity_id"], name = "idx_audit_entity"),
        Index(value = ["timestamp"], name = "idx_audit_timestamp")
    ]
)
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "entity_type")
    val entityType: String, // TASK, DEBT, PAYMENT, NOTE, FINANCE, GOAL, ASSET, SCOPE
    @ColumnInfo(name = "entity_id")
    val entityId: Long,
    val action: AuditAction,
    val actor: AuditActor = AuditActor.USER,
    @ColumnInfo(name = "payload_before_json")
    val payloadBeforeJson: String? = null,
    @ColumnInfo(name = "payload_after_json")
    val payloadAfterJson: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "security_scopes",
    indices = [
        Index(value = ["scope_name"], unique = true, name = "idx_scopes_name")
    ]
)
data class SecurityScopeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "scope_name")
    val scopeName: String,
    val description: String,
    @ColumnInfo(name = "is_granted")
    val isGranted: Boolean = true,
    @ColumnInfo(name = "granted_at")
    val grantedAt: Long = System.currentTimeMillis()
)
