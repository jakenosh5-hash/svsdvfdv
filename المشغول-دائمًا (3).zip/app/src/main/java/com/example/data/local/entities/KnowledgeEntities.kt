package com.example.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents a high-level Knowledge Index (فهرس المعرفة), created autonomously
 * by the AI Brain or pre-seeded (e.g. "عمل المستخدم", "الزراعة", "المشاريع", "المالية والديون").
 */
@Entity(
    tableName = "knowledge_indexes",
    indices = [
        Index(value = ["name"], unique = true, name = "idx_indexes_name")
    ]
)
data class KnowledgeIndexEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String? = null,
    @ColumnInfo(name = "icon_name")
    val iconName: String = "folder",
    @ColumnInfo(name = "color_hex")
    val colorHex: String = "#3F51B5",
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Represents a Section/Chapter (باب المعرفة) residing under a specific Knowledge Index.
 * (e.g. Under "عمل المستخدم" -> "باب الزراعة", "ملاحظات الاجتماعات", "محاصيل القمح").
 */
@Entity(
    tableName = "knowledge_sections",
    foreignKeys = [
        ForeignKey(
            entity = KnowledgeIndexEntity::class,
            parentColumns = ["id"],
            childColumns = ["index_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["index_id"], name = "idx_sections_index_id"),
        Index(value = ["index_id", "name"], unique = true, name = "idx_sections_index_name")
    ]
)
data class KnowledgeSectionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "index_id")
    val indexId: Long,
    @ColumnInfo(name = "index_name")
    val indexName: String,
    val name: String,
    val description: String? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Represents a Distilled Memory Entry (الذاكرة المقطرة / الخلاصة التراكمية).
 * Generated automatically by the AI Brain in every interaction.
 * Stored concisely without assumptions, categorized under an Index and a Section.
 */
@Entity(
    tableName = "knowledge_memories",
    foreignKeys = [
        ForeignKey(
            entity = KnowledgeSectionEntity::class,
            parentColumns = ["id"],
            childColumns = ["section_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["section_id"], name = "idx_memories_section_id"),
        Index(value = ["index_name"], name = "idx_memories_index_name"),
        Index(value = ["created_at"], name = "idx_memories_created_at")
    ]
)
data class KnowledgeMemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "section_id")
    val sectionId: Long,
    @ColumnInfo(name = "index_name")
    val indexName: String,
    @ColumnInfo(name = "section_name")
    val sectionName: String,
    val query: String,
    val summary: String,
    @ColumnInfo(name = "full_context")
    val fullContext: String? = null,
    val importance: Int = 5, // 1 (minor note) to 10 (crucial rule/fact)
    val tags: String = "",
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)
