package com.example.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.domain.models.TaskPriority
import com.example.domain.models.TaskStatus
import com.example.domain.models.TimeHorizon

@Entity(
    tableName = "projects",
    indices = [
        Index(value = ["status"], name = "idx_projects_status"),
        Index(value = ["updated_at"], name = "idx_projects_updated_at")
    ]
)
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String? = null,
    @ColumnInfo(name = "color_hex")
    val colorHex: String = "#2E7D32",
    @ColumnInfo(name = "icon_name")
    val iconName: String = "folder",
    val status: String = "ACTIVE", // ACTIVE, COMPLETED, ARCHIVED, ON_HOLD
    @ColumnInfo(name = "target_end_date")
    val targetEndDate: Long? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(
            entity = TaskEntity::class,
            parentColumns = ["id"],
            childColumns = ["parent_task_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.SET_NULL
        ),
        ForeignKey(
            entity = TaskTemplateEntity::class,
            parentColumns = ["id"],
            childColumns = ["template_id"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["parent_task_id"], name = "idx_tasks_parent_id"),
        Index(value = ["project_id"], name = "idx_tasks_project_id"),
        Index(value = ["template_id"], name = "idx_tasks_template_id"),
        Index(value = ["status", "due_date"], name = "idx_tasks_status_due"),
        Index(value = ["time_horizon"], name = "idx_tasks_time_horizon")
    ]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "parent_task_id")
    val parentTaskId: Long? = null,
    @ColumnInfo(name = "project_id")
    val projectId: Long? = null,
    @ColumnInfo(name = "template_id")
    val templateId: Long? = null,
    val title: String,
    val description: String? = null,
    @ColumnInfo(name = "time_horizon")
    val timeHorizon: TimeHorizon = TimeHorizon.DAILY,
    val priority: TaskPriority = TaskPriority.IMPORTANT_NOT_URGENT,
    val status: TaskStatus = TaskStatus.PENDING,
    @ColumnInfo(name = "due_date")
    val dueDate: Long? = null,
    @ColumnInfo(name = "due_time_minutes")
    val dueTimeMinutes: Int? = null,
    @ColumnInfo(name = "duration_minutes")
    val durationMinutes: Int? = null,
    @ColumnInfo(name = "is_recurring")
    val isRecurring: Boolean = false,
    @ColumnInfo(name = "recurrence_rule")
    val recurrenceRule: String? = null,
    val tags: String? = null,
    @ColumnInfo(name = "sync_to_calendar")
    val syncToCalendar: Boolean = false,
    @ColumnInfo(name = "calendar_event_id")
    val calendarEventId: Long? = null,
    @ColumnInfo(name = "image_uri")
    val imageUri: String? = null,
    @ColumnInfo(name = "reminder_time")
    val reminderTime: Long? = null,
    @ColumnInfo(name = "is_reminder_enabled")
    val isReminderEnabled: Boolean = false,
    @ColumnInfo(name = "completed_at")
    val completedAt: Long? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)
