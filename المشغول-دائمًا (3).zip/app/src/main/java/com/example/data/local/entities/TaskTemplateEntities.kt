package com.example.data.local.entities

import androidx.room.*

/**
 * Entity representing a reusable Task Template (e.g. "العناية بالورد", "صيانة السيارة").
 * Stored in separate table `task_templates` as an architectural extension point.
 */
@Entity(
    tableName = "task_templates",
    indices = [
        Index(value = ["name"], unique = true, name = "idx_task_templates_name")
    ]
)
data class TaskTemplateEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String? = null,
    @ColumnInfo(name = "icon_name")
    val iconName: String = "spa",
    @ColumnInfo(name = "color_hex")
    val colorHex: String = "#2E7D32",
    @ColumnInfo(name = "auto_next_task_rule")
    val autoNextTaskRule: String? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Definition of a dynamic field inside a Task Template.
 * Stored in separate table `template_fields`.
 */
@Entity(
    tableName = "template_fields",
    foreignKeys = [
        ForeignKey(
            entity = TaskTemplateEntity::class,
            parentColumns = ["id"],
            childColumns = ["template_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["template_id"], name = "idx_template_fields_template_id"),
        Index(value = ["template_id", "field_key"], unique = true, name = "idx_template_fields_key_unique")
    ]
)
data class TemplateFieldEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "template_id")
    val templateId: Long,
    @ColumnInfo(name = "field_name")
    val fieldName: String,
    @ColumnInfo(name = "field_key")
    val fieldKey: String,
    @ColumnInfo(name = "field_type")
    val fieldType: String, // TEXT, LONG_TEXT, NUMBER, MEASUREMENT, SLIDER, SCALE_1_10, SINGLE_CHOICE, MULTI_CHOICE, DATE, TIME, BOOLEAN, IMAGE, DROPDOWN
    val unit: String? = null, // e.g. "سم", "كغ", "لتر", "كم"
    @ColumnInfo(name = "min_value")
    val minValue: Double? = null,
    @ColumnInfo(name = "max_value")
    val maxValue: Double? = null,
    @ColumnInfo(name = "step_value")
    val stepValue: Double? = null,
    @ColumnInfo(name = "options_json")
    val optionsJson: String? = null, // JSON array of options for choice/dropdown fields
    @ColumnInfo(name = "is_required")
    val isRequired: Boolean = false,
    @ColumnInfo(name = "display_order")
    val displayOrder: Int = 0
)

/**
 * Stored custom values for each task instance created from a template.
 * Stored in separate table `task_custom_values`.
 */
@Entity(
    tableName = "task_custom_values",
    foreignKeys = [
        ForeignKey(
            entity = TaskEntity::class,
            parentColumns = ["id"],
            childColumns = ["task_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TemplateFieldEntity::class,
            parentColumns = ["id"],
            childColumns = ["field_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["task_id"], name = "idx_custom_values_task_id"),
        Index(value = ["field_id"], name = "idx_custom_values_field_id"),
        Index(value = ["task_id", "field_id"], unique = true, name = "idx_custom_values_unique_task_field")
    ]
)
data class TaskCustomValueEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "task_id")
    val taskId: Long,
    @ColumnInfo(name = "field_id")
    val fieldId: Long,
    @ColumnInfo(name = "value_text")
    val valueText: String? = null,
    @ColumnInfo(name = "value_number")
    val valueNumber: Double? = null,
    @ColumnInfo(name = "value_date")
    val valueDate: Long? = null,
    @ColumnInfo(name = "raw_json_value")
    val rawJsonValue: String? = null
)
