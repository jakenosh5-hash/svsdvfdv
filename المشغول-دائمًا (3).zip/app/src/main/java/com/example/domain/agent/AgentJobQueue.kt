package com.example.domain.agent

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.AlwaysBusyApp
import com.example.data.local.entities.AgentJobEntity
import kotlinx.coroutines.flow.collect
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AgentJobQueue(private val context: Context) {
    private val dao = (context.applicationContext as AlwaysBusyApp).container.database.agentRuntimeDao()

    suspend fun enqueue(
        persona: String,
        kind: String,
        payload: JSONObject,
        idempotencyKey: String,
        conversationId: Long? = null,
        availableAt: Long = System.currentTimeMillis()
    ): Long {
        require(persona == "REM" || persona == "RAM")
        val existing = dao.getJobByIdempotencyKey(idempotencyKey)
        if (existing != null) return existing.id
        val id = dao.insertJob(
            AgentJobEntity(
                persona = persona,
                kind = kind,
                conversationId = conversationId,
                payloadJson = payload.toString(),
                availableAt = availableAt,
                idempotencyKey = idempotencyKey
            )
        )
        if (id <= 0L) return dao.getJobByIdempotencyKey(idempotencyKey)?.id ?: error("Unable to enqueue durable agent job")
        val delay = (availableAt - System.currentTimeMillis()).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<AgentJobWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(androidx.work.workDataOf("job_id" to id))
            .addTag("agent-job:$id")
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork("agent-job:$id", ExistingWorkPolicy.KEEP, request)
        return id
    }
}

class AgentJobWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        val app = applicationContext as AlwaysBusyApp
        val dao = app.container.database.agentRuntimeDao()
        val jobId = inputData.getLong("job_id", -1L)
        val job = dao.getJob(jobId) ?: return Result.success()
        if (job.status == "DONE" || job.status == "DEAD_LETTER") return Result.success()
        dao.updateJob(job.id, "RUNNING", job.attempts + 1, null)
        return try {
            val payload = JSONObject(job.payloadJson)
            val conversationId = job.conversationId ?: payload.optLong("conversation_id", 0L)
            val event = payload.optString("event")
            val prompt = if (event.isNotBlank()) {
                when (event) {
                    "REMOTE_INPUT" -> payload.optString("reply")
                    "USER_BUSY" -> "المستخدم مشغول الآن. أعد تقييم الخطة وأجل المتابعة دون افتراضات."
                    "SNOOZE" -> "أعاد المستخدم جدولة المتابعة. أنشئ خطة زمنية جديدة مناسبة."
                    "MARK_AS_READ" -> "تمت قراءة الإشعار. حدّث حالة الخطة فقط دون إرسال رسالة إضافية."
                    else -> ""
                }
            } else payload.optString("prompt")
            if (conversationId > 0L && prompt.isNotBlank()) {
                app.container.autonomousAgentCoordinator.processUserMessage(conversationId, prompt).collect { }
            }
            dao.updateJob(job.id, "DONE", job.attempts + 1, null)
            Result.success()
        } catch (t: Throwable) {
            val nextAttempt = job.attempts + 1
            val terminal = nextAttempt >= 5
            dao.updateJob(job.id, if (terminal) "DEAD_LETTER" else "RETRY", nextAttempt, t.message)
            if (terminal) Result.failure() else Result.retry()
        }
    }
}
