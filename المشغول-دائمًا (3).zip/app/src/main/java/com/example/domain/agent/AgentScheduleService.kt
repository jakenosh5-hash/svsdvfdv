package com.example.domain.agent

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.AlwaysBusyApp
import com.example.data.local.entities.ScheduledAgentTaskEntity
import com.example.services.AgentAlarmReceiver
import org.json.JSONObject

class AgentScheduleService(private val context: Context) {
    private val app = context.applicationContext as AlwaysBusyApp
    private val dao = app.container.database.agentRuntimeDao()
    private val queue = AgentJobQueue(context)

    suspend fun schedule(
        persona: String,
        prompt: String,
        dueAt: Long,
        idempotencyKey: String
    ): Long {
        require(dueAt > System.currentTimeMillis())
        require(persona == "REM" || persona == "RAM")
        val existing = dao.getScheduledByIdempotencyKey(idempotencyKey)
        if (existing != null) return existing.id
        val scheduledId = dao.insertScheduled(
            ScheduledAgentTaskEntity(
                persona = persona,
                prompt = prompt,
                dueAt = dueAt,
                idempotencyKey = idempotencyKey
            )
        )
        val task = if (scheduledId > 0) scheduledId else dao.getScheduledByIdempotencyKey(idempotencyKey)?.id ?: error("Unable to persist schedule")
        val jobId = queue.enqueue(
            persona = persona,
            kind = "SCHEDULED_AGENT_TASK",
            payload = JSONObject().put("prompt", prompt).put("scheduled_task_id", task),
            idempotencyKey = "schedule:$task",
            availableAt = dueAt
        )
        scheduleAlarm(jobId, dueAt)
        return task
    }

    private fun scheduleAlarm(jobId: Long, dueAt: Long) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, AgentAlarmReceiver::class.java).putExtra("job_id", jobId)
        val pending = PendingIntent.getBroadcast(context, jobId.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (android.os.Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pending)
        } else {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pending)
        }
    }
}
