package com.example.domain.agent

import com.example.data.local.dao.AiDao
import com.example.data.local.entities.AiMessageEntity
import com.example.domain.command.CommandBus
import com.example.domain.command.CommandParser
import com.example.domain.gateway.AiToolCallDispatcher
import com.example.domain.gateway.ToolCallingSchemas
import com.example.domain.knowledge.AutonomousKnowledgeService
import com.example.domain.memory.CumulativeMemoryEngine
import com.example.network.LlmApiClient
import com.example.security.AiPreferences
import com.example.services.IAuditService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Orchestrates the full Agent Loop:
 * - AI Cognitive Brain (Grok / OpenAI / Gemini)
 * - Autonomous Executive Arm (CommandBus + Room Knowledge Base)
 * - Multi-turn search, memory distillation, and silent app execution.
 */
class AutonomousAgentCoordinator(
    private val aiDao: AiDao,
    private val knowledgeService: AutonomousKnowledgeService,
    private val commandBus: CommandBus,
    private val toolCallDispatcher: AiToolCallDispatcher,
    private val auditService: IAuditService,
    private val aiPreferences: AiPreferences,
    private val llmClient: LlmApiClient,
    private val memoryEngine: CumulativeMemoryEngine
) {

    sealed class AgentStatus {
        data class Thinking(val message: String = "العقل الذكي يفكر ويحلل الفهارس...") : AgentStatus()
        data class SearchingMemory(val query: String) : AgentStatus()
        data class ExecutingCommand(val action: String) : AgentStatus()
        data class NeedsConfirmation(val command: String, val reason: String) : AgentStatus()
        data class DistillingMemory(val section: String) : AgentStatus()
        data class Success(val turnResponse: AgentTurnResponse) : AgentStatus()
        data class Error(val errorMessage: String) : AgentStatus()
    }

    data class AgentTurnResponse(
        val assistantMessage: String,
        val executedActions: List<String>,
        val storedMemories: List<String>,
        val isAutonomousCloud: Boolean
    )

    /**
     * Executes a full conversation turn with streaming progress status.
     */
    fun processUserMessage(
        conversationId: Long,
        userQuery: String,
        replyToMessage: AiMessageEntity? = null
    ): Flow<AgentStatus> = flow {
        val trimmedQuery = userQuery.trim()
        if (trimmedQuery.isEmpty()) return@flow

        val conv = aiDao.getConversationById(conversationId)
        val activePersona = conv?.persona ?: aiPreferences.activePersona

        // 1. Save user message to database with optional reply quote
        aiDao.insertMessage(
            AiMessageEntity(
                conversationId = conversationId,
                sender = "USER",
                content = trimmedQuery,
                replyToId = replyToMessage?.id,
                replyToText = replyToMessage?.content?.take(150),
                replyToSender = replyToMessage?.sender
            )
        )

        // Automatically update conversation title from first query if still default
        if (conv != null && (conv.title == "محادثة جديدة" || conv.title == "محادثة الذكاء الاصطناعي" || conv.title == "جلسة تفكير وتنفيذ جديدة")) {
            val titleSnippet = if (trimmedQuery.length > 32) trimmedQuery.take(29) + "..." else trimmedQuery
            aiDao.updateConversation(conv.copy(title = titleSnippet, updatedAt = System.currentTimeMillis()))
        }

        emit(AgentStatus.Thinking())

        val isConfigured = aiPreferences.isConfigured

        if (isConfigured) {
            // --- Live Cloud AI Brain (Grok / OpenAI / Gemini) ---
            try {
                val knowledgeCatalog = knowledgeService.buildKnowledgeCatalogPrompt()
                val liveContext = memoryEngine.buildAgentContextPrompt(trimmedQuery)
                val systemPrompt = AutonomousAgentProtocolEngine.buildSystemPrompt(
                    persona = activePersona,
                    knowledgeCatalog = knowledgeCatalog,
                    auditSummary = liveContext,
                    userPreferencesSummary = "استخرج التفضيلات من السياق الحي ولا تفترض قيماً غير موجودة."
                )

                // Build conversation history
                val pastMessages = aiDao.getMessagesList(conversationId).takeLast(10)
                val chatMessages = mutableListOf<LlmApiClient.ChatMessage>()
                chatMessages.add(LlmApiClient.ChatMessage(role = "system", content = systemPrompt))
                for (m in pastMessages) {
                    val role = if (m.sender == "USER") "user" else "assistant"
                    val quotedPrefix = if (m.replyToText != null) "[رد على: ${m.replyToSender}: \"${m.replyToText}\"]\n" else ""
                    chatMessages.add(LlmApiClient.ChatMessage(role = role, content = quotedPrefix + m.content))
                }

                val structuredTurn = runStructuredToolLoop(conversationId, activePersona, chatMessages)
                if (structuredTurn != null) {
                    emit(AgentStatus.Success(structuredTurn))
                    return@flow
                }

                // Call LLM
                val firstResponseResult = llmClient.sendChatCompletionForPersona(activePersona, chatMessages)
                if (firstResponseResult.isFailure) {
                    val err = firstResponseResult.exceptionOrNull()?.message ?: "فشل الاتصال بالذكاء الاصطناعي."
                    emit(AgentStatus.Error(err))
                    return@flow
                }

                val firstRawResponse = firstResponseResult.getOrThrow()
                var parseResult = AutonomousAgentProtocolEngine.parseResponse(firstRawResponse)
                // Bound model output before it reaches the local execution arm. This
                // prevents malformed/repetitive generations from causing an action storm.
                val allActions = mutableListOf<AutonomousAgentProtocolEngine.AgentAction>()
                allActions.addAll(parseResult.actions.distinct().take(MAX_ACTIONS_PER_TURN))

                // Check for multi-turn search/fetch requirement
                if (parseResult.requiresFollowUp && parseResult.searchOrFetchAction != null) {
                    val action = parseResult.searchOrFetchAction
                    val searchSummary = when (action) {
                        is AutonomousAgentProtocolEngine.AgentAction.IndexSearch -> {
                            emit(AgentStatus.SearchingMemory(action.query))
                            val matches = knowledgeService.searchMemories(action.query)
                            if (matches.isEmpty()) {
                                "لم يتم العثور على نتائج مطابقة لكلمة [${action.query}] في الفهارس الحالية."
                            } else {
                                matches.joinToString("\n") {
                                    "• [فهرس: ${it.indexName} > باب: ${it.sectionName}]: ${it.summary}"
                                }
                            }
                        }
                        is AutonomousAgentProtocolEngine.AgentAction.IndexFetch -> {
                            emit(AgentStatus.SearchingMemory("${action.indexName} > ${action.sectionName}"))
                            val matches = knowledgeService.fetchSectionMemories(action.indexName, action.sectionName)
                            if (matches.isEmpty()) {
                                "الباب فارغ حالياً."
                            } else {
                                matches.joinToString("\n") { "• [أهمية ${it.importance}/10]: ${it.summary}" }
                            }
                        }
                        else -> ""
                    }

                    // Feed back observation to AI Brain
                    chatMessages.add(LlmApiClient.ChatMessage(role = "assistant", content = firstRawResponse))
                    chatMessages.add(
                        LlmApiClient.ChatMessage(
                            role = "user",
                            content = """[BOT_OBSERVATION: نتائج البحث في الذاكرة التراكمية]:
$searchSummary
الرجاء صياغة جوابك الاستشاري النهائي للمستخدم داخل <<<USER_MESSAGE>>>، وأي أوامر إضافية للبوت التنفيذي داخل <<<BOT_ACTIONS>>>."""
                        )
                    )

                    emit(AgentStatus.Thinking("العقل الذكي يحلل الحقائق المسترجعة ويصيغ الرد..."))
                    val finalResponseResult = llmClient.sendChatCompletionForPersona(activePersona, chatMessages)
                    if (finalResponseResult.isSuccess) {
                        val secondParse = AutonomousAgentProtocolEngine.parseResponse(finalResponseResult.getOrThrow())
                        parseResult = secondParse
                        allActions.addAll(secondParse.actions)
                        val bounded = allActions.distinct().take(MAX_ACTIONS_PER_TURN)
                        allActions.clear()
                        allActions.addAll(bounded)
                    }
                }

                // Execute all background actions requested by the AI Brain across turns
                val executedLog = mutableListOf<String>()
                val memoryLog = mutableListOf<String>()

                for (act in allActions) {
                    when (act) {
                        is AutonomousAgentProtocolEngine.AgentAction.IndexCreate -> {
                            knowledgeService.getOrCreateSubIndex(act.indexName, act.description)
                            executedLog.add("إنشاء فهرس: ${act.indexName}")
                        }
                        is AutonomousAgentProtocolEngine.AgentAction.SectionCreate -> {
                            knowledgeService.getOrCreateSection(act.indexName, act.sectionName, act.description)
                            executedLog.add("إنشاء باب: ${act.indexName} > ${act.sectionName}")
                        }
                        is AutonomousAgentProtocolEngine.AgentAction.MemoryStore -> {
                            emit(AgentStatus.DistillingMemory(act.sectionName))
                            knowledgeService.storeDistilledMemory(
                                indexName = act.indexName,
                                sectionName = act.sectionName,
                                query = act.query.ifBlank { trimmedQuery },
                                summary = act.summary,
                                importance = act.importance,
                                tags = act.tags
                            )
                            memoryLog.add("${act.indexName} > ${act.sectionName}: ${act.summary}")
                        }
                        is AutonomousAgentProtocolEngine.AgentAction.AppExecute -> {
                            emit(AgentStatus.ExecutingCommand(act.command))
                            val cmd = runCatching { CommandParser.parse(act.command) }.getOrNull()
                            if (cmd != null) {
                                val result = commandBus.execute(cmd, actor = com.example.domain.models.AuditActor.AI_AGENT)
                                executedLog.add("${act.command} — ${if (result.isSuccess) "نجح" else "فشل"}: ${result.outputUser}")
                            } else {
                                executedLog.add("${act.command} — فشل: تعذر تحليل الأمر")
                            }
                        }
                        else -> { /* handled above */ }
                    }
                }

                // If the AI didn't emit a MEMORY_STORE, auto-synthesize one so no interaction is lost
                // Do not store assistant prose as long-term memory. Only explicit
                // MEMORY_STORE actions or verified user facts are durable memories.

                // Save Assistant message to Room
                val finalAssistantText = parseResult.userMessage.ifBlank {
                    "تم تنفيذ طلبك بنجاح وحفظ الذاكرة التراكمية في الفهارس."
                } + if (executedLog.isNotEmpty()) {
                    "\n\nنتيجة التنفيذ الفعلية من التطبيق:\n" + executedLog.joinToString("\n") { "• $it" }
                } else ""

                val executionJson = org.json.JSONArray().apply {
                    executedLog.forEach { put(it) }
                }.toString()

                aiDao.insertMessage(
                    AiMessageEntity(
                        conversationId = conversationId,
                        sender = if (activePersona.equals("RAM", ignoreCase = true)) "ASSISTANT_RAM" else "ASSISTANT_REM",
                        content = finalAssistantText,
                        toolCallsJson = org.json.JSONArray(allActions.filterIsInstance<AutonomousAgentProtocolEngine.AgentAction.AppExecute>().map { it.command }).toString(),
                        toolResultJson = executionJson
                    )
                )

                emit(
                    AgentStatus.Success(
                        AgentTurnResponse(
                            assistantMessage = finalAssistantText,
                            executedActions = executedLog,
                            storedMemories = memoryLog,
                            isAutonomousCloud = true
                        )
                    )
                )

            } catch (e: Exception) {
                emit(AgentStatus.Error(e.localizedMessage ?: "حدث استثناء أثناء تشغيل العقل الذكي."))
            }

        } else {
            // --- Local Executive Mode (API Key not yet configured in Settings) ---
            emit(AgentStatus.Thinking("تشغيل محرك الذاكرة المحلي (يرجى إدخال مفتاح API في الإعدادات للتفعيل السحابي الكامل)..."))

            // Check if user query matches any direct app command (e.g. "مهمة جديدة ...", "مصروف ...")
            val executedLog = mutableListOf<String>()
            val memoryLog = mutableListOf<String>()

            val directCmd = runCatching { CommandParser.parse(trimmedQuery) }.getOrNull()
            if (directCmd != null) {
                emit(AgentStatus.ExecutingCommand(trimmedQuery))
                val result = commandBus.execute(directCmd, actor = com.example.domain.models.AuditActor.AI_AGENT)
                executedLog.add("${directCmd.javaClass.simpleName} — ${if (result.isSuccess) "نجح" else "فشل"}: ${result.outputUser}")
            }

            // Search local knowledge base for relevant context
            val matchingMemories = knowledgeService.searchMemories(trimmedQuery)
            val memoryContext = if (matchingMemories.isNotEmpty()) {
                "وجدت في ذاكرتك التراكمية:\n" + matchingMemories.take(3).joinToString("\n") { "• [${it.indexName} > ${it.sectionName}]: ${it.summary}" }
            } else {
                "لا توجد مدخلات سابقة مطابقة في الفهارس."
            }

            // Persist only explicit user facts/decisions, never every question.
            if (looksLikeDurableUserFact(trimmedQuery)) {
                val shortSummary = if (trimmedQuery.length > 120) trimmedQuery.take(117) + "..." else trimmedQuery
                knowledgeService.storeDistilledMemory(
                    indexName = "عمل المستخدم",
                    sectionName = "تفضيلات وقرارات مؤكدة",
                    query = trimmedQuery,
                    summary = shortSummary,
                    importance = 5
                )
                memoryLog.add("عمل المستخدم > تفضيلات وقرارات مؤكدة: $shortSummary")
            }

            val assistantReply = buildString {
                if (activePersona.equals("RAM", ignoreCase = true)) {
                    appendLine("تحليل أولي للمدخلات 🌸:")
                    appendLine("«$trimmedQuery»")
                    appendLine("\n1. التفكيك المنطقي:")
                    appendLine("• الفكرة الأساسية واضحة، لكن التنفيذ الفعلي يتطلب حزماً ودقة، لا أمنيات فضفاضة.")
                    if (executedLog.isNotEmpty()) {
                        appendLine("\n2. الإجراءات المباشرة المنفذة:")
                        executedLog.forEach { appendLine("• $it") }
                    }
                    appendLine("\n3. السياق والذاكرة:")
                    appendLine(memoryContext)
                    appendLine("\n💡 خلاصة رام: تم توثيق الفكرة ومتابعتها، قم بالخطوة الأولى الآن دون تردد! 🌸😏")
                } else {
                    appendLine("تحليل استراتيجي لمطلب سيدي العزيز 💙:")
                    appendLine("«$trimmedQuery»")
                    appendLine("\n1. القراءة المنطقية للهدف:")
                    appendLine("• ريم حللت المسألة بعناية: سنبدأ بتنظيم الخطوات خطوة بخطوة ومن الصفر.")
                    if (executedLog.isNotEmpty()) {
                        appendLine("\n2. العمليات التنفيذية:")
                        executedLog.forEach { appendLine("• $it") }
                    }
                    appendLine("\n3. الفهارس والذاكرة التراكمية:")
                    appendLine(memoryContext)
                    appendLine("\n💡 خطة ريم: الخطوة الأولى موثقة وجاهزة للتنفيذ، وسأكون معك دائماً في كل خطوة! 💙✨")
                }
            }

            aiDao.insertMessage(
                AiMessageEntity(
                    conversationId = conversationId,
                    sender = if (activePersona.equals("RAM", ignoreCase = true)) "ASSISTANT_RAM" else "ASSISTANT_REM",
                    content = assistantReply,
                    toolResultJson = org.json.JSONArray(executedLog).toString()
                )
            )

            emit(
                AgentStatus.Success(
                    AgentTurnResponse(
                        assistantMessage = assistantReply,
                        executedActions = executedLog,
                        storedMemories = memoryLog,
                        isAutonomousCloud = false
                    )
                )
            )
        }
    }

    /** Executes a previously proposed sensitive command only after UI confirmation. */
    fun processConfirmedCommand(conversationId: Long, command: String): Flow<AgentStatus> = flow {
        emit(AgentStatus.ExecutingCommand(command))
        val result = runCatching { CommandParser.parse(command) }
            .fold(
                onSuccess = { parsed -> commandBus.execute(parsed, actor = com.example.domain.models.AuditActor.AI_AGENT) },
                onFailure = { error ->
                    com.example.domain.command.CommandResult(
                        isSuccess = false,
                        outputUser = "تعذر بناء الأمر المؤكد: ${error.message}",
                        outputJson = "{\"status\":\"error\",\"code\":\"PARSE_ERROR\"}",
                        actionType = "PARSE_ERROR",
                        errorCode = "PARSE_ERROR"
                    )
                }
            )
        val resultText = if (result.isSuccess) {
            "تم التنفيذ بعد تأكيدك:\n${result.outputUser}"
        } else {
            "لم يتم التنفيذ:\n${result.outputUser}"
        }
        val conv = aiDao.getConversationById(conversationId)
        val p = conv?.persona ?: aiPreferences.activePersona
        aiDao.insertMessage(
            AiMessageEntity(
                conversationId = conversationId,
                sender = if (p.equals("RAM", ignoreCase = true)) "ASSISTANT_RAM" else "ASSISTANT_REM",
                content = resultText,
                toolCallsJson = "{\"command\":${org.json.JSONObject.quote(command)}}",
                toolResultJson = result.outputJson
            )
        )
        emit(
            AgentStatus.Success(
                AgentTurnResponse(
                    assistantMessage = resultText,
                    executedActions = listOf("$command (${if (result.isSuccess) "نجح" else "فشل"})"),
                    storedMemories = emptyList(),
                    isAutonomousCloud = aiPreferences.isConfigured
                )
            )
        )
    }

    private suspend fun runStructuredToolLoop(
        conversationId: Long,
        persona: String,
        initialMessages: List<LlmApiClient.ChatMessage>
    ): AgentTurnResponse? {
        var messages = initialMessages.toMutableList()
        val executed = mutableListOf<String>()
        val maxIterations = 8
        repeat(maxIterations) {
            val response = llmClient.sendToolChatCompletion(
                persona = persona,
                messages = messages,
                toolsJson = ToolCallingSchemas.getAllToolDefinitions(),
                toolChoice = "auto"
            ).getOrElse { return null }
            if (response.calls.isEmpty()) {
                val text = response.content?.trim().orEmpty()
                if (text.isBlank()) return null
                val id = aiDao.insertMessage(
                    AiMessageEntity(
                        conversationId = conversationId,
                        sender = if (persona.equals("RAM", ignoreCase = true)) "ASSISTANT_RAM" else "ASSISTANT_REM",
                        content = text,
                        toolResultJson = response.rawJson
                    )
                )
                return AgentTurnResponse(text, executed, emptyList(), true)
            }
            for (call in response.calls.distinctBy { it.id }) {
                val args = org.json.JSONObject(call.argumentsJson)
                val result = toolCallDispatcher.dispatchToolCall(
                    org.json.JSONObject().put("name", call.name).put("arguments", args).toString()
                )
                val resultJson = result.outputJson.ifBlank { org.json.JSONObject().put("status", if (result.isSuccess) "ok" else "error").toString() }
                executed += "${call.name}:${if (result.isSuccess) "ok" else "error"}"
                messages += LlmApiClient.ChatMessage(
                    role = "tool",
                    content = resultJson,
                    toolCallId = call.id,
                    name = call.name
                )
            }
        }
        return null
    }

    private companion object {
        const val MAX_ACTIONS_PER_TURN = 12

        fun looksLikeDurableUserFact(text: String): Boolean {
            val lower = text.lowercase()
            return listOf("أفضل", "افضل", "أحب", "احب", "لا أحب", "لا احب", "هدفي", "قررت", "سألتزم", "عادة", "دائما", "يوميا")
                .any { lower.contains(it) }
        }
    }
}
