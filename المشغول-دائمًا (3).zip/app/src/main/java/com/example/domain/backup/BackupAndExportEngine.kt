package com.example.domain.backup

import com.example.data.local.AppDatabase
import com.example.data.local.entities.*
import com.example.domain.models.CurrencyType
import com.example.domain.models.TaskPriority
import com.example.domain.models.TaskStatus
import com.example.domain.models.TimeHorizon
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupAndExportEngine(
    private val database: AppDatabase
) {

    data class ExportResult(
        val filename: String,
        val mimeType: String,
        val content: String,
        val checksumSha256: String
    )

    data class RestoreResult(
        val isSuccess: Boolean,
        val restoredEntitiesCount: Int,
        val message: String
    )

    suspend fun createFullJsonBackup(): ExportResult {
        val root = JSONObject()
        root.put("version", 2)
        root.put("app", "AlwaysBusyLifeOS")
        root.put("timestamp", System.currentTimeMillis())

        // 1. Projects
        val projects = database.projectDao().getAllProjects().first()
        val projectsArray = JSONArray()
        for (p in projects) {
            projectsArray.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("description", p.description)
                put("colorHex", p.colorHex)
                put("iconName", p.iconName)
                put("status", p.status)
            })
        }
        root.put("projects", projectsArray)

        // 2. Tasks
        val tasks = database.taskDao().getAllTasks().first()
        val tasksArray = JSONArray()
        for (t in tasks) {
            tasksArray.put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("description", t.description)
                put("priority", t.priority.name)
                put("status", t.status.name)
                put("timeHorizon", t.timeHorizon.name)
                put("durationMinutes", t.durationMinutes)
                put("tags", t.tags)
                put("projectId", t.projectId)
                put("parentTaskId", t.parentTaskId)
                put("templateId", t.templateId)
            })
        }
        root.put("tasks", tasksArray)

        // 3. Transactions
        val txs = database.financeDao().getAllTransactions().first()
        val txArray = JSONArray()
        for (tx in txs) {
            txArray.put(JSONObject().apply {
                put("id", tx.id)
                put("type", tx.type.name)
                put("amount", tx.amount)
                put("currency", tx.currency.name)
                put("categoryId", tx.categoryId)
                put("note", tx.note)
                put("transactionDate", tx.transactionDate)
            })
        }
        root.put("transactions", txArray)

        // 4. Debts
        val debts = database.debtDao().getAllDebts().first()
        val debtsArray = JSONArray()
        for (d in debts) {
            debtsArray.put(JSONObject().apply {
                put("id", d.id)
                put("type", d.type.name)
                put("personName", d.personName)
                put("originalAmount", d.originalAmount)
                put("remainingAmount", d.remainingAmount)
                put("currency", d.currency.name)
                put("status", d.status.name)
                put("note", d.note)
            })
        }
        root.put("debts", debtsArray)

        // 5. Notes
        val notes = database.noteDao().getActiveNotes().first()
        val notesArray = JSONArray()
        for (n in notes) {
            notesArray.put(JSONObject().apply {
                put("id", n.id)
                put("title", n.title)
                put("contentMarkdown", n.contentMarkdown)
                put("tags", n.tags)
                put("isPinned", n.isPinned)
            })
        }
        root.put("notes", notesArray)

        // 6. Memories
        val memories = database.aiDao().getAllMemoriesList()
        val memArray = JSONArray()
        for (m in memories) {
            memArray.put(JSONObject().apply {
                put("category", m.category)
                put("key", m.memoryKey)
                put("content", m.content)
                put("importance", m.importance)
            })
        }
        root.put("memories", memArray)

        val jsonString = root.toString(2)
        val checksum = calculateSha256(jsonString)
        val dateStr = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())

        return ExportResult(
            filename = "always_busy_backup_$dateStr.json",
            mimeType = "application/json",
            content = jsonString,
            checksumSha256 = checksum
        )
    }

    suspend fun exportFinanceCsv(): ExportResult {
        val txs = database.financeDao().getAllTransactions().first()
        val categories = database.financeDao().getAllCategories().first().associateBy { it.id }
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

        val sb = StringBuilder()
        sb.append("ID,Date,Type,Category,Amount,Currency,Note\n")
        for (tx in txs) {
            val catName = categories[tx.categoryId]?.name ?: "عام"
            val dateStr = dateFormat.format(Date(tx.transactionDate))
            sb.append("${tx.id},\"$dateStr\",${tx.type.name},\"$catName\",${tx.amount},${tx.currency.name},\"${tx.note ?: ""}\"\n")
        }

        val content = sb.toString()
        val checksum = calculateSha256(content)
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

        return ExportResult(
            filename = "financial_statement_$dateStr.csv",
            mimeType = "text/csv",
            content = content,
            checksumSha256 = checksum
        )
    }

    suspend fun exportTasksCsv(): ExportResult {
        val tasks = database.taskDao().getAllTasks().first()
        val sb = StringBuilder()
        sb.append("ID,Title,Priority,Status,Horizon,DurationMinutes,Tags\n")
        for (t in tasks) {
            sb.append("${t.id},\"${t.title.replace("\"", "\"\"")}\",${t.priority.name},${t.status.name},${t.timeHorizon.name},${t.durationMinutes ?: 0},\"${t.tags ?: ""}\"\n")
        }

        val content = sb.toString()
        val checksum = calculateSha256(content)
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

        return ExportResult(
            filename = "tasks_export_$dateStr.csv",
            mimeType = "text/csv",
            content = content,
            checksumSha256 = checksum
        )
    }

    suspend fun restoreFullJsonBackup(jsonString: String): RestoreResult {
        return try {
            val root = JSONObject(jsonString)
            if (!root.has("app") || root.getString("app") != "AlwaysBusyLifeOS") {
                return RestoreResult(false, 0, "الملف غير صالح: لا ينتمي لتطبيق المشغول دائمًا.")
            }

            var restoredCount = 0

            // 1. Restore Tasks
            if (root.has("tasks")) {
                val tasksArray = root.getJSONArray("tasks")
                for (i in 0 until tasksArray.length()) {
                    val obj = tasksArray.getJSONObject(i)
                    val prio = runCatching { TaskPriority.valueOf(obj.optString("priority", "IMPORTANT_NOT_URGENT")) }.getOrDefault(TaskPriority.IMPORTANT_NOT_URGENT)
                    val status = runCatching { TaskStatus.valueOf(obj.optString("status", "PENDING")) }.getOrDefault(TaskStatus.PENDING)
                    val horizon = runCatching { TimeHorizon.valueOf(obj.optString("timeHorizon", "DAILY")) }.getOrDefault(TimeHorizon.DAILY)

                    val entity = TaskEntity(
                        title = obj.getString("title"),
                        description = obj.optString("description", null),
                        priority = prio,
                        status = status,
                        timeHorizon = horizon,
                        durationMinutes = if (obj.has("durationMinutes")) obj.getInt("durationMinutes") else null,
                        tags = obj.optString("tags", null),
                        projectId = if (obj.has("projectId")) obj.getLong("projectId") else null
                    )
                    database.taskDao().insertTask(entity)
                    restoredCount++
                }
            }

            // 2. Restore Notes
            if (root.has("notes")) {
                val notesArray = root.getJSONArray("notes")
                for (i in 0 until notesArray.length()) {
                    val obj = notesArray.getJSONObject(i)
                    val note = NoteEntity(
                        title = obj.getString("title"),
                        contentMarkdown = obj.getString("contentMarkdown"),
                        tags = obj.optString("tags", null),
                        isPinned = obj.optBoolean("isPinned", false)
                    )
                    database.noteDao().insertNote(note)
                    restoredCount++
                }
            }

            // 3. Restore Memories
            if (root.has("memories")) {
                val memArray = root.getJSONArray("memories")
                for (i in 0 until memArray.length()) {
                    val obj = memArray.getJSONObject(i)
                    val mem = AiMemoryItemEntity(
                        category = obj.getString("category"),
                        memoryKey = obj.getString("key"),
                        content = obj.getString("content"),
                        importance = obj.optInt("importance", 3)
                    )
                    database.aiDao().insertOrUpdateMemory(mem)
                    restoredCount++
                }
            }

            RestoreResult(
                isSuccess = true,
                restoredEntitiesCount = restoredCount,
                message = "تمت استعادة $restoredCount عنصراً بنجاح ومطابقتها في قاعدة البيانات."
            )
        } catch (e: Exception) {
            RestoreResult(
                isSuccess = false,
                restoredEntitiesCount = 0,
                message = "فشل استيراد النسخة الاحتياطية: ${e.message}"
            )
        }
    }

    private fun calculateSha256(text: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(text.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }
}
