package com.example.domain.command

import com.example.domain.models.CurrencyType
import com.example.domain.models.DebtType
import com.example.domain.models.GoalHorizon
import com.example.domain.models.TaskPriority
import com.example.domain.models.TimeHorizon

sealed class AppCommand {
    abstract val requiredScope: String

    // --- Task Commands ---
    data class TaskAdd(
        val title: String,
        val description: String? = null,
        val priority: TaskPriority = TaskPriority.IMPORTANT_NOT_URGENT,
        val timeHorizon: TimeHorizon = TimeHorizon.DAILY,
        val dueDateEpoch: Long? = null,
        val durationMinutes: Int? = null,
        val tags: String? = null,
        val projectId: Long? = null,
        val parentTaskId: Long? = null
    ) : AppCommand() {
        override val requiredScope: String = "tasks:write"
    }

    data class TaskComplete(val taskId: Long) : AppCommand() {
        override val requiredScope: String = "tasks:write"
    }

    data class TaskDelete(val taskId: Long) : AppCommand() {
        override val requiredScope: String = "tasks:delete"
    }

    data class TaskList(val horizon: TimeHorizon? = null, val limit: Int = 20) : AppCommand() {
        override val requiredScope: String = "tasks:read"
    }

    // --- Project Commands ---
    data class ProjectAdd(
        val name: String,
        val description: String? = null,
        val colorHex: String = "#2E7D32",
        val iconName: String = "folder"
    ) : AppCommand() {
        override val requiredScope: String = "tasks:write"
    }

    data class ProjectList(val limit: Int = 20) : AppCommand() {
        override val requiredScope: String = "tasks:read"
    }

    // --- Finance Commands ---
    data class FinanceAdd(
        val isExpense: Boolean,
        val amount: Double,
        val currency: CurrencyType,
        val categoryName: String,
        val note: String? = null
    ) : AppCommand() {
        override val requiredScope: String = "finance:write"
    }

    data class FinanceBalance(val dummy: Unit = Unit) : AppCommand() {
        override val requiredScope: String = "finance:read"
    }

    data class FinanceRateUpdate(val rate: Double, val note: String? = null) : AppCommand() {
        override val requiredScope: String = "finance:write"
    }

    // --- Debt Commands ---
    data class DebtAdd(
        val type: DebtType,
        val personName: String,
        val amount: Double,
        val currency: CurrencyType = CurrencyType.SYP,
        val note: String? = null
    ) : AppCommand() {
        override val requiredScope: String = "debts:write"
    }

    data class DebtPay(
        val debtId: Long,
        val amount: Double,
        val note: String? = null
    ) : AppCommand() {
        override val requiredScope: String = "debts:write"
    }

    data class DebtList(val dummy: Unit = Unit) : AppCommand() {
        override val requiredScope: String = "debts:read"
    }

    // --- Note Commands ---
    data class NoteAdd(
        val title: String,
        val contentMarkdown: String,
        val tags: String? = null
    ) : AppCommand() {
        override val requiredScope: String = "notes:write"
    }

    data class NoteList(val query: String? = null) : AppCommand() {
        override val requiredScope: String = "notes:read"
    }

    // --- Goal Commands ---
    data class GoalAdd(
        val title: String,
        val description: String? = null,
        val horizon: GoalHorizon = GoalHorizon.MEDIUM_TERM,
        val targetValue: Double = 100.0
    ) : AppCommand() {
        override val requiredScope: String = "tasks:write"
    }

    // --- Memory Commands (Cumulative Memory) ---
    data class MemoryAdd(
        val category: String, // USER_PREFERENCE, HABIT, SEMANTIC_FACT, EPISODIC_SUMMARY
        val key: String,
        val content: String,
        val importance: Int = 3
    ) : AppCommand() {
        override val requiredScope: String = "notes:write"
    }

    data class MemoryList(val query: String? = null) : AppCommand() {
        override val requiredScope: String = "notes:read"
    }

    // --- Security & Audit Commands ---
    data class ScopeSet(val scopeName: String, val isGranted: Boolean) : AppCommand() {
        override val requiredScope: String = "audit:read"
    }

    data class ScopeList(val dummy: Unit = Unit) : AppCommand() {
        override val requiredScope: String = "audit:read"
    }

    data class AuditList(val limit: Int = 10) : AppCommand() {
        override val requiredScope: String = "audit:read"
    }

    // --- System / Terminal Utility Commands ---
    data class SystemSnapshot(val denseMode: Boolean = true) : AppCommand() {
        override val requiredScope: String = "tasks:read"
    }

    data class Help(val topic: String? = null) : AppCommand() {
        override val requiredScope: String = "tasks:read"
    }

    data class Clear(val dummy: Unit = Unit) : AppCommand() {
        override val requiredScope: String = "tasks:read"
    }
}

data class CommandResult(
    val isSuccess: Boolean,
    val outputUser: String,
    val outputJson: String,
    val actionType: String,
    val affectedEntityId: Long? = null,
    val errorCode: String? = null
)
