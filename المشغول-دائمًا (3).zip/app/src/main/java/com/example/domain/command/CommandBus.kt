package com.example.domain.command

import com.example.domain.gateway.AppInternalGateway
import com.example.domain.models.AuditAction
import com.example.domain.models.AuditActor
import com.example.domain.models.CurrencyType
import com.example.domain.models.TaskStatus
import com.example.services.IAuditService
import com.example.services.ISecurityScopeService
import org.json.JSONArray
import org.json.JSONObject

class CommandBus(
    private val gateway: AppInternalGateway,
    private val securityScopeService: ISecurityScopeService,
    private val auditService: IAuditService
) {

    suspend fun execute(command: AppCommand, actor: AuditActor = AuditActor.COMMAND_TERMINAL): CommandResult {
        // 1. Security Scope Interception
        val isGranted = securityScopeService.isScopeGranted(command.requiredScope)
        if (!isGranted) {
            val errMsg = "تم رفض العملية أمنياً: الصلاحية '${command.requiredScope}' معطلة حالياً. يمكنك تفعيلها من إعدادات الأمان."
            val errJson = JSONObject().apply {
                put("status", "error")
                put("code", "SCOPE_REVOKED")
                put("required_scope", command.requiredScope)
                put("message", errMsg)
            }.toString()

            auditService.logEvent(
                entityType = "SECURITY_INTERCEPTOR",
                entityId = 0,
                action = AuditAction.UPDATE,
                actor = actor,
                payloadAfter = errJson
            )

            return CommandResult(
                isSuccess = false,
                outputUser = errMsg,
                outputJson = errJson,
                actionType = command::class.simpleName ?: "UNKNOWN",
                errorCode = "SCOPE_REVOKED"
            )
        }

        // 2. Execution Routing
        return try {
            when (command) {
                is AppCommand.TaskAdd -> handleTaskAdd(command, actor)
                is AppCommand.TaskComplete -> handleTaskComplete(command, actor)
                is AppCommand.TaskDelete -> handleTaskDelete(command, actor)
                is AppCommand.TaskList -> handleTaskList(command)
                is AppCommand.ProjectAdd -> handleProjectAdd(command, actor)
                is AppCommand.ProjectList -> handleProjectList(command)
                is AppCommand.FinanceAdd -> handleFinanceAdd(command, actor)
                is AppCommand.FinanceBalance -> handleFinanceBalance(command)
                is AppCommand.FinanceRateUpdate -> handleFinanceRateUpdate(command, actor)
                is AppCommand.DebtAdd -> handleDebtAdd(command, actor)
                is AppCommand.DebtPay -> handleDebtPay(command, actor)
                is AppCommand.DebtList -> handleDebtList(command)
                is AppCommand.NoteAdd -> handleNoteAdd(command, actor)
                is AppCommand.NoteList -> handleNoteList(command)
                is AppCommand.GoalAdd -> handleGoalAdd(command, actor)
                is AppCommand.MemoryAdd -> handleMemoryAdd(command, actor)
                is AppCommand.MemoryList -> handleMemoryList(command)
                is AppCommand.ScopeSet -> handleScopeSet(command, actor)
                is AppCommand.ScopeList -> handleScopeList(command)
                is AppCommand.AuditList -> handleAuditList(command)
                is AppCommand.SystemSnapshot -> handleSystemSnapshot(command)
                is AppCommand.Help -> handleHelp(command)
                is AppCommand.Clear -> CommandResult(true, "تم مسح الشاشة الطرفية.", "{\"status\":\"cleared\"}", "CLEAR")
            }
        } catch (e: Exception) {
            val errorJson = JSONObject().apply {
                put("status", "error")
                put("code", "EXECUTION_EXCEPTION")
                put("message", e.message ?: "خطأ غير متوقع أثناء التنفيذ")
            }.toString()
            CommandResult(
                isSuccess = false,
                outputUser = "حدث خطأ أثناء تنفيذ الأمر: ${e.message}",
                outputJson = errorJson,
                actionType = command::class.simpleName ?: "UNKNOWN",
                errorCode = "EXECUTION_EXCEPTION"
            )
        }
    }

    private suspend fun handleTaskAdd(cmd: AppCommand.TaskAdd, actor: AuditActor): CommandResult {
        val id = gateway.createTask(
            title = cmd.title,
            description = cmd.description,
            priority = cmd.priority,
            timeHorizon = cmd.timeHorizon,
            durationMinutes = cmd.durationMinutes,
            tags = cmd.tags,
            projectId = cmd.projectId
        )
        val json = JSONObject().apply {
            put("status", "success")
            put("task_id", id)
            put("title", cmd.title)
            put("priority", cmd.priority.labelArabic)
        }.toString()

        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم إنشاء المهمة بنجاح [ID: #$id]: \"${cmd.title}\" (${cmd.priority.labelArabic})",
            outputJson = json,
            actionType = "TASK_ADD",
            affectedEntityId = id
        )
    }

    private suspend fun handleTaskComplete(cmd: AppCommand.TaskComplete, actor: AuditActor): CommandResult {
        gateway.completeTask(cmd.taskId)
        val json = JSONObject().apply {
            put("status", "success")
            put("task_id", cmd.taskId)
            put("completed", true)
        }.toString()

        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم إنجاز المهمة بنجاح [#${cmd.taskId}]. هدوء البال في تزايد!",
            outputJson = json,
            actionType = "TASK_COMPLETE",
            affectedEntityId = cmd.taskId
        )
    }

    private suspend fun handleTaskDelete(cmd: AppCommand.TaskDelete, actor: AuditActor): CommandResult {
        gateway.deleteTask(cmd.taskId)
        val json = JSONObject().apply {
            put("status", "success")
            put("task_id", cmd.taskId)
            put("deleted", true)
        }.toString()

        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم حذف المهمة [#${cmd.taskId}] نهائياً.",
            outputJson = json,
            actionType = "TASK_DELETE",
            affectedEntityId = cmd.taskId
        )
    }

    private suspend fun handleTaskList(cmd: AppCommand.TaskList): CommandResult {
        val tasks = if (cmd.horizon != null) {
            gateway.getAllTasks().filter { it.timeHorizon == cmd.horizon }
        } else {
            gateway.getAllTasks()
        }.take(cmd.limit)

        val array = JSONArray()
        val textBuilder = StringBuilder()
        textBuilder.append("قائمة المهام (${tasks.size}):\n")

        for (t in tasks) {
            val statusMark = if (t.status == TaskStatus.COMPLETED) "✓" else "○"
            textBuilder.append("[$statusMark] #${t.id} ${t.title} [${t.priority.labelArabic}] ${if (t.durationMinutes != null) "(${t.durationMinutes} د)" else ""}\n")

            val obj = JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("status", t.status.name)
                put("priority", t.priority.name)
                put("horizon", t.timeHorizon.name)
            }
            array.put(obj)
        }

        return CommandResult(
            isSuccess = true,
            outputUser = textBuilder.toString().trimEnd(),
            outputJson = JSONObject().put("tasks", array).toString(),
            actionType = "TASK_LIST"
        )
    }

    private suspend fun handleProjectAdd(cmd: AppCommand.ProjectAdd, actor: AuditActor): CommandResult {
        val id = gateway.createProject(cmd.name, cmd.description, cmd.colorHex, cmd.iconName)
        val json = JSONObject().apply {
            put("status", "success")
            put("project_id", id)
            put("name", cmd.name)
        }.toString()
        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم إنشاء المشروع [#$id]: \"${cmd.name}\"",
            outputJson = json,
            actionType = "PROJECT_ADD",
            affectedEntityId = id
        )
    }

    private suspend fun handleProjectList(cmd: AppCommand.ProjectList): CommandResult {
        val projects = gateway.getProjects().take(cmd.limit)
        val array = JSONArray()
        val sb = StringBuilder("قائمة المشاريع النشطة (${projects.size}):\n")
        for (p in projects) {
            sb.append("• [#${p.id}] ${p.name} - ${p.description ?: "بدون وصف"}\n")
            array.put(JSONObject().put("id", p.id).put("name", p.name))
        }
        return CommandResult(
            isSuccess = true,
            outputUser = sb.toString().trimEnd(),
            outputJson = JSONObject().put("projects", array).toString(),
            actionType = "PROJECT_LIST"
        )
    }

    private suspend fun handleFinanceAdd(cmd: AppCommand.FinanceAdd, actor: AuditActor): CommandResult {
        val id = gateway.recordFinanceTransaction(
            isExpense = cmd.isExpense,
            amount = cmd.amount,
            currency = cmd.currency,
            categoryName = cmd.categoryName,
            note = cmd.note
        )
        val typeLabel = if (cmd.isExpense) "مصروف" else "إيراد"
        val currSymbol = cmd.currency.symbol

        val json = JSONObject().apply {
            put("status", "success")
            put("transaction_id", id)
            put("type", typeLabel)
            put("amount", cmd.amount)
            put("currency", cmd.currency.name)
        }.toString()

        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم تسجيل ال$typeLabel [#$id]: ${"%,.0f".format(cmd.amount)} $currSymbol [${cmd.categoryName}] ${if (cmd.note != null) "(${cmd.note})" else ""}",
            outputJson = json,
            actionType = "FINANCE_ADD",
            affectedEntityId = id
        )
    }

    private suspend fun handleFinanceBalance(cmd: AppCommand.FinanceBalance): CommandResult {
        val b = gateway.getBalanceSummary()
        val sb = StringBuilder()
        sb.append("الملخص المالي اللحظي:\n")
        sb.append("• صافي الليرة السورية: ${"%,.0f".format(b.sypNet)} ل.س (دخل: ${"%,.0f".format(b.sypIncome)} | صرف: ${"%,.0f".format(b.sypExpense)})\n")
        sb.append("• صافي الدولار: $${"%,.2f".format(b.usdNet)} (دخل: $${"%,.2f".format(b.usdIncome)} | صرف: $${"%,.2f".format(b.usdExpense)})")

        val json = JSONObject().apply {
            put("syp_net", b.sypNet)
            put("usd_net", b.usdNet)
        }.toString()

        return CommandResult(
            isSuccess = true,
            outputUser = sb.toString(),
            outputJson = json,
            actionType = "FINANCE_BALANCE"
        )
    }

    private suspend fun handleFinanceRateUpdate(cmd: AppCommand.FinanceRateUpdate, actor: AuditActor): CommandResult {
        val id = gateway.updateExchangeRate(cmd.rate, cmd.note)
        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم تحديث سعر الصرف اليدوي: 1 USD = ${"%,.0f".format(cmd.rate)} SYP",
            outputJson = JSONObject().put("rate", cmd.rate).toString(),
            actionType = "FINANCE_RATE_UPDATE",
            affectedEntityId = id
        )
    }

    private suspend fun handleDebtAdd(cmd: AppCommand.DebtAdd, actor: AuditActor): CommandResult {
        val id = gateway.createDebt(
            type = cmd.type,
            personName = cmd.personName,
            amount = cmd.amount,
            currency = cmd.currency,
            note = cmd.note
        )
        val json = JSONObject().apply {
            put("debt_id", id)
            put("type", cmd.type.name)
            put("person", cmd.personName)
            put("amount", cmd.amount)
        }.toString()

        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم تسجيل الدين [#$id]: ${cmd.type.labelArabic} لـ \"${cmd.personName}\" بمبلغ ${"%,.0f".format(cmd.amount)} ${cmd.currency.symbol}",
            outputJson = json,
            actionType = "DEBT_ADD",
            affectedEntityId = id
        )
    }

    private suspend fun handleDebtPay(cmd: AppCommand.DebtPay, actor: AuditActor): CommandResult {
        gateway.recordDebtPayment(cmd.debtId, cmd.amount, cmd.note)
        val json = JSONObject().apply {
            put("status", "success")
            put("debt_id", cmd.debtId)
            put("amount_paid", cmd.amount)
        }.toString()

        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم تسجيل دفعة سداد للدين [#${cmd.debtId}] بمبلغ ${"%,.0f".format(cmd.amount)}",
            outputJson = json,
            actionType = "DEBT_PAY",
            affectedEntityId = cmd.debtId
        )
    }

    private suspend fun handleDebtList(cmd: AppCommand.DebtList): CommandResult {
        val debts = gateway.getDebts()
        val array = JSONArray()
        val sb = StringBuilder("دفتر الديون القائمة (${debts.size}):\n")
        for (d in debts) {
            sb.append("• [#${d.id}] ${d.type.labelArabic} ${d.personName}: متبقي ${"%,.0f".format(d.remainingAmount)} ${d.currency.symbol} (${d.status.labelArabic})\n")
            array.put(JSONObject().put("id", d.id).put("person", d.personName).put("remaining", d.remainingAmount))
        }
        return CommandResult(
            isSuccess = true,
            outputUser = sb.toString().trimEnd(),
            outputJson = JSONObject().put("debts", array).toString(),
            actionType = "DEBT_LIST"
        )
    }

    private suspend fun handleNoteAdd(cmd: AppCommand.NoteAdd, actor: AuditActor): CommandResult {
        val id = gateway.saveNote(cmd.title, cmd.contentMarkdown, cmd.tags)
        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم حفظ الملاحظة المعرفية [#$id]: \"${cmd.title}\"",
            outputJson = JSONObject().put("note_id", id).toString(),
            actionType = "NOTE_ADD",
            affectedEntityId = id
        )
    }

    private suspend fun handleNoteList(cmd: AppCommand.NoteList): CommandResult {
        val notes = gateway.getNotes().filter { cmd.query == null || it.title.contains(cmd.query, true) || it.contentMarkdown.contains(cmd.query, true) }
        val sb = StringBuilder("الملاحظات المعرفية (${notes.size}):\n")
        val array = JSONArray()
        for (n in notes) {
            sb.append("• [#${n.id}] ${n.title} ${if (n.isPinned) "📌" else ""}\n")
            array.put(JSONObject().put("id", n.id).put("title", n.title))
        }
        return CommandResult(
            isSuccess = true,
            outputUser = sb.toString().trimEnd(),
            outputJson = JSONObject().put("notes", array).toString(),
            actionType = "NOTE_LIST"
        )
    }

    private suspend fun handleGoalAdd(cmd: AppCommand.GoalAdd, actor: AuditActor): CommandResult {
        val id = gateway.createTask(
            title = "[هدف] " + cmd.title,
            description = cmd.description,
            timeHorizon = com.example.domain.models.TimeHorizon.YEARLY
        )
        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم تسجيل الهدف الاستراتيجي [#$id]: \"${cmd.title}\"",
            outputJson = JSONObject().put("goal_id", id).toString(),
            actionType = "GOAL_ADD",
            affectedEntityId = id
        )
    }

    private suspend fun handleMemoryAdd(cmd: AppCommand.MemoryAdd, actor: AuditActor): CommandResult {
        val id = gateway.saveMemory(cmd.category, cmd.key, cmd.content, cmd.importance)
        return CommandResult(
            isSuccess = true,
            outputUser = "✓ تم حفظ بند الذاكرة التراكمية [#$id]: [${cmd.category}] \"${cmd.key}\" -> \"${cmd.content}\"",
            outputJson = JSONObject().put("memory_id", id).toString(),
            actionType = "MEMORY_ADD",
            affectedEntityId = id
        )
    }

    private suspend fun handleMemoryList(cmd: AppCommand.MemoryList): CommandResult {
        val mems = if (cmd.query != null) gateway.searchMemories(cmd.query) else gateway.getMemories()
        val sb = StringBuilder("عناصر الذاكرة التراكمية (${mems.size}):\n")
        val array = JSONArray()
        for (m in mems) {
            sb.append("• [${m.category} | أهمية:${m.importance}] ${m.memoryKey}: \"${m.content}\"\n")
            array.put(JSONObject().put("key", m.memoryKey).put("content", m.content))
        }
        return CommandResult(
            isSuccess = true,
            outputUser = sb.toString().trimEnd(),
            outputJson = JSONObject().put("memories", array).toString(),
            actionType = "MEMORY_LIST"
        )
    }

    private suspend fun handleScopeSet(cmd: AppCommand.ScopeSet, actor: AuditActor): CommandResult {
        gateway.setScope(cmd.scopeName, cmd.isGranted)
        val statusText = if (cmd.isGranted) "تم منح وتفعيل" else "تم سحب وتعطيل"
        return CommandResult(
            isSuccess = true,
            outputUser = "✓ $statusText الصلاحية الأمنية: '${cmd.scopeName}'",
            outputJson = JSONObject().put("scope", cmd.scopeName).put("granted", cmd.isGranted).toString(),
            actionType = "SCOPE_SET"
        )
    }

    private suspend fun handleScopeList(cmd: AppCommand.ScopeList): CommandResult {
        val scopes = gateway.getScopes()
        val sb = StringBuilder("الصلاحيات الأمنية للنظام:\n")
        val array = JSONArray()
        for (s in scopes) {
            val mark = if (s.isGranted) "✓ مفعلة" else "✗ معطلة"
            sb.append("• ${s.scopeName} [$mark] : ${s.description}\n")
            array.put(JSONObject().put("name", s.scopeName).put("granted", s.isGranted))
        }
        return CommandResult(
            isSuccess = true,
            outputUser = sb.toString().trimEnd(),
            outputJson = JSONObject().put("scopes", array).toString(),
            actionType = "SCOPE_LIST"
        )
    }

    private suspend fun handleAuditList(cmd: AppCommand.AuditList): CommandResult {
        val logs = gateway.getRecentAuditLogs(cmd.limit)
        val sb = StringBuilder("آخر عمليات سجل التدقيق (${logs.size}):\n")
        val array = JSONArray()
        for (l in logs) {
            sb.append("• [${l.actor.name}] ${l.action.name} on ${l.entityType} #${l.entityId}\n")
            array.put(JSONObject().put("id", l.id).put("entity", l.entityType).put("action", l.action.name))
        }
        return CommandResult(
            isSuccess = true,
            outputUser = sb.toString().trimEnd(),
            outputJson = JSONObject().put("logs", array).toString(),
            actionType = "AUDIT_LIST"
        )
    }

    private suspend fun handleSystemSnapshot(cmd: AppCommand.SystemSnapshot): CommandResult {
        val snapshotJson = gateway.getDenseSystemSnapshot()
        val parsed = JSONObject(snapshotJson)
        val calm = parsed.getInt("calm_score")
        val tasks = parsed.getInt("today_tasks_count")
        val sypNet = parsed.getJSONObject("balances").getDouble("syp_net")
        val usdNet = parsed.getJSONObject("balances").getDouble("usd_net")

        val sb = StringBuilder()
        sb.append("=== فهرس النظام اللحظي (Dense System Snapshot) ===\n")
        sb.append("• مؤشر الهدوء والسيطرة: $calm / 100\n")
        sb.append("• مهام اليوم: $tasks مهام\n")
        sb.append("• صافي الأرصدة: ${"%,.0f".format(sypNet)} ل.س | $${"%,.2f".format(usdNet)}\n")
        sb.append("• ملخص الديون: ${parsed.getJSONObject("debts_summary").getInt("active_count")} التزامات قائمة\n")
        sb.append("================================================")

        return CommandResult(
            isSuccess = true,
            outputUser = sb.toString(),
            outputJson = snapshotJson,
            actionType = "SYSTEM_SNAPSHOT"
        )
    }

    private fun handleHelp(cmd: AppCommand.Help): CommandResult {
        val helpText = """
دليل المحطة الطرفية والأوامر الذكية (LifeOS CLI):
--------------------------------------------------------
1. المهام (Tasks):
   • task add "العنوان" priority:high horizon:daily duration:30
   • task done [ID] (إنجاز مهمة)
   • task delete [ID] (حذف مهمة)
   • task list [today|week|month]

2. المالية (Finance):
   • finance expense 50000 currency:SYP category:طعام note:"غداء"
   • finance income 150 currency:USD category:"عمل حر"
   • balance (عرض الأرصدة اللحظية)
   • finance rate 14800 (تحديث سعر الصرف يدوياً)

3. الديون (Debts):
   • debt add owe "أحمد" 250000 currency:SYP note:"إيجار"
   • debt add to_me "سعيد" 100 currency:USD
   • debt pay [ID] [المبلغ]
   • debt list

4. الملاحظات والذاكرة (Notes & Cognitive Memory):
   • note add "العنوان" "المحتوى" tags:work
   • note list [كلمة بحث]
   • memory add pref "currency" "يفضل المستخدم الليرة السورية"
   • memory list

5. النظام والأمان (System & Security):
   • snapshot (فهرس النظام التكعيبي الموجز)
   • scope list (عرض الصلاحيات)
   • scope grant [scope] / scope revoke [scope]
   • audit [limit]
   • clear (مسح الشاشة)
--------------------------------------------------------
        """.trimIndent()

        return CommandResult(
            isSuccess = true,
            outputUser = helpText,
            outputJson = "{\"status\":\"help_rendered\"}",
            actionType = "HELP"
        )
    }
}
