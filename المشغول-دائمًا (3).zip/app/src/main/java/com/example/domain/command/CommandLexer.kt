package com.example.domain.command

/**
 * Tokenizes raw command text into structured tokens, supporting quotes (English & Arabic),
 * key-value pairs (key:value or key:"value with spaces"), and flags (--flag).
 */
object CommandLexer {

    data class Token(
        val raw: String,
        val isQuoted: Boolean = false,
        val key: String? = null,
        val value: String? = null,
        val isFlag: Boolean = false
    )

    fun tokenize(input: String): List<Token> {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return emptyList()

        val tokens = mutableListOf<Token>()
        val sb = StringBuilder()
        var inQuote = false
        var quoteChar = ' '
        var i = 0

        while (i < trimmed.length) {
            val c = trimmed[i]

            if (!inQuote && (c == '"' || c == '\'' || c == '«' || c == '“' || c == '”')) {
                inQuote = true
                quoteChar = if (c == '«') '»' else if (c == '“') '”' else c
                i++
                continue
            }

            if (inQuote && c == quoteChar) {
                inQuote = false
                tokens.add(Token(raw = sb.toString(), isQuoted = true))
                sb.clear()
                i++
                continue
            }

            if (!inQuote && Character.isWhitespace(c)) {
                if (sb.isNotEmpty()) {
                    tokens.add(parseUnquoted(sb.toString()))
                    sb.clear()
                }
                i++
                continue
            }

            sb.append(c)
            i++
        }

        if (sb.isNotEmpty()) {
            tokens.add(parseUnquoted(sb.toString()))
        }

        return tokens
    }

    private fun parseUnquoted(word: String): Token {
        if (word.startsWith("--")) {
            return Token(raw = word, isFlag = true, key = word.removePrefix("--"))
        }

        val colonIndex = word.indexOf(':')
        if (colonIndex > 0 && colonIndex < word.length - 1) {
            val k = word.substring(0, colonIndex).trim()
            val v = word.substring(colonIndex + 1).trim()
            return Token(raw = word, key = k, value = v)
        }

        return Token(raw = word)
    }
}
