package com.example.domain.command

import com.example.domain.models.*

object CommandParser {

    class ParseException(message: String) : Exception(message)

    fun parse(input: String): AppCommand {
        val tokens = CommandLexer.tokenize(input)
        if (tokens.isEmpty()) {
            throw ParseException("الأمر المدخل فارغ. اكتب help لعرض قائمة الأوامر المتاحة.")
        }

        val first = tokens[0].raw.lowercase()
        return when (first) {
            "help", "مساعدة", "?" -> parseHelp(tokens)
            "clear", "مسح", "cls" -> AppCommand.Clear()
            "snapshot", "فهرس", "status" -> AppCommand.SystemSnapshot()
            "balance", "رصيد" -> AppCommand.FinanceBalance()

            "task", "مهمة", "مهام" -> parseTask(tokens)
            "project", "مشروع" -> parseProject(tokens)
            "finance", "مالية", "مصروف", "دخل" -> parseFinance(tokens)
            "debt", "دين", "ديون" -> parseDebt(tokens)
            "note", "ملاحظة", "ملاحظات" -> parseNote(tokens)
            "goal", "هدف" -> parseGoal(tokens)
            "memory", "ذاكرة" -> parseMemory(tokens)
            "scope", "صلاحية", "صلاحيات" -> parseScope(tokens)
            "audit", "تدقيق" -> parseAudit(tokens)

            else -> throw ParseException("الأمر غير معروف: '$first'. اكتب help للاطلاع على دليل الأوامر.")
        }
    }

    private fun parseHelp(tokens: List<CommandLexer.Token>): AppCommand {
        val topic = if (tokens.size > 1) tokens[1].raw else null
        return AppCommand.Help(topic)
    }

    private fun parseTask(tokens: List<CommandLexer.Token>): AppCommand {
        if (tokens.size < 2) return AppCommand.TaskList()
        val sub = tokens[1].raw.lowercase()

        return when (sub) {
            "add", "new", "إضافة", "جديد" -> {
                if (tokens.size < 3) throw ParseException("صيغة غير صحيحة: يجب تحديد عنوان المهمة. مثال: task add \"شراء مستلزمات\" priority:high")
                val title = tokens[2].raw
                var priority = TaskPriority.IMPORTANT_NOT_URGENT
                var timeHorizon = TimeHorizon.DAILY
                var duration: Int? = null
                var tags: String? = null
                var desc: String? = null

                for (i in 3 until tokens.size) {
                    val t = tokens[i]
                    val k = t.key?.lowercase()
                    val v = t.value ?: t.raw
                    when (k) {
                        "priority", "أولوية", "p" -> {
                            priority = when (v.lowercase()) {
                                "urgent", "عاجل", "1" -> TaskPriority.URGENT_IMPORTANT
                                "important", "مهم", "2" -> TaskPriority.IMPORTANT_NOT_URGENT
                                "urgent_not_important", "3" -> TaskPriority.URGENT_NOT_IMPORTANT
                                else -> TaskPriority.NEITHER
                            }
                        }
                        "horizon", "أفق", "h" -> {
                            timeHorizon = when (v.lowercase()) {
                                "weekly", "أسبوعي" -> TimeHorizon.WEEKLY
                                "monthly", "شهري" -> TimeHorizon.MONTHLY
                                "yearly", "سنوي" -> TimeHorizon.YEARLY
                                else -> TimeHorizon.DAILY
                            }
                        }
                        "duration", "مدة", "d" -> duration = v.filter { it.isDigit() }.toIntOrNull()
                        "tags", "وسوم" -> tags = v
                        "desc", "وصف" -> desc = v
                    }
                }
                AppCommand.TaskAdd(
                    title = title,
                    description = desc,
                    priority = priority,
                    timeHorizon = timeHorizon,
                    durationMinutes = duration,
                    tags = tags
                )
            }
            "done", "complete", "إنجاز" -> {
                if (tokens.size < 3) throw ParseException("صيغة غير صحيحة: يجب تحديد رقم المهمة. مثال: task done 5")
                val id = tokens[2].raw.toLongOrNull() ?: throw ParseException("رقم المهمة غير صالح: ${tokens[2].raw}")
                AppCommand.TaskComplete(id)
            }
            "delete", "del", "حذف" -> {
                if (tokens.size < 3) throw ParseException("صيغة غير صحيحة: يجب تحديد رقم المهمة. مثال: task delete 5")
                val id = tokens[2].raw.toLongOrNull() ?: throw ParseException("رقم المهمة غير صالح: ${tokens[2].raw}")
                AppCommand.TaskDelete(id)
            }
            "list", "عرض", "قائمة" -> {
                val horizon = if (tokens.size > 2) {
                    when (tokens[2].raw.lowercase()) {
                        "today", "يومي", "daily" -> TimeHorizon.DAILY
                        "week", "أسبوعي", "weekly" -> TimeHorizon.WEEKLY
                        "month", "شهري", "monthly" -> TimeHorizon.MONTHLY
                        else -> null
                    }
                } else null
                AppCommand.TaskList(horizon = horizon)
            }
            else -> {
                // If sub is a number, assume task complete
                val id = sub.toLongOrNull()
                if (id != null) AppCommand.TaskComplete(id)
                else throw ParseException("إجراء غير معروف للمهام: '$sub'. استخدم add, done, delete, list.")
            }
        }
    }

    private fun parseProject(tokens: List<CommandLexer.Token>): AppCommand {
        if (tokens.size < 2 || tokens[1].raw.lowercase() in listOf("list", "عرض")) return AppCommand.ProjectList()
        val sub = tokens[1].raw.lowercase()
        if (sub in listOf("add", "new", "إضافة")) {
            if (tokens.size < 3) throw ParseException("حدد اسم المشروع. مثال: project add \"تطوير الموقع\"")
            val name = tokens[2].raw
            val desc = if (tokens.size > 3) tokens[3].raw else null
            return AppCommand.ProjectAdd(name = name, description = desc)
        }
        throw ParseException("إجراء غير معروف للمشاريع: '$sub'. استخدم add أو list.")
    }

    private fun parseFinance(tokens: List<CommandLexer.Token>): AppCommand {
        if (tokens.size < 2) return AppCommand.FinanceBalance()
        val sub = tokens[1].raw.lowercase()

        when (sub) {
            "balance", "رصيد" -> return AppCommand.FinanceBalance()
            "rate", "سعر", "صرف" -> {
                if (tokens.size < 3) throw ParseException("حدد سعر الصرف. مثال: finance rate 14800")
                val rate = tokens[2].raw.toDoubleOrNull() ?: throw ParseException("سعر الصرف غير صالح: ${tokens[2].raw}")
                return AppCommand.FinanceRateUpdate(rate)
            }
            "expense", "مصروف", "صرف" -> return parseFinanceTx(tokens, isExpense = true)
            "income", "دخل", "إيراد" -> return parseFinanceTx(tokens, isExpense = false)
            "add", "إضافة" -> {
                val isExp = if (tokens.size > 2 && tokens[2].raw.lowercase() in listOf("income", "دخل")) false else true
                val startIdx = if (tokens.size > 2 && tokens[2].raw.lowercase() in listOf("income", "دخل", "expense", "مصروف")) 3 else 2
                return parseFinanceTx(tokens, isExpense = isExp, offset = startIdx)
            }
            else -> throw ParseException("إجراء مالي غير معروف: '$sub'. استخدم expense, income, balance, rate.")
        }
    }

    private fun parseFinanceTx(tokens: List<CommandLexer.Token>, isExpense: Boolean, offset: Int = 2): AppCommand {
        if (tokens.size <= offset) {
            throw ParseException("حدد المبلغ والتصنيف. مثال: finance expense 50000 currency:SYP category:طعام")
        }

        val amount = tokens[offset].raw.toDoubleOrNull()
            ?: throw ParseException("المبلغ المالي غير صالح: ${tokens[offset].raw}")

        var currency = CurrencyType.SYP
        var categoryName = if (isExpense) "مصاريف عامة" else "دخل عام"
        var note: String? = null

        for (i in (offset + 1) until tokens.size) {
            val t = tokens[i]
            val k = t.key?.lowercase()
            val v = t.value ?: t.raw
            when (k) {
                "currency", "عملة", "c" -> {
                    currency = if (v.uppercase() == "USD" || v == "دولار") CurrencyType.USD else CurrencyType.SYP
                }
                "category", "تصنيف", "cat" -> categoryName = v
                "note", "ملاحظة" -> note = v
                else -> {
                    if (t.key == null && !t.isFlag) {
                        if (categoryName == "مصاريف عامة" || categoryName == "دخل عام") categoryName = t.raw
                        else note = t.raw
                    }
                }
            }
        }

        return AppCommand.FinanceAdd(
            isExpense = isExpense,
            amount = amount,
            currency = currency,
            categoryName = categoryName,
            note = note
        )
    }

    private fun parseDebt(tokens: List<CommandLexer.Token>): AppCommand {
        if (tokens.size < 2) return AppCommand.DebtList()
        val sub = tokens[1].raw.lowercase()

        return when (sub) {
            "list", "عرض" -> AppCommand.DebtList()
            "add", "new", "إضافة" -> {
                // debt add owe "سامر" 250000 currency:SYP
                if (tokens.size < 5) throw ParseException("صيغة غير صحيحة. مثال: debt add owe \"سامر\" 250000 currency:SYP")
                val typeStr = tokens[2].raw.lowercase()
                val type = if (typeStr in listOf("owe", "علي", "التزام")) DebtType.I_OWE else DebtType.OWED_TO_ME
                val person = tokens[3].raw
                val amount = tokens[4].raw.toDoubleOrNull() ?: throw ParseException("قيمة الدين غير صالحة: ${tokens[4].raw}")
                var currency = CurrencyType.SYP
                var note: String? = null

                for (i in 5 until tokens.size) {
                    val t = tokens[i]
                    val k = t.key?.lowercase()
                    val v = t.value ?: t.raw
                    when (k) {
                        "currency", "عملة" -> currency = if (v.uppercase() == "USD") CurrencyType.USD else CurrencyType.SYP
                        "note", "ملاحظة" -> note = v
                    }
                }
                AppCommand.DebtAdd(type = type, personName = person, amount = amount, currency = currency, note = note)
            }
            "pay", "سداد", "دفع" -> {
                if (tokens.size < 4) throw ParseException("حدد رقم الدين والمبلغ. مثال: debt pay 3 50000")
                val debtId = tokens[2].raw.toLongOrNull() ?: throw ParseException("رقم الدين غير صالح: ${tokens[2].raw}")
                val amount = tokens[3].raw.toDoubleOrNull() ?: throw ParseException("المبلغ غير صالح: ${tokens[3].raw}")
                val note = if (tokens.size > 4) tokens[4].raw else null
                AppCommand.DebtPay(debtId = debtId, amount = amount, note = note)
            }
            else -> throw ParseException("إجراء غير معروف للديون: '$sub'. استخدم add, pay, list.")
        }
    }

    private fun parseNote(tokens: List<CommandLexer.Token>): AppCommand {
        if (tokens.size < 2) return AppCommand.NoteList()
        val sub = tokens[1].raw.lowercase()

        return when (sub) {
            "list", "عرض" -> {
                val query = if (tokens.size > 2) tokens[2].raw else null
                AppCommand.NoteList(query = query)
            }
            "add", "new", "إضافة" -> {
                if (tokens.size < 3) throw ParseException("حدد عنوان ومحتوى الملاحظة. مثال: note add \"فكرة عمل\" \"تفاصيل الملاحظة\"")
                val title = tokens[2].raw
                val content = if (tokens.size > 3) tokens[3].raw else title
                var tags: String? = null
                for (i in 4 until tokens.size) {
                    val t = tokens[i]
                    if (t.key?.lowercase() in listOf("tags", "وسوم")) tags = t.value ?: t.raw
                }
                AppCommand.NoteAdd(title = title, contentMarkdown = content, tags = tags)
            }
            else -> {
                AppCommand.NoteList(query = sub)
            }
        }
    }

    private fun parseGoal(tokens: List<CommandLexer.Token>): AppCommand {
        if (tokens.size < 3) throw ParseException("حدد عنوان الهدف. مثال: goal add \"قراءة 12 كتاباً\"")
        val title = tokens[2].raw
        return AppCommand.GoalAdd(title = title)
    }

    private fun parseMemory(tokens: List<CommandLexer.Token>): AppCommand {
        if (tokens.size < 2) return AppCommand.MemoryList()
        val sub = tokens[1].raw.lowercase()

        return when (sub) {
            "list", "عرض" -> {
                val query = if (tokens.size > 2) tokens[2].raw else null
                AppCommand.MemoryList(query = query)
            }
            "add", "new", "حفظ" -> {
                // memory add pref "currency" "يفضل المستخدم الليرة السورية"
                if (tokens.size < 5) throw ParseException("صيغة غير صحيحة. مثال: memory add pref \"key\" \"محتوى الذاكرة التراكمية\"")
                val cat = when (tokens[2].raw.lowercase()) {
                    "pref", "تفضيل" -> "USER_PREFERENCE"
                    "habit", "عادة" -> "HABIT"
                    "summary", "ملخص" -> "EPISODIC_SUMMARY"
                    else -> "SEMANTIC_FACT"
                }
                val key = tokens[3].raw
                val content = tokens[4].raw
                val imp = if (tokens.size > 5) tokens[5].raw.toIntOrNull() ?: 3 else 3
                AppCommand.MemoryAdd(category = cat, key = key, content = content, importance = imp)
            }
            else -> AppCommand.MemoryList(query = sub)
        }
    }

    private fun parseScope(tokens: List<CommandLexer.Token>): AppCommand {
        if (tokens.size < 2 || tokens[1].raw.lowercase() in listOf("list", "عرض")) return AppCommand.ScopeList()
        val sub = tokens[1].raw.lowercase()
        if (tokens.size < 3) throw ParseException("حدد اسم الصلاحية. مثال: scope grant tasks:write")
        val scopeName = tokens[2].raw
        val isGranted = sub in listOf("grant", "منح", "تفعيل", "enable")
        return AppCommand.ScopeSet(scopeName = scopeName, isGranted = isGranted)
    }

    private fun parseAudit(tokens: List<CommandLexer.Token>): AppCommand {
        val limit = if (tokens.size > 2) tokens[2].raw.toIntOrNull() ?: 10 else 10
        return AppCommand.AuditList(limit = limit)
    }
}
