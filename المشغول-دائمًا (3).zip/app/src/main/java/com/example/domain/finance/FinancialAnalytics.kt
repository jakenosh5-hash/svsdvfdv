package com.example.domain.finance

import com.example.data.local.entities.AssetEntity
import com.example.data.local.entities.DebtEntity
import com.example.data.local.entities.FinanceTransactionEntity
import com.example.domain.models.CurrencyType
import com.example.domain.models.DebtStatus
import com.example.domain.models.DebtType
import com.example.domain.models.TransactionType
import com.example.services.CurrencyBalance
import java.text.NumberFormat
import java.util.Locale

/**
 * Pure domain calculations for Phase 3:
 * - Dual-currency conversion and Net Worth (P3-T03, P3-T04)
 * - Liquidity Ratio Calculator (P3-T22)
 * - Financial Leakage Detector (P3-T25)
 * - Cashflow Forecast Engine (P3-T26)
 * - Debt Payoff Strategies (Snowball & Avalanche) (P3-T27)
 * - Monthly Financial Statement Summary (P3-T28)
 */
object FinancialAnalytics {

    /**
     * Converts an amount between SYP and USD using the specified exchange rate.
     * 1 USD = rate SYP (e.g. 1 USD = 14,500 SYP)
     */
    fun convertCurrency(
        amount: Double,
        from: CurrencyType,
        to: CurrencyType,
        usdToSypRate: Double
    ): Double {
        if (from == to) return amount
        if (usdToSypRate <= 0.0) return amount
        return when {
            from == CurrencyType.USD && to == CurrencyType.SYP -> amount * usdToSypRate
            from == CurrencyType.SYP && to == CurrencyType.USD -> amount / usdToSypRate
            else -> amount
        }
    }

    /**
     * Calculates Unified Net Worth in target currency.
     * Net Worth = (Total Assets + Cash Balances + Owed To Me) - (Debts I Owe)
     */
    fun calculateUnifiedNetWorth(
        targetCurrency: CurrencyType,
        usdToSypRate: Double,
        balance: CurrencyBalance,
        assets: List<AssetEntity>,
        debts: List<DebtEntity>
    ): Double {
        val rate = if (usdToSypRate > 0.0) usdToSypRate else 14500.0

        // 1. Balances
        val sypNetConverted = convertCurrency(balance.sypNet, CurrencyType.SYP, targetCurrency, rate)
        val usdNetConverted = convertCurrency(balance.usdNet, CurrencyType.USD, targetCurrency, rate)

        // 2. Assets
        var assetsTotal = 0.0
        for (asset in assets) {
            val converted = convertCurrency(asset.currentValue, asset.currency, targetCurrency, rate)
            assetsTotal += converted
        }

        // 3. Debts (Active)
        var debtsOwedToMe = 0.0
        var debtsIOwe = 0.0
        for (debt in debts) {
            if (debt.status == DebtStatus.ACTIVE) {
                val converted = convertCurrency(debt.remainingAmount, debt.currency, targetCurrency, rate)
                if (debt.type == DebtType.OWED_TO_ME) {
                    debtsOwedToMe += converted
                } else if (debt.type == DebtType.I_OWE) {
                    debtsIOwe += converted
                }
            }
        }

        return (sypNetConverted + usdNetConverted) + assetsTotal + debtsOwedToMe - debtsIOwe
    }

    /**
     * Calculates Liquidity Ratio:
     * Liquid Assets: CASH, BANK
     * Total Assets
     */
    data class LiquidityReport(
        val liquidAmount: Double,
        val totalAssetsAmount: Double,
        val liquidityRatioPercent: Double,
        val isHealthy: Boolean // >= 20% is recommended emergency cushion
    )

    fun calculateLiquidity(
        assets: List<AssetEntity>,
        targetCurrency: CurrencyType,
        usdToSypRate: Double
    ): LiquidityReport {
        val rate = if (usdToSypRate > 0.0) usdToSypRate else 14500.0
        var liquid = 0.0
        var total = 0.0

        for (asset in assets) {
            val converted = convertCurrency(asset.currentValue, asset.currency, targetCurrency, rate)
            total += converted
            val cat = asset.category.uppercase(Locale.ROOT)
            if (cat == "CASH" || cat == "BANK" || cat == "نقد" || cat == "حساب بنكي") {
                liquid += converted
            }
        }

        val ratio = if (total > 0.0) (liquid / total) * 100.0 else 0.0
        return LiquidityReport(
            liquidAmount = liquid,
            totalAssetsAmount = total,
            liquidityRatioPercent = ratio,
            isHealthy = ratio >= 20.0
        )
    }

    /**
     * Identifies Financial Leakage (نزيف مالي):
     * Repeated small expenses (< maxThreshold) whose sum exceeds 15% of total expenses.
     */
    data class LeakageItem(
        val categoryName: String,
        val count: Int,
        val totalAmount: Double,
        val percentageOfTotal: Double
    )

    fun detectFinancialLeakage(
        transactions: List<FinanceTransactionEntity>,
        categoryNameLookup: (Long) -> String,
        targetCurrency: CurrencyType,
        usdToSypRate: Double,
        microThreshold: Double = 15000.0 // e.g. 15,000 SYP or 2 USD
    ): List<LeakageItem> {
        val expenses = transactions.filter { it.type == TransactionType.EXPENSE }
        if (expenses.isEmpty()) return emptyList()

        var totalExpenseConverted = 0.0
        val microMap = mutableMapOf<Long, Pair<Int, Double>>()

        for (tx in expenses) {
            val converted = convertCurrency(tx.amount, tx.currency, targetCurrency, usdToSypRate)
            totalExpenseConverted += converted

            if (converted <= microThreshold) {
                val current = microMap[tx.categoryId] ?: Pair(0, 0.0)
                microMap[tx.categoryId] = Pair(current.first + 1, current.second + converted)
            }
        }

        if (totalExpenseConverted <= 0.0) return emptyList()

        return microMap.mapNotNull { (catId, pair) ->
            val count = pair.first
            val sum = pair.second
            val pct = (sum / totalExpenseConverted) * 100.0
            if (count >= 3 && pct >= 5.0) {
                LeakageItem(
                    categoryName = categoryNameLookup(catId),
                    count = count,
                    totalAmount = sum,
                    percentageOfTotal = pct
                )
            } else null
        }.sortedByDescending { it.totalAmount }
    }

    /**
     * Cashflow Forecast Engine:
     * Forecasts the balance at end of next month based on average monthly burn rate and upcoming debts.
     */
    data class ForecastResult(
        val expectedIncome: Double,
        val expectedExpense: Double,
        val upcomingDebtsDue: Double,
        val projectedSurplusOrDeficit: Double,
        val isDeficitRisk: Boolean
    )

    fun forecastNextMonth(
        currentBalance: Double,
        recentTransactions: List<FinanceTransactionEntity>,
        activeDebts: List<DebtEntity>,
        targetCurrency: CurrencyType,
        usdToSypRate: Double
    ): ForecastResult {
        // Calculate average or sum from transactions in the past 30 days
        var income = 0.0
        var expense = 0.0

        for (tx in recentTransactions) {
            val converted = convertCurrency(tx.amount, tx.currency, targetCurrency, usdToSypRate)
            if (tx.type == TransactionType.INCOME) income += converted
            else if (tx.type == TransactionType.EXPENSE) expense += converted
        }

        // Active debts due in next 30 days that I Owe
        val now = System.currentTimeMillis()
        val nextMonthEnd = now + (35L * 24 * 3600 * 1000)
        var debtsDue = 0.0

        for (d in activeDebts) {
            if (d.status == DebtStatus.ACTIVE && d.type == DebtType.I_OWE) {
                val due = d.dueDate
                if (due == null || due <= nextMonthEnd) {
                    debtsDue += convertCurrency(d.remainingAmount, d.currency, targetCurrency, usdToSypRate)
                }
            }
        }

        val projected = currentBalance + income - expense - debtsDue
        return ForecastResult(
            expectedIncome = income,
            expectedExpense = expense,
            upcomingDebtsDue = debtsDue,
            projectedSurplusOrDeficit = projected,
            isDeficitRisk = projected < 0.0
        )
    }

    /**
     * Debt Payoff Strategies:
     * - Snowball: Lowest remaining amount first (Builds psychological momentum)
     * - Avalanche: Highest remaining amount or highest interest rate first (Mathematically optimal)
     */
    enum class PayoffStrategy {
        SNOWBALL,
        AVALANCHE
    }

    fun prioritizeDebts(
        debts: List<DebtEntity>,
        strategy: PayoffStrategy
    ): List<DebtEntity> {
        val activeDebts = debts.filter { it.status == DebtStatus.ACTIVE && it.type == DebtType.I_OWE }
        return when (strategy) {
            PayoffStrategy.SNOWBALL -> activeDebts.sortedBy { it.remainingAmount }
            PayoffStrategy.AVALANCHE -> activeDebts.sortedWith(
                compareByDescending<DebtEntity> { it.interestRatePercent }
                    .thenByDescending { it.remainingAmount }
            )
        }
    }

    /**
     * Generates a complete textual Monthly Financial Statement Summary.
     */
    fun generateFinancialSummaryText(
        monthName: String,
        balance: CurrencyBalance,
        rate: Double,
        assets: List<AssetEntity>,
        debts: List<DebtEntity>
    ): String {
        val nf = NumberFormat.getNumberInstance(Locale.US)
        val sypNetWorth = calculateUnifiedNetWorth(CurrencyType.SYP, rate, balance, assets, debts)
        val usdNetWorth = calculateUnifiedNetWorth(CurrencyType.USD, rate, balance, assets, debts)

        val activeDebtsIOwe = debts.filter { it.status == DebtStatus.ACTIVE && it.type == DebtType.I_OWE }
        val activeDebtsOwedToMe = debts.filter { it.status == DebtStatus.ACTIVE && it.type == DebtType.OWED_TO_ME }

        return buildString {
            appendLine("════════════════════════════════════")
            appendLine(" 📊 التقرير المالي الشامل - $monthName")
            appendLine(" تطبيق: المشغول دائمًا (Always Busy Life OS)")
            appendLine("════════════════════════════════════")
            appendLine()
            appendLine("💵 سعر الصرف المعتمد: 1 USD = ${nf.format(rate)} SYP")
            appendLine()
            appendLine("🔹 رصيد الليرة السورية (SYP):")
            appendLine("  • الدخل: +${nf.format(balance.sypIncome)} ل.س")
            appendLine("  • الصرف: -${nf.format(balance.sypExpense)} ل.س")
            appendLine("  • الصافي: ${nf.format(balance.sypNet)} ل.س")
            appendLine()
            appendLine("🔹 رصيد الدولار الأمريكي (USD):")
            appendLine("  • الدخل: +$${nf.format(balance.usdIncome)}")
            appendLine("  • الصرف: -$${nf.format(balance.usdExpense)}")
            appendLine("  • الصافي: $${nf.format(balance.usdNet)}")
            appendLine()
            appendLine("💎 إجمالي صافي الثروة المجمعة:")
            appendLine("  • ما يعادل بالليرة: ${nf.format(sypNetWorth)} ل.س")
            appendLine("  • ما يعادل بالدولار: $${nf.format(usdNetWorth)}")
            appendLine()
            appendLine("🤝 الالتزامات والديون النشطة:")
            appendLine("  • ديون عليّ (I Owe): ${activeDebtsIOwe.size} التزامات")
            appendLine("  • ديون لي (Owed to Me): ${activeDebtsOwedToMe.size} مستحقات")
            appendLine()
            appendLine("💼 المحفظة والأصول:")
            appendLine("  • عدد الأصول المسجلة: ${assets.size}")
            appendLine("════════════════════════════════════")
            appendLine("تم التوليد محلياً وبأمان تام 100% بدون أي تسريب للبيانات.")
        }
    }
}
