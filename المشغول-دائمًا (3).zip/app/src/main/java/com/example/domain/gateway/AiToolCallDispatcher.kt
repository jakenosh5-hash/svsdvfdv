package com.example.domain.gateway

import com.example.domain.command.AppCommand
import com.example.domain.command.CommandBus
import com.example.domain.command.CommandResult
import com.example.domain.models.*
import org.json.JSONObject

/**
 * Dispatches structured AI tool call payloads (JSON) into typed commands,
 * enforcing execution safety and returning uniform JSON results to the AI model.
 */
class AiToolCallDispatcher(
    private val commandBus: CommandBus
) {

    suspend fun dispatchToolCall(toolCallJson: String): CommandResult {
        return try {
            val root = JSONObject(toolCallJson)
            val name = root.optString("name", "")
            val args = root.optJSONObject("arguments") ?: JSONObject()

            val command: AppCommand = when (name) {
                "create_task" -> {
                    val title = args.getString("title")
                    val desc = args.optString("description", null)
                    val prioStr = args.optString("priority", "IMPORTANT_NOT_URGENT")
                    val priority = runCatching { TaskPriority.valueOf(prioStr) }.getOrDefault(TaskPriority.IMPORTANT_NOT_URGENT)
                    val horizonStr = args.optString("time_horizon", "DAILY")
                    val horizon = runCatching { TimeHorizon.valueOf(horizonStr) }.getOrDefault(TimeHorizon.DAILY)
                    val duration = if (args.has("duration_minutes")) args.getInt("duration_minutes") else null
                    val tags = args.optString("tags", null)
                    AppCommand.TaskAdd(
                        title = title,
                        description = desc,
                        priority = priority,
                        timeHorizon = horizon,
                        durationMinutes = duration,
                        tags = tags
                    )
                }

                "complete_task" -> {
                    val taskId = args.getLong("task_id")
                    AppCommand.TaskComplete(taskId)
                }

                "query_tasks" -> {
                    val horizonStr = args.optString("horizon", null)
                    val horizon = horizonStr?.let { runCatching { TimeHorizon.valueOf(it) }.getOrNull() }
                    val limit = args.optInt("limit", 20)
                    AppCommand.TaskList(horizon = horizon, limit = limit)
                }

                "record_transaction" -> {
                    val isExpense = args.getBoolean("is_expense")
                    val amount = args.getDouble("amount")
                    val currStr = args.optString("currency", "SYP")
                    val currency = if (currStr.uppercase() == "USD") CurrencyType.USD else CurrencyType.SYP
                    val category = args.getString("category")
                    val note = args.optString("note", null)
                    AppCommand.FinanceAdd(
                        isExpense = isExpense,
                        amount = amount,
                        currency = currency,
                        categoryName = category,
                        note = note
                    )
                }

                "get_financial_balance" -> {
                    AppCommand.FinanceBalance()
                }

                "create_debt" -> {
                    val typeStr = args.getString("type")
                    val type = if (typeStr == "OWED_TO_ME") DebtType.OWED_TO_ME else DebtType.I_OWE
                    val person = args.getString("person_name")
                    val amount = args.getDouble("amount")
                    val currStr = args.optString("currency", "SYP")
                    val currency = if (currStr.uppercase() == "USD") CurrencyType.USD else CurrencyType.SYP
                    val note = args.optString("note", null)
                    AppCommand.DebtAdd(
                        type = type,
                        personName = person,
                        amount = amount,
                        currency = currency,
                        note = note
                    )
                }

                "record_debt_payment" -> {
                    val debtId = args.getLong("debt_id")
                    val amount = args.getDouble("amount")
                    val note = args.optString("note", null)
                    AppCommand.DebtPay(debtId = debtId, amount = amount, note = note)
                }

                "save_note" -> {
                    val title = args.getString("title")
                    val content = args.getString("content_markdown")
                    val tags = args.optString("tags", null)
                    AppCommand.NoteAdd(title = title, contentMarkdown = content, tags = tags)
                }

                "store_memory" -> {
                    val category = args.getString("category")
                    val key = args.getString("key")
                    val content = args.getString("content")
                    val importance = args.optInt("importance", 3)
                    AppCommand.MemoryAdd(category = category, key = key, content = content, importance = importance)
                }

                "get_system_snapshot" -> {
                    AppCommand.SystemSnapshot()
                }

                else -> throw IllegalArgumentException("أداة غير معروفة للوكيل: '$name'")
            }

            commandBus.execute(command, actor = AuditActor.AI_AGENT)
        } catch (e: Exception) {
            val errJson = JSONObject().apply {
                put("status", "error")
                put("message", e.message ?: "خطأ أثناء تفكيك استدعاء الأداة")
            }.toString()
            CommandResult(
                isSuccess = false,
                outputUser = "فشل تنفيذ أداة الذكاء الاصطناعي: ${e.message}",
                outputJson = errJson,
                actionType = "AI_TOOL_CALL_ERROR",
                errorCode = "TOOL_CALL_PARSING_FAILED"
            )
        }
    }
}
