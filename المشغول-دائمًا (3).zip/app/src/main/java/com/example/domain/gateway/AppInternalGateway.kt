package com.example.domain.gateway

import com.example.data.local.AppDatabase
import com.example.data.local.entities.*
import com.example.domain.models.*
import com.example.services.*
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

/**
 * Unified internal application gateway providing headless, strongly-typed endpoints
 * for the AI layer, automation bots, and terminal bus without exposing raw database tables.
 */
class AppInternalGateway(
    private val database: AppDatabase,
    private val taskService: ITaskService,
    private val financeService: IFinanceService,
    private val debtService: IDebtService,
    private val noteService: INoteService,
    private val auditService: IAuditService,
    private val securityScopeService: ISecurityScopeService
) {

    // --- Tasks ---
    suspend fun createTask(
        title: String,
        description: String? = null,
        priority: TaskPriority = TaskPriority.IMPORTANT_NOT_URGENT,
        timeHorizon: TimeHorizon = TimeHorizon.DAILY,
        durationMinutes: Int? = null,
        tags: String? = null,
        projectId: Long? = null
    ): Long {
        return taskService.createTask(
            title = title,
            description = description,
            priority = priority,
            timeHorizon = timeHorizon,
            durationMinutes = durationMinutes,
            tags = tags,
            projectId = projectId
        )
    }

    suspend fun completeTask(taskId: Long) {
        taskService.updateTaskStatus(taskId, TaskStatus.COMPLETED)
    }

    suspend fun deleteTask(taskId: Long) {
        taskService.deleteTask(taskId)
    }

    suspend fun getAllTasks(): List<TaskEntity> = taskService.getAllTasks().first()

    suspend fun getTodayTasks(): List<TaskEntity> = taskService.getTodayTasks().first()

    // --- Projects ---
    suspend fun createProject(name: String, description: String? = null, colorHex: String = "#2E7D32", iconName: String = "folder"): Long {
        return taskService.createProject(name, description, colorHex, iconName)
    }

    suspend fun getProjects(): List<ProjectEntity> = taskService.getProjects().first()

    // --- Finance ---
    suspend fun recordFinanceTransaction(
        isExpense: Boolean,
        amount: Double,
        currency: CurrencyType,
        categoryName: String,
        note: String? = null
    ): Long {
        val categories = financeService.getCategories().first()
        val matchedCategory = categories.firstOrNull { it.name.contains(categoryName, ignoreCase = true) }
        val categoryId = matchedCategory?.id ?: (categories.firstOrNull()?.id ?: 1L)

        val type = if (isExpense) TransactionType.EXPENSE else TransactionType.INCOME
        return financeService.recordTransaction(
            type = type,
            amount = amount,
            currency = currency,
            categoryId = categoryId,
            note = note
        )
    }

    suspend fun getBalanceSummary(): CurrencyBalance = financeService.getBalanceSummary().first()

    suspend fun updateExchangeRate(rate: Double, note: String? = null): Long {
        return financeService.updateExchangeRate(rate, note)
    }

    // --- Debts ---
    suspend fun createDebt(
        type: DebtType,
        personName: String,
        amount: Double,
        currency: CurrencyType = CurrencyType.SYP,
        note: String? = null
    ): Long {
        return debtService.createDebt(
            type = type,
            personName = personName,
            amount = amount,
            currency = currency,
            note = note
        )
    }

    suspend fun recordDebtPayment(debtId: Long, amount: Double, note: String? = null) {
        debtService.recordPartialPayment(debtId, amount, note)
    }

    suspend fun getDebts(): List<DebtEntity> = debtService.getAllDebts().first()

    // --- Notes ---
    suspend fun saveNote(title: String, contentMarkdown: String, tags: String? = null): Long {
        return noteService.saveNote(title, contentMarkdown, tags)
    }

    suspend fun getNotes(): List<NoteEntity> = noteService.getActiveNotes().first()

    // --- Cumulative Memory ---
    suspend fun saveMemory(category: String, key: String, content: String, importance: Int = 3): Long {
        val entity = AiMemoryItemEntity(
            category = category,
            memoryKey = key,
            content = content,
            importance = importance
        )
        return database.aiDao().insertOrUpdateMemory(entity)
    }

    suspend fun getMemories(): List<AiMemoryItemEntity> = database.aiDao().getAllMemoriesList()

    suspend fun searchMemories(query: String): List<AiMemoryItemEntity> = database.aiDao().searchMemories(query)

    // --- Scopes & Audit ---
    suspend fun getScopes(): List<SecurityScopeEntity> = securityScopeService.getAllScopes().first()

    suspend fun setScope(scopeName: String, isGranted: Boolean) {
        securityScopeService.setScopeGranted(scopeName, isGranted)
    }

    suspend fun getRecentAuditLogs(limit: Int = 10): List<AuditLogEntity> = auditService.getRecentLogs().first().take(limit)

    // --- Dense System Index Snapshot ---
    suspend fun getDenseSystemSnapshot(): String {
        val todayTasks = getTodayTasks()
        val allTasks = getAllTasks()
        val balance = getBalanceSummary()
        val debts = getDebts()
        val memories = getMemories().take(5)
        val calmScore = taskService.calculateCalmScore(todayTasks)

        val root = JSONObject()
        root.put("calm_score", calmScore)
        root.put("today_tasks_count", todayTasks.size)
        root.put("today_completed", todayTasks.count { it.status == TaskStatus.COMPLETED })
        root.put("total_tasks_open", allTasks.count { it.status != TaskStatus.COMPLETED && it.status != TaskStatus.CANCELLED })

        val balObj = JSONObject()
        balObj.put("syp_net", balance.sypNet)
        balObj.put("usd_net", balance.usdNet)
        root.put("balances", balObj)

        val activeDebts = debts.filter { it.status == DebtStatus.ACTIVE }
        val iOwe = activeDebts.filter { it.type == DebtType.I_OWE }.sumOf { it.remainingAmount }
        val owedToMe = activeDebts.filter { it.type == DebtType.OWED_TO_ME }.sumOf { it.remainingAmount }
        val debtObj = JSONObject()
        debtObj.put("active_count", activeDebts.size)
        debtObj.put("i_owe_total", iOwe)
        debtObj.put("owed_to_me_total", owedToMe)
        root.put("debts_summary", debtObj)

        val memArray = JSONArray()
        for (m in memories) {
            val item = JSONObject()
            item.put("category", m.category)
            item.put("key", m.memoryKey)
            item.put("content", m.content)
            memArray.put(item)
        }
        root.put("top_memories", memArray)

        return root.toString(2)
    }
}
