package com.example.domain.gateway

import org.json.JSONArray
import org.json.JSONObject

/**
 * Standard JSON Schemas for tool calling, compatible with Gemini, Claude, and OpenAI tool-calling specifications.
 */
object ToolCallingSchemas {

    fun getAllToolDefinitions(): String {
        val tools = JSONArray()

        tools.put(createTool(
            name = "create_task",
            description = "إنشاء مهمة جديدة في نظام الإنتاجية مع تحديد الأولوية والأفق الزمني",
            parameters = JSONObject().apply {
                put("type", "object")
                val props = JSONObject().apply {
                    put("title", JSONObject().put("type", "string").put("description", "عنوان المهمة"))
                    put("description", JSONObject().put("type", "string").put("description", "تفاصيل اختيارية للمهمة"))
                    put("priority", JSONObject().put("type", "string").put("enum", JSONArray(listOf("URGENT_IMPORTANT", "IMPORTANT_NOT_URGENT", "URGENT_NOT_IMPORTANT", "NEITHER"))))
                    put("time_horizon", JSONObject().put("type", "string").put("enum", JSONArray(listOf("DAILY", "WEEKLY", "MONTHLY", "YEARLY"))))
                    put("duration_minutes", JSONObject().put("type", "integer").put("description", "المدة التقديرية بالدقائق"))
                    put("tags", JSONObject().put("type", "string").put("description", "وسوم مفصولة بفواصل مثل: عمل,دراسة"))
                }
                put("properties", props)
                put("required", JSONArray(listOf("title")))
            }
        ))

        tools.put(createTool(
            name = "complete_task",
            description = "تعليم مهمة كمكتملة باستخدام معرف المهمة (task_id)",
            parameters = JSONObject().apply {
                put("type", "object")
                val props = JSONObject().apply {
                    put("task_id", JSONObject().put("type", "integer").put("description", "معرف المهمة الرقمي"))
                }
                put("properties", props)
                put("required", JSONArray(listOf("task_id")))
            }
        ))

        tools.put(createTool(
            name = "query_tasks",
            description = "استعلام وقراءة المهام حسب الأفق الزمني والحالة",
            parameters = JSONObject().apply {
                put("type", "object")
                val props = JSONObject().apply {
                    put("horizon", JSONObject().put("type", "string").put("enum", JSONArray(listOf("DAILY", "WEEKLY", "MONTHLY", "YEARLY"))))
                    put("limit", JSONObject().put("type", "integer").put("default", 20))
                }
                put("properties", props)
            }
        ))

        tools.put(createTool(
            name = "record_transaction",
            description = "تسجيل حركة مالية جديدة (مصروف أو دخل) بالليرة السورية أو الدولار الأمريكي",
            parameters = JSONObject().apply {
                put("type", "object")
                val props = JSONObject().apply {
                    put("is_expense", JSONObject().put("type", "boolean").put("description", "true للمصروف و false للإيراد/الدخل"))
                    put("amount", JSONObject().put("type", "number").put("description", "المبلغ المالي"))
                    put("currency", JSONObject().put("type", "string").put("enum", JSONArray(listOf("SYP", "USD"))))
                    put("category", JSONObject().put("type", "string").put("description", "اسم التصنيف مثل: طعام, فواتير, عمل حر"))
                    put("note", JSONObject().put("type", "string").put("description", "ملاحظة أو بيان المعاملة"))
                }
                put("properties", props)
                put("required", JSONArray(listOf("is_expense", "amount", "currency", "category")))
            }
        ))

        tools.put(createTool(
            name = "get_financial_balance",
            description = "الحصول على الأرصدة اللحظية وصافي الدخل والمصروف بالليرة السورية والدولار",
            parameters = JSONObject().apply {
                put("type", "object")
                put("properties", JSONObject())
            }
        ))

        tools.put(createTool(
            name = "create_debt",
            description = "تسجيل دين جديد (عليّ التزام أو لي مستحق) مع اسم الشخص والمبلغ والعملة",
            parameters = JSONObject().apply {
                put("type", "object")
                val props = JSONObject().apply {
                    put("type", JSONObject().put("type", "string").put("enum", JSONArray(listOf("I_OWE", "OWED_TO_ME"))))
                    put("person_name", JSONObject().put("type", "string").put("description", "اسم الشخص أو الجهة"))
                    put("amount", JSONObject().put("type", "number").put("description", "قيمة الدين"))
                    put("currency", JSONObject().put("type", "string").put("enum", JSONArray(listOf("SYP", "USD"))))
                    put("note", JSONObject().put("type", "string").put("description", "بيان الدين"))
                }
                put("properties", props)
                put("required", JSONArray(listOf("type", "person_name", "amount", "currency")))
            }
        ))

        tools.put(createTool(
            name = "record_debt_payment",
            description = "تسجيل دفعة سداد جزئي أو كلي لدين قائم",
            parameters = JSONObject().apply {
                put("type", "object")
                val props = JSONObject().apply {
                    put("debt_id", JSONObject().put("type", "integer").put("description", "معرف الدين"))
                    put("amount", JSONObject().put("type", "number").put("description", "مبلغ الدفعة المسددة"))
                    put("note", JSONObject().put("type", "string").put("description", "ملاحظة السداد أو الوصل"))
                }
                put("properties", props)
                put("required", JSONArray(listOf("debt_id", "amount")))
            }
        ))

        tools.put(createTool(
            name = "save_note",
            description = "حفظ ملاحظة معرفية جديدة بتنسيق Markdown وربطها بوسوم",
            parameters = JSONObject().apply {
                put("type", "object")
                val props = JSONObject().apply {
                    put("title", JSONObject().put("type", "string").put("description", "عنوان الملاحظة"))
                    put("content_markdown", JSONObject().put("type", "string").put("description", "محتوى الملاحظة"))
                    put("tags", JSONObject().put("type", "string").put("description", "وسوم مفصولة بفواصل"))
                }
                put("properties", props)
                put("required", JSONArray(listOf("title", "content_markdown")))
            }
        ))

        tools.put(createTool(
            name = "store_memory",
            description = "تخزين حقيقة، عادة، أو تفضيل في الذاكرة التراكمية الطويلة للمساعد الذكي",
            parameters = JSONObject().apply {
                put("type", "object")
                val props = JSONObject().apply {
                    put("category", JSONObject().put("type", "string").put("enum", JSONArray(listOf("USER_PREFERENCE", "HABIT", "SEMANTIC_FACT", "EPISODIC_SUMMARY"))))
                    put("key", JSONObject().put("type", "string").put("description", "مفتاح الذاكرة الفريد"))
                    put("content", JSONObject().put("type", "string").put("description", "المعلومة المستخلصة بدقة"))
                    put("importance", JSONObject().put("type", "integer").put("description", "مستوى الأهمية من 1 إلى 5"))
                }
                put("properties", props)
                put("required", JSONArray(listOf("category", "key", "content")))
            }
        ))

        tools.put(createTool(
            name = "get_system_snapshot",
            description = "استخراج فهرس النظام اللحظي الكثيف (مؤشر الهدوء، ملخص المهام، النقد، والديون) لتوفير سياق شامل",
            parameters = JSONObject().apply {
                put("type", "object")
                put("properties", JSONObject())
            }
        ))

        return tools.toString(2)
    }

    private fun createTool(name: String, description: String, parameters: JSONObject): JSONObject {
        return JSONObject().apply {
            put("type", "function")
            val func = JSONObject().apply {
                put("name", name)
                put("description", description)
                put("parameters", parameters)
            }
            put("function", func)
        }
    }
}
