package com.example.domain.knowledge

import com.example.data.local.dao.KnowledgeDao
import com.example.data.local.entities.KnowledgeIndexEntity
import com.example.data.local.entities.KnowledgeMemoryEntity
import com.example.data.local.entities.KnowledgeSectionEntity
import kotlinx.coroutines.flow.Flow

/**
 * Service managing the autonomous hierarchical knowledge architecture:
 * Indexes (الفهارس) -> Sections (الأبواب) -> Distilled Memories (الذواكر المقطرة).
 * Acts as the reference library for the AI Brain.
 */
class AutonomousKnowledgeService(
    private val knowledgeDao: KnowledgeDao
) {

    fun getAllIndexes(): Flow<List<KnowledgeIndexEntity>> = knowledgeDao.getAllIndexes()

    fun getAllSections(): Flow<List<KnowledgeSectionEntity>> = knowledgeDao.getAllSections()

    fun getAllMemories(): Flow<List<KnowledgeMemoryEntity>> = knowledgeDao.getAllMemories()

    fun getSectionsForIndex(indexId: Long): Flow<List<KnowledgeSectionEntity>> =
        knowledgeDao.getSectionsForIndex(indexId)

    fun getMemoriesForSection(sectionId: Long): Flow<List<KnowledgeMemoryEntity>> =
        knowledgeDao.getMemoriesForSection(sectionId)

    /**
     * Finds or creates a Knowledge Index (فهرس).
     */
    suspend fun getOrCreateSubIndex(name: String, description: String? = null): KnowledgeIndexEntity {
        val trimmed = name.trim()
        val existing = knowledgeDao.getIndexByName(trimmed)
        if (existing != null) return existing

        val id = knowledgeDao.insertIndex(
            KnowledgeIndexEntity(
                name = trimmed,
                description = description ?: "فهرس معرفي منشأ تلقائياً بواسطة العقل الذكي"
            )
        )
        return knowledgeDao.getIndexById(id) ?: KnowledgeIndexEntity(id = id, name = trimmed)
    }

    /**
     * Finds or creates a Section (باب) within an Index.
     */
    suspend fun getOrCreateSection(
        indexName: String,
        sectionName: String,
        description: String? = null
    ): KnowledgeSectionEntity {
        val index = getOrCreateSubIndex(indexName)
        val trimmedSection = sectionName.trim()
        val existing = knowledgeDao.getSectionByName(index.id, trimmedSection)
        if (existing != null) return existing

        val id = knowledgeDao.insertSection(
            KnowledgeSectionEntity(
                indexId = index.id,
                indexName = index.name,
                name = trimmedSection,
                description = description ?: "باب معرفي فرعي"
            )
        )
        return KnowledgeSectionEntity(
            id = id,
            indexId = index.id,
            indexName = index.name,
            name = trimmedSection
        )
    }

    /**
     * Stores a distilled memory synthesized by the AI.
     */
    suspend fun storeDistilledMemory(
        indexName: String,
        sectionName: String,
        query: String,
        summary: String,
        importance: Int = 5,
        tags: String = "",
        fullContext: String? = null
    ): Long {
        val section = getOrCreateSection(indexName, sectionName)
        return knowledgeDao.insertMemory(
            KnowledgeMemoryEntity(
                sectionId = section.id,
                indexName = section.indexName,
                sectionName = section.name,
                query = query.trim(),
                summary = summary.trim(),
                fullContext = fullContext,
                importance = importance.coerceIn(1, 10),
                tags = tags.trim()
            )
        )
    }

    /**
     * Searches across all indexes, sections, and memories for matches.
     */
    suspend fun searchMemories(query: String): List<KnowledgeMemoryEntity> {
        if (query.isBlank()) return emptyList()
        return knowledgeDao.searchMemories(query.trim())
    }

    /**
     * Fetches all distilled memories in a specific section.
     */
    suspend fun fetchSectionMemories(indexName: String, sectionName: String): List<KnowledgeMemoryEntity> {
        return knowledgeDao.getMemoriesBySectionNames(indexName.trim(), sectionName.trim())
    }

    /**
     * Deletes a memory by ID.
     */
    suspend fun deleteMemory(id: Long) = knowledgeDao.deleteMemory(id)

    /**
     * Deletes an index by ID.
     */
    suspend fun deleteIndex(id: Long) = knowledgeDao.deleteIndex(id)

    /**
     * Builds a concise Knowledge Catalog synopsis to be injected into the AI's system prompt.
     * This provides the AI with the table of contents so it never invents facts or hallucinates.
     */
    suspend fun buildKnowledgeCatalogPrompt(): String {
        val indexes = knowledgeDao.getAllIndexesList()
        val sections = knowledgeDao.getAllSectionsList()
        val memories = knowledgeDao.getAllMemoriesList()

        val sb = StringBuilder()
        sb.appendLine("=== كتالوج فهارس وأبواب المعرفة التراكمية الحالية ===")
        if (indexes.isEmpty()) {
            sb.appendLine("(لا توجد فهارس حتى الآن - يمكنك إنشاء فهارس جديدة وأبواب عند الحاجة)")
            return sb.toString()
        }

        for (idx in indexes) {
            sb.appendLine("📁 فهرس: [${idx.name}] ${if (!idx.description.isNullOrBlank()) "(${idx.description})" else ""}")
            val idxSections = sections.filter { it.indexId == idx.id }
            if (idxSections.isEmpty()) {
                sb.appendLine("   - (لا توجد أبواب حتى الآن)")
            } else {
                for (sec in idxSections) {
                    val secMemories = memories.filter { it.sectionId == sec.id }
                    sb.appendLine("   📖 باب: [${sec.name}] (يحوي ${secMemories.size} ذواكر مقطرة)")
                    // Include top 2 most important memory summaries for immediate context
                    secMemories.take(2).forEach { m ->
                        sb.appendLine("      • [أهمية ${m.importance}/10]: ${m.summary}")
                    }
                }
            }
        }
        sb.appendLine("====================================================")
        return sb.toString()
    }
}
