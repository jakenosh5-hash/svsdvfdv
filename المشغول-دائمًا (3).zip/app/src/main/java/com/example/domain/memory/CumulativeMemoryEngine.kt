package com.example.domain.memory

import com.example.data.local.dao.AiDao
import com.example.data.local.entities.AiMemoryItemEntity
import com.example.data.local.entities.AiMessageEntity
import com.example.domain.gateway.AppInternalGateway
import kotlinx.coroutines.flow.first

/**
 * Human-like cumulative cognitive memory engine.
 * Provides working memory context, episodic & semantic long-term memory retrieval,
 * and automatic conversation summarization.
 */
class CumulativeMemoryEngine(
    private val aiDao: AiDao,
    private val gateway: AppInternalGateway
) {

    /**
     * Builds the complete prompt context for the AI agent, combining:
     * 1. System core philosophy (Life OS, Calm Score, Local-First, Syrian reality).
     * 2. High-importance cumulative memories (User preferences, habits, facts).
     * 3. Live Dense System Index (Current tasks, cash balances, debts).
     */
    suspend fun buildAgentContextPrompt(userQuery: String): String {
        val memories = aiDao.getAllMemoriesList()
        val relevantMemories = if (userQuery.isBlank()) {
            memories.take(8)
        } else {
            val queryWords = userQuery.split(" ", "_", "-").filter { it.length > 2 }
            memories.sortedByDescending { mem ->
                var score = mem.importance * 2
                for (w in queryWords) {
                    if (mem.content.contains(w, ignoreCase = true) || mem.memoryKey.contains(w, ignoreCase = true)) {
                        score += 5
                    }
                }
                score
            }.take(8)
        }

        // Record memory access to simulate synaptic reinforcement
        for (m in relevantMemories) {
            aiDao.recordMemoryAccess(m.id)
        }

        val denseSnapshot = gateway.getDenseSystemSnapshot()

        val sb = StringBuilder()
        sb.append("=== هوية وميثاق المساعد الذكي لنظام (المشغول دائمًا - Life OS) ===\n")
        sb.append("أنت رفيق ذكي تنفيذي ومحرك أتمتة لنظام تشغيل الحياة الشخصية. هدفك تقليل وهم الانشغال ورفع مؤشر الهدوء النفسي.\n")
        sb.append("تتمتع بصلاحية رؤية كافة بيانات التطبيق، ويمكنك استدعاء أدوات النظام البرمجية (Tool Calling) لتنفيذ أي إجراء نيابة عن المستخدم.\n\n")

        sb.append("--- الذاكرة التراكمية الطويلة (Human-like Long-Term Memory) ---\n")
        if (relevantMemories.isEmpty()) {
            sb.append("(لا توجد ذكريات مخزنة حتى الآن)\n")
        } else {
            for (m in relevantMemories) {
                sb.append("• [${m.category} | أهمية:${m.importance}] ${m.memoryKey}: \"${m.content}\"\n")
            }
        }
        sb.append("\n")

        sb.append("--- فهرس النظام اللحظي (Dense System Index Snapshot) ---\n")
        sb.append(denseSnapshot)
        sb.append("\n=================================================================\n")

        return sb.toString()
    }

    /**
     * Automatically distills key facts and decisions from a conversation into persistent memory items.
     */
    suspend fun distillAndStoreMemoriesFromConversation(conversationId: Long, messages: List<AiMessageEntity>) {
        if (messages.size < 2) return

        val userMessages = messages.filter { it.sender == "USER" }.map { it.content }
        val lastUserText = userMessages.lastOrNull() ?: return

        // Pattern-based semantic fact extraction
        val lower = lastUserText.lowercase()
        when {
            lower.contains("أفضل") || lower.contains("افضل") || lower.contains("حبذا") -> {
                val key = "pref_" + System.currentTimeMillis() % 10000
                aiDao.insertOrUpdateMemory(
                    AiMemoryItemEntity(
                        category = "USER_PREFERENCE",
                        memoryKey = key,
                        content = lastUserText.take(120),
                        importance = 4,
                        sourceConversationId = conversationId
                    )
                )
            }

            lower.contains("قررت") || lower.contains("سألتزم") || lower.contains("هدفي") -> {
                val key = "decision_" + System.currentTimeMillis() % 10000
                aiDao.insertOrUpdateMemory(
                    AiMemoryItemEntity(
                        category = "EPISODIC_SUMMARY",
                        memoryKey = key,
                        content = lastUserText.take(120),
                        importance = 5,
                        sourceConversationId = conversationId
                    )
                )
            }

            lower.contains("عادة") || lower.contains("دائما") || lower.contains("يوميا") -> {
                val key = "habit_" + System.currentTimeMillis() % 10000
                aiDao.insertOrUpdateMemory(
                    AiMemoryItemEntity(
                        category = "HABIT",
                        memoryKey = key,
                        content = lastUserText.take(120),
                        importance = 3,
                        sourceConversationId = conversationId
                    )
                )
            }
        }
    }
}
