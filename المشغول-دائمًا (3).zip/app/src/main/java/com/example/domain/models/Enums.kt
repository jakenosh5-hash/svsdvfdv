package com.example.domain.models

enum class CurrencyType(val symbol: String, val displayNameArabic: String) {
    SYP("ل.س", "ليرة سورية"),
    USD("$", "دولار أمريكي")
}

enum class TaskPriority(val labelArabic: String, val level: Int) {
    URGENT_IMPORTANT("عاجل ومهم", 1),
    IMPORTANT_NOT_URGENT("مهم وغير عاجل", 2),
    URGENT_NOT_IMPORTANT("عاجل وغير مهم", 3),
    NEITHER("غير عاجل وغير مهم", 4)
}

enum class TaskStatus(val labelArabic: String) {
    PENDING("قيد الانتظار"),
    IN_PROGRESS("قيد التنفيذ"),
    COMPLETED("مكتمل"),
    POSTPONED("مؤجل"),
    CANCELLED("ملغى")
}

enum class TimeHorizon(val labelArabic: String) {
    DAILY("يومي"),
    WEEKLY("أسبوعي"),
    MONTHLY("شهري"),
    YEARLY("سنوي")
}

enum class DebtType(val labelArabic: String) {
    I_OWE("عليّ دين (التزام)"),
    OWED_TO_ME("لي دين (مستحق)")
}

enum class DebtStatus(val labelArabic: String) {
    ACTIVE("نشط / قائم"),
    PAID("مسدد بالكامل"),
    DEFAULTED("متعثر"),
    CANCELLED("ملغى / مسامح")
}

enum class TransactionType(val labelArabic: String) {
    INCOME("إيراد / دخل"),
    EXPENSE("مصروف"),
    TRANSFER("تحويل")
}

enum class GoalHorizon(val labelArabic: String) {
    SHORT_TERM("قصير المدى (1-3 أشهر)"),
    MEDIUM_TERM("متوسط المدى (3-12 شهراً)"),
    LONG_TERM("طويل المدى (1-5 سنوات)")
}

enum class GoalStatus(val labelArabic: String) {
    IN_PROGRESS("قيد التقدم"),
    ACHIEVED("تم تحقيقه"),
    POSTPONED("مؤجل"),
    ABANDONED("متوقف")
}

enum class AuditAction {
    CREATE,
    UPDATE,
    COMPLETE,
    PAY,
    DELETE
}

enum class AuditActor {
    USER,
    COMMAND_TERMINAL,
    AUTOMATION,
    AI_AGENT
}
