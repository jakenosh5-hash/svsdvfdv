package com.example.network

import com.example.security.AiPreferences
import com.example.security.PersonaProfileStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Robust HTTP client for OpenAI-compatible LLM endpoints (Groq, Grok, OpenAI, Gemini).
 * Supports automatic multi-key failover with 18-hour cooldown demotion.
 * Protects against tool-choice / parsing format conflicts with automatic model fallback.
 */
class LlmApiClient(
    private val aiPreferences: AiPreferences,
    private val personaProfileStore: PersonaProfileStore? = null,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {

    data class ChatMessage(
        val role: String,
        val content: String,
        val toolCallId: String? = null,
        val name: String? = null
    )

    data class ToolCall(val id: String, val name: String, val argumentsJson: String)
    data class ToolResponse(val content: String?, val calls: List<ToolCall>, val rawJson: String)

    suspend fun sendToolChatCompletion(
        persona: String,
        messages: List<ChatMessage>,
        toolsJson: String,
        toolChoice: String = "auto"
    ): Result<ToolResponse> = withContext(Dispatchers.IO) {
        val store = personaProfileStore ?: return@withContext Result.failure(IllegalStateException("Persona profile store is required for tool calling"))
        val profile = store.loadProfile(persona)
        val keys = store.activeKeys(persona)
        if (keys.isEmpty() || profile.baseUrl.isBlank() || profile.model.isBlank()) return@withContext Result.failure(IllegalStateException("لم يتم إعداد ملف $persona بشكل مستقل."))
        val endpoint = if (profile.baseUrl.endsWith("/chat/completions")) profile.baseUrl else "${profile.baseUrl.removeSuffix("/")}/chat/completions"
        var last: Exception? = null
        for ((slot, key) in keys) {
            try {
                val (code, body) = executeChatHttp(endpoint, profile.model, messages, 0.2, key, toolsJson, toolChoice)
                if (code in 200..299) return@withContext Result.success(parseToolResponse(body))
                last = Exception(parseErrorMessage(code, body, endpoint, profile.model))
                if (code in listOf(401, 403, 429)) store.demoteKey(persona, slot)
            } catch (error: Exception) {
                last = error
                store.demoteKey(persona, slot)
            }
        }
        Result.failure(last ?: Exception("Tool Calling failed for $persona"))
    }

    /** Persona-bound path. It never reads or mutates the other persona's provider, model, or keys. */
    suspend fun sendChatCompletionForPersona(
        persona: String,
        messages: List<ChatMessage>,
        temperature: Double = 0.7
    ): Result<String> = withContext(Dispatchers.IO) {
        val store = personaProfileStore ?: return@withContext sendChatCompletion(messages, temperature)
        val profile = store.loadProfile(persona)
        val keyed = store.activeKeys(persona)
        val keys = keyed.map { it.second }
        if (keys.isEmpty() || profile.baseUrl.isBlank() || profile.model.isBlank()) {
            return@withContext Result.failure(IllegalStateException("لم يتم إعداد ملف $persona بشكل مستقل."))
        }
        val endpoint = if (profile.baseUrl.endsWith("/chat/completions")) profile.baseUrl else "${profile.baseUrl.removeSuffix("/")}/chat/completions"
        var failure: Exception? = null
        keyed.forEach { (slot, key) ->
            try {
                val (code, body) = executeChatHttp(endpoint, profile.model, messages, temperature, key)
                if (code in 200..299) extractResponseContent(body)?.takeIf { it.isNotBlank() }?.let {
                    return@withContext Result.success(it)
                }
                failure = Exception(parseErrorMessage(code, body, endpoint, profile.model))
                if (code in listOf(401, 403, 429)) {
                    store.demoteKey(persona, slot)
                }
            } catch (error: Exception) {
                failure = error
                store.demoteKey(persona, slot)
            }
        }
        Result.failure(failure ?: Exception("فشل الاتصال عبر مفاتيح $persona"))
    }

    /**
     * Executes a chat completion request.
     * Iterates through active API keys in order (Primary -> Secondary -> Tertiary ...).
     * If a key encounters rate limit, invalid key, or connection failure, it is demoted for 18 hours.
     */
    suspend fun sendChatCompletion(
        messages: List<ChatMessage>,
        temperature: Double = 0.7
    ): Result<String> = withContext(Dispatchers.IO) {
        val activeKeys = aiPreferences.getActiveKeys()
        if (activeKeys.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("لم يتم تثبيت أي مفتاح API نشط. يرجى إدخال أو رفع مفتاح API من صفحة [الإعدادات].")
            )
        }

        val baseUrl = aiPreferences.baseUrl.trim().removeSuffix("/")
        val endpoint = if (baseUrl.endsWith("/chat/completions")) baseUrl else "$baseUrl/chat/completions"
        var currentModel = aiPreferences.model.trim().ifBlank { AiPreferences.DEFAULT_GROQ_MODEL }

        var lastError: Exception? = null

        // Try available active keys in failover order
        for (key in activeKeys) {
            try {
                val (code, responseBody) = executeChatHttp(endpoint, currentModel, messages, temperature, key)

                if (code in 200..299) {
                    val content = extractResponseContent(responseBody)
                    if (!content.isNullOrBlank()) {
                        return@withContext Result.success(content)
                    }
                }

                // If code is 400 and complains about tool choice / parsing failure,
                // fallback gracefully to a stable model
                if (code == 400 && isToolOrParsingConflict(responseBody)) {
                    val fallbackModel = if (endpoint.contains("groq.com")) {
                        AiPreferences.MODEL_GROQ_GPT_OSS_120B
                    } else {
                        AiPreferences.DEFAULT_GROQ_MODEL
                    }
                    val (retryCode, retryBody) = executeChatHttp(endpoint, fallbackModel, messages, temperature, key)
                    if (retryCode in 200..299) {
                        val content = extractResponseContent(retryBody)
                        if (!content.isNullOrBlank()) {
                            aiPreferences.model = fallbackModel
                            return@withContext Result.success(content)
                        }
                    }
                }

                // If code is 404 (model deprecated / removed on Groq or provider), auto-heal
                if (code == 404 && endpoint.contains("groq.com") && currentModel != AiPreferences.MODEL_GROQ_GPT_OSS_120B) {
                    val fallbackModel = AiPreferences.MODEL_GROQ_GPT_OSS_120B
                    val (retryCode, retryBody) = executeChatHttp(endpoint, fallbackModel, messages, temperature, key)
                    if (retryCode in 200..299) {
                        val content = extractResponseContent(retryBody)
                        if (!content.isNullOrBlank()) {
                            aiPreferences.model = fallbackModel
                            return@withContext Result.success(content)
                        }
                    }
                }

                // If code indicates quota, rate-limit (429), or auth/account issue (401, 403):
                // Demote key silently and proceed to next key!
                if (code in listOf(401, 403, 429) || responseBody.contains("quota", ignoreCase = true)) {
                    aiPreferences.recordKeyFailureAndDemote(key)
                }

                val parsedError = parseErrorMessage(code, responseBody, endpoint, currentModel)
                lastError = Exception(parsedError)

            } catch (e: Exception) {
                lastError = e
                // On connection timeout or IO error on this specific key, demote and try next key
                aiPreferences.recordKeyFailureAndDemote(key)
            }
        }

        val finalMsg = lastError?.localizedMessage ?: "فشل الاتصال بالذكاء الاصطناعي عبر كافة المفاتيح المتوفرة."
        Result.failure(Exception(finalMsg, lastError))
    }

    private fun executeChatHttp(
        endpoint: String,
        modelName: String,
        messages: List<ChatMessage>,
        temperature: Double,
        apiKey: String,
        toolsJson: String? = null,
        toolChoice: String? = null
    ): Pair<Int, String> {
        val messagesArray = JSONArray()
        for (msg in messages) {
            val obj = JSONObject()
            obj.put("role", msg.role)
            obj.put("content", msg.content)
            msg.toolCallId?.let { obj.put("tool_call_id", it) }
            msg.name?.let { obj.put("name", it) }
            messagesArray.put(obj)
        }

        val requestJson = JSONObject()
        requestJson.put("model", modelName)
        requestJson.put("messages", messagesArray)
        requestJson.put("temperature", temperature)
        requestJson.put("stream", false)
        if (!toolsJson.isNullOrBlank()) requestJson.put("tools", JSONArray(toolsJson))
        if (!toolChoice.isNullOrBlank()) requestJson.put("tool_choice", toolChoice)

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = requestJson.toString().toRequestBody(mediaType)

        val requestBuilder = Request.Builder()
            .url(endpoint)
            .post(requestBody)
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", "Bearer $apiKey")

        if (apiKey.startsWith("AIzaSy") || endpoint.contains("googleapis.com")) {
            requestBuilder.addHeader("x-goog-api-key", apiKey)
        }
        if (endpoint.contains("openrouter.ai")) {
            requestBuilder.addHeader("HTTP-Referer", "https://always-busy-life-os.app")
            requestBuilder.addHeader("X-Title", "Always Busy Life OS")
        }

        val request = requestBuilder.build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: ""
        return Pair(response.code, body)
    }

    private fun extractResponseContent(responseBody: String): String? {
        return try {
            val jsonObject = JSONObject(responseBody)
            val choices = jsonObject.optJSONArray("choices")
            if (choices != null && choices.length() > 0) {
                val firstChoice = choices.getJSONObject(0)
                val messageObj = firstChoice.optJSONObject("message")
                val content = messageObj?.optString("content")
                if (!content.isNullOrBlank()) return content
            }

            // Also support responses.create output format:
            val outputArr = jsonObject.optJSONArray("output")
            if (outputArr != null) {
                for (i in 0 until outputArr.length()) {
                    val item = outputArr.optJSONObject(i)
                    val itemContent = item?.optJSONArray("content")
                    if (itemContent != null) {
                        for (j in 0 until itemContent.length()) {
                            val cObj = itemContent.optJSONObject(j)
                            val text = cObj?.optString("output_text") ?: cObj?.optString("text")
                            if (!text.isNullOrBlank()) {
                                return text
                            }
                        }
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    private fun parseToolResponse(body: String): ToolResponse {
        val root = JSONObject(body)
        val message = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
        val calls = mutableListOf<ToolCall>()
        val rawCalls = message?.optJSONArray("tool_calls") ?: JSONArray()
        for (i in 0 until rawCalls.length()) {
            val call = rawCalls.optJSONObject(i) ?: continue
            val function = call.optJSONObject("function") ?: continue
            calls += ToolCall(
                id = call.optString("id").ifBlank { error("tool_call missing id") },
                name = function.optString("name").ifBlank { error("tool_call missing name") },
                argumentsJson = function.optString("arguments").ifBlank { "{}" }
            )
        }
        return ToolResponse(message?.optString("content")?.takeIf { it.isNotBlank() }, calls, body)
    }

    private fun isToolOrParsingConflict(body: String): Boolean {
        return body.contains("Tool choice is none", ignoreCase = true) ||
                body.contains("Parsing failed", ignoreCase = true) ||
                body.contains("failed_generation", ignoreCase = true) ||
                body.contains("model called a tool", ignoreCase = true)
    }

    /**
     * Verifies the API connection using the active primary key and endpoint.
     */
    suspend fun testConnection(): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = aiPreferences.getActivePrimaryApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("لم يتم العثور على أي مفتاح API نشط. يرجى إدخال أو استيراد المفاتيح أولاً."))
        }

        val cleanUrl = aiPreferences.baseUrl.trim().removeSuffix("/")
        val endpoint = if (cleanUrl.endsWith("/chat/completions")) cleanUrl else "$cleanUrl/chat/completions"
        var model = aiPreferences.model.trim().ifBlank { AiPreferences.DEFAULT_GROQ_MODEL }

        try {
            val messages = listOf(
                ChatMessage(role = "user", content = "مرحبا، هل أنت متصل؟ أجب بكلمة واحدة فقط: نعم")
            )

            var (code, responseBody) = executeChatHttp(endpoint, model, messages, 0.3, apiKey)

            // Auto-heal if tool choice error occurs during test
            if (code == 400 && isToolOrParsingConflict(responseBody)) {
                model = if (endpoint.contains("groq.com")) AiPreferences.MODEL_GROQ_GPT_OSS_120B else AiPreferences.DEFAULT_GROQ_MODEL
                aiPreferences.model = model
                val retry = executeChatHttp(endpoint, model, messages, 0.3, apiKey)
                code = retry.first
                responseBody = retry.second
            }

            // Auto-heal if 404 occurs on Groq because model was deprecated
            if (code == 404 && endpoint.contains("groq.com") && model != AiPreferences.MODEL_GROQ_GPT_OSS_120B) {
                model = AiPreferences.MODEL_GROQ_GPT_OSS_120B
                aiPreferences.model = model
                val retry = executeChatHttp(endpoint, model, messages, 0.3, apiKey)
                code = retry.first
                responseBody = retry.second
            }

            if (code in 200..299) {
                val count = aiPreferences.keysCount
                val modelName = aiPreferences.model
                Result.success("تم الاتصال بالخادم بنجاح! المفاتيح الجاهزة: ($count مفاتيح)، النموذج النشط: $modelName.")
            } else {
                if (code in listOf(401, 403, 429)) {
                    aiPreferences.recordKeyFailureAndDemote(apiKey)
                }
                Result.failure(Exception(parseErrorMessage(code, responseBody, endpoint, model)))
            }
        } catch (e: Exception) {
            Result.failure(Exception(e.localizedMessage ?: "فشل الاتصال بالخادم. تأكد من اتصال الإنترنت وصحة الرابط.", e))
        }
    }

    private fun parseErrorMessage(code: Int, body: String, endpoint: String = "", model: String = ""): String {
        return try {
            val obj = JSONObject(body)
            val errorObj = obj.optJSONObject("error")
            val serverMessage = errorObj?.optString("message") ?: body

            when (code) {
                400 -> {
                    if (isToolOrParsingConflict(body)) {
                        "تنبيه المزود (400 Tool Choice Conflict): النموذج واجه تعارضاً في استدعاء الأدوات. تم تصحيح هذا السلوك تلقائياً."
                    } else {
                        "طلب غير صالح (400): $serverMessage"
                    }
                }
                401 -> "خطأ مصادقة (401 Unauthorized): مفتاح API غير صالح أو تم إلغاؤه من مزود الخدمة. تأكد من نسخ المفتاح كاملاً."
                403 -> "ممنوع الوصول (403 Forbidden): الحساب أو المفتاح لا يملك صلاحية الوصول لهذا النموذج أو الرابط."
                404 -> {
                    if (endpoint.contains("groq.com") || body.contains("model", ignoreCase = true) || serverMessage.contains("model", ignoreCase = true)) {
                        "خطأ (404 Not Found): النموذج السابق لم يعد متوفراً على باقة Groq المجانية (قامت Groq بإيقاف نماذج Llama القديمة مؤخراً). تم تفعيل التبديل التلقائي إلى openai/gpt-oss-120b أو يمكنك اختيار مزود مجاني دائم مثل Google Gemini أو OpenRouter من الإعدادات."
                    } else {
                        "غير موجود (404 Not Found): الرابط المحدد أو اسم النموذج غير متاح على خادم المزود."
                    }
                }
                429 -> "تجاوز حد الطلبات (429 Rate Limit): تم استهلاك رصيد المفتاح الحالي أو تجاوز معدل الطلبات. سيتم تدوير المفتاح للاحتياطي تلقائياً."
                500, 502, 503 -> "خطأ في خوادم مزود الخدمة ($code): يرجى المحاولة لاحقاً أو التبديل لمزود آخر."
                else -> "خطأ من مزود الخدمة ($code): $serverMessage"
            }
        } catch (e: Exception) {
            "استجابة خطأ ($code): $body"
        }
    }
}
