package com.example.presentation.ai

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entities.AiConversationEntity
import java.text.SimpleDateFormat
import java.util.*

/**
 * Authentic Telegram-style AI Conversational Screen featuring:
 * - Rem (ريم 💙) & Ram (رام 🌸) from Re:Zero as personal assistants
 * - Telegram chat background wallpaper pattern (img_telegram_bg)
 * - Clickable Avatar & Header opening the Character Profile View
 * - Telegram quoted reply banner and reply actions on bubbles
 * - Markdown tables, code blocks, formatted lists, and emoji preservation
 * - Dynamic persona switcher between Rem and Ram
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiHubScreen(
    viewModel: AiHubViewModel,
    modifier: Modifier = Modifier,
    onNavigateToSettings: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showHistorySheet by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var conversationToDelete by remember { mutableStateOf<AiConversationEntity?>(null) }
    var inputText by remember { mutableStateOf("") }
    var showEmojiKeyboard by remember { mutableStateOf(false) }

    val activeConversation = remember(uiState.conversations, uiState.currentConversationId) {
        uiState.conversations.firstOrNull { it.id == uiState.currentConversationId }
    }

    val isRem = uiState.activePersona.equals("REM", ignoreCase = true)
    val personaName = if (isRem) "ريم (Rem)" else "رام (Ram)"
    val personaColor = if (isRem) Color(0xFF2481CC) else Color(0xFFC2185B)
    val avatarRes = if (isRem) R.drawable.img_rem_avatar else R.drawable.img_ram_avatar

    val isDark = isSystemInDarkTheme()

    // Authentic Telegram Theme Palette
    // Telegram's Android header is deliberately neutral; persona color belongs to
    // the assistant avatar and send affordance, not the whole app chrome.
    val telegramTopBarColor = if (isDark) Color(0xFF17212B) else Color(0xFF5682A3)
    val telegramBgColor = if (isDark) Color(0xFF0F1821) else Color(0xFFE4ECE0)
    val telegramInputBg = if (isDark) Color(0xFF17212B) else Color(0xFFFFFFFF)

    LaunchedEffect(uiState.toastMessage) {
        uiState.toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToast()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showProfileDialog = true }
                    ) {
                        // Circular Character Avatar
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                        ) {
                            Image(
                                painter = painterResource(id = avatarRes),
                                contentDescription = personaName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = personaName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF64D877))
                                )
                                Text(
                                    text = "متصل الآن",
                                    fontSize = 11.sp,
                                    color = Color(0xFFA8D7FF),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { showHistorySheet = true }) {
                        Icon(
                            Icons.Default.Menu,
                            contentDescription = "سجل المحادثات",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // Quick Persona Toggle Button (Rem <-> Ram)
                    IconButton(
                        onClick = {
                            val nextPersona = if (isRem) "RAM" else "REM"
                            viewModel.setPersona(nextPersona)
                        }
                    ) {
                        Icon(
                            Icons.Default.SwapHoriz,
                            contentDescription = "تبديل الشخصية (ريم / رام)",
                            tint = Color.White
                        )
                    }

                    // New Chat
                    IconButton(onClick = { viewModel.createNewConversation() }) {
                        Icon(
                            Icons.Default.AddComment,
                            contentDescription = "محادثة جديدة",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = telegramTopBarColor
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(telegramBgColor)
        ) {
            // Telegram Chat Wallpaper Layer
            Image(
                painter = painterResource(id = R.drawable.img_telegram_bg),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = if (isDark) 0.12f else 0.22f,
                modifier = Modifier.fillMaxSize()
            )

            Column(modifier = Modifier.fillMaxSize()) {
                // Notice if running in autonomous local mode
                if (!uiState.isAutonomousCloud) {
                    Surface(
                        color = (if (isDark) Color(0xFF1E2C3A) else Color(0xFFF0F4F8)).copy(alpha = 0.95f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    Icons.Default.Info,
                                    contentDescription = null,
                                    tint = personaColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    "المحرك المحلي نشط — فعّل الذكاء السحابي من الإعدادات عند الحاجة.",
                                    fontSize = 11.sp,
                                    color = if (isDark) Color(0xFFCFD8DC) else Color(0xFF37474F)
                                )
                            }
                            TextButton(
                                onClick = onNavigateToSettings,
                                contentPadding = PaddingValues(horizontal = 6.dp)
                            ) {
                                Text("الإعدادات", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = personaColor)
                            }
                        }
                    }
                }

                // Chat Messages List
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    val listState = rememberLazyListState()

                    // Auto-scroll to bottom on new message
                    LaunchedEffect(uiState.messages.size, uiState.isAgentTyping) {
                        if (uiState.messages.isNotEmpty()) {
                            listState.animateScrollToItem(uiState.messages.size - 1)
                        }
                    }

                    if (uiState.messages.isEmpty() && !uiState.isAgentTyping) {
                        TelegramEmptyChatGreeting(
                            activePersona = uiState.activePersona,
                            onOpenProfile = { showProfileDialog = true },
                            onSelectSuggestion = { suggestion ->
                                viewModel.sendUserMessage(suggestion)
                            }
                        )
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            // Telegram floating Date Badge at top
                            item {
                                TelegramDateBadge(dateText = "اليوم")
                            }

                            items(uiState.messages, key = { it.id }) { message ->
                                TelegramChatBubbleItem(
                                    message = message,
                                    activePersona = activeConversation?.persona ?: uiState.activePersona,
                                    onReplyToMessage = { msg ->
                                        viewModel.setReplyingTo(msg)
                                    },
                                    onOpenProfile = { showProfileDialog = true }
                                )
                            }

                            // Agent processing/thinking indicator
                            if (uiState.isAgentTyping) {
                                item {
                                    TelegramAgentThinkingBubble(
                                        statusText = uiState.agentStatusText,
                                        activePersona = uiState.activePersona,
                                        onOpenProfile = { showProfileDialog = true }
                                    )
                                }
                            }
                        }
                    }
                }

                // Quick Prompt Chips
                QuickPromptChipsRow(
                    onPromptSelected = { prompt ->
                        viewModel.sendUserMessage(prompt)
                    }
                )

                // Docked Telegram Reply Preview Banner
                AnimatedVisibility(
                    visible = uiState.replyingToMessage != null,
                    enter = slideInVertically { it } + fadeIn(),
                    exit = slideOutVertically { it } + fadeOut()
                ) {
                    uiState.replyingToMessage?.let { replyTarget ->
                        TelegramReplyInputBanner(
                            replyToMessage = replyTarget,
                            activePersona = uiState.activePersona,
                            onCancelReply = { viewModel.setReplyingTo(null) }
                        )
                    }
                }

                // Message Input Bar (Authentic Telegram Style)
                Surface(
                    tonalElevation = 2.dp,
                    color = telegramInputBg,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Emoji sticker icon (Telegram signature left icon)
                        IconButton(
                            onClick = { showEmojiKeyboard = !showEmojiKeyboard },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (showEmojiKeyboard) Icons.Default.Keyboard else Icons.Default.Mood,
                                contentDescription = if (showEmojiKeyboard) "لوحة المفاتيح" else "رموز تعبيرية",
                                tint = if (showEmojiKeyboard) personaColor else (if (isDark) Color(0xFF869AA8) else Color(0xFF707579)),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Seamless Telegram Message Input Field
                        TextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = {
                                Text(
                                    "رسالة...",
                                    fontSize = 14.sp,
                                    color = if (isDark) Color(0xFF869AA8) else Color(0xFF8E959B)
                                )
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(22.dp),
                            maxLines = 4,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            colors = TextFieldDefaults.colors(
                                unfocusedContainerColor = if (isDark) Color(0xFF242F3D) else Color(0xFFF1F3F5),
                                focusedContainerColor = if (isDark) Color(0xFF242F3D) else Color(0xFFF1F3F5),
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                disabledIndicatorColor = Color.Transparent,
                                focusedTextColor = if (isDark) Color.White else Color.Black,
                                unfocusedTextColor = if (isDark) Color.White else Color.Black,
                                cursorColor = personaColor
                            )
                        )

                        // Telegram send button becomes a stop control while the agent is busy.
                        IconButton(
                            onClick = {
                                if (uiState.isAgentTyping) {
                                    viewModel.cancelCurrentResponse()
                                } else {
                                    val msg = inputText.trim()
                                    if (msg.isNotEmpty()) {
                                        viewModel.sendUserMessage(msg)
                                        inputText = ""
                                        showEmojiKeyboard = false
                                    }
                                }
                            },
                            enabled = uiState.isAgentTyping || inputText.isNotBlank(),
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(
                                    if (uiState.isAgentTyping || inputText.isNotBlank())
                                        personaColor
                                    else
                                        (if (isDark) Color(0xFF242F3D) else Color(0xFFE0E5EA))
                                )
                        ) {
                            Icon(
                                if (uiState.isAgentTyping) Icons.Default.Stop else Icons.AutoMirrored.Filled.Send,
                                contentDescription = if (uiState.isAgentTyping) "إيقاف الرد" else "إرسال الرسالة",
                                tint = if (uiState.isAgentTyping || inputText.isNotBlank())
                                    Color.White
                                else
                                    (if (isDark) Color(0xFF566573) else Color(0xFFA0AAB3)),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Telegram Emoji Keyboard Panel
                if (showEmojiKeyboard) {
                    Surface(
                        color = if (isDark) Color(0xFF1E2C3A) else Color(0xFFF0F4F8),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    ) {
                        val emojis = remember {
                            listOf(
                                "😊", "😂", "🥰", "😍", "👍", "❤️", "🔥", "🎉",
                                "👏", "💡", "⚡", "🌸", "💙", "☕", "📝", "📅",
                                "💰", "🚀", "🎯", "✨", "💪", "🙌", "🤔", "👀",
                                "⭐", "✅", "❌", "📌", "📊", "🤝", "👌", "😎",
                                "😴", "🙏", "💯", "📈", "🛡️", "🔑", "🔍", "📱"
                            )
                        }
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(8),
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(emojis) { emoji ->
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            inputText += emoji
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(emoji, fontSize = 22.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Telegram Character Profile Dialog (Rem / Ram)
    if (showProfileDialog) {
        CharacterProfileDialog(
            activePersona = uiState.activePersona,
            onSwitchPersona = { newPersona ->
                viewModel.setPersona(newPersona)
            },
            onDismiss = { showProfileDialog = false },
            onNavigateToSettings = onNavigateToSettings
        )
    }

    // Conversation History Sheet
    if (showHistorySheet) {
        ModalBottomSheet(
            onDismissRequest = { showHistorySheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            ConversationHistoryContent(
                conversations = uiState.conversations,
                activeId = uiState.currentConversationId,
                activePersona = uiState.activePersona,
                onSelectConversation = { id ->
                    viewModel.selectConversation(id)
                    showHistorySheet = false
                },
                onNewConversation = {
                    viewModel.createNewConversation()
                    showHistorySheet = false
                },
                onDeleteConversation = { conv ->
                    conversationToDelete = conv
                }
            )
        }
    }

    // Delete Conversation Confirmation Dialog
    conversationToDelete?.let { conv ->
        AlertDialog(
            onDismissRequest = { conversationToDelete = null },
            title = { Text("حذف المحادثة؟") },
            text = { Text("هل تريد بالتأكيد حذف \"${conv.title}\"؟ سيتم مسح كافة رسائلها.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteConversation(conv.id)
                        conversationToDelete = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { conversationToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    uiState.pendingConfirmationCommand?.let { command ->
        AlertDialog(
            onDismissRequest = { viewModel.rejectPendingAction() },
            title = { Text("تأكيد عملية حساسة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(uiState.pendingConfirmationReason ?: "هذه العملية ستغيّر بيانات التطبيق.")
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = command,
                            modifier = Modifier.padding(10.dp),
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                    Text("لن يتم التنفيذ قبل اختيار تأكيد صريح منك.", style = MaterialTheme.typography.labelMedium)
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.confirmPendingAction() }) { Text("تأكيد التنفيذ") }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.rejectPendingAction() }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun TelegramEmptyChatGreeting(
    activePersona: String,
    onOpenProfile: () -> Unit,
    onSelectSuggestion: (String) -> Unit
) {
    val isRem = activePersona.equals("REM", ignoreCase = true)
    val personaName = if (isRem) "ريم (Rem)" else "رام (Ram)"
    val personaColor = if (isRem) Color(0xFF1E88E5) else Color(0xFFD81B60)
    val avatarRes = if (isRem) R.drawable.img_rem_avatar else R.drawable.img_ram_avatar

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Character Avatar with click to open profile
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .border(3.dp, personaColor, CircleShape)
                .clickable { onOpenProfile() }
        ) {
            Image(
                painter = painterResource(id = avatarRes),
                contentDescription = personaName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = if (isRem) "مرحباً بك، أنا ريم 💙" else "مرحباً بك، أنا رام 🌸",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = if (isRem)
                "المساعد الذكي لتنظيم مهامك، ومتابعة مشاريعك، وإدارة مواردك المالية في Always Busy."
            else
                "المستشار التحليلي الاستراتيجي لترتيب الأولويات، وضبط المهام، وتحليل الخطط المالية بدقة وحزم.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "اقتراحات سريعة للبدء:",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = personaColor
        )

        Spacer(modifier = Modifier.height(8.dp))

        val starterPrompts = listOf(
            "ما هي مهامي المتبقية لليوم؟",
            "لخص لي صافي الثروة وإجمالي الديون الحالية في جدول",
            "سجل مهمة جديدة لمتابعة ري القمح صباح الغد مع منبه",
            "أضف حركة مصروف بقيمة 25,000 ل.س لشراء وقود"
        )

        starterPrompts.forEach { prompt ->
            OutlinedCard(
                onClick = { onSelectSuggestion(prompt) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.outlinedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.ChatBubbleOutline,
                        contentDescription = null,
                        tint = personaColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(prompt, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun QuickPromptChipsRow(
    onPromptSelected: (String) -> Unit
) {
    val quickChips = listOf(
        "📊 جدول الملخص",
        "🌾 ري القمح",
        "💰 فحص الميزانية",
        "📝 إضافة مهمة جديدة"
    )

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(quickChips) { chip ->
            SuggestionChip(
                onClick = { onPromptSelected(chip.substring(2).trim()) },
                label = { Text(chip, fontSize = 11.sp) }
            )
        }
    }
}

@Composable
private fun ConversationHistoryContent(
    conversations: List<AiConversationEntity>,
    activeId: Long?,
    activePersona: String,
    onSelectConversation: (Long) -> Unit,
    onNewConversation: () -> Unit,
    onDeleteConversation: (AiConversationEntity) -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .padding(bottom = 24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "سجل محادثات تيليجرام AI",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Button(
                onClick = onNewConversation,
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("محادثة جديدة")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (conversations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("لا توجد محادثات مسجلة بعد", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(conversations, key = { it.id }) { conv ->
                    val isSelected = conv.id == activeId
                    val isConvRem = conv.persona.equals("REM", ignoreCase = true)
                    val pColor = if (isConvRem) Color(0xFF1E88E5) else Color(0xFFD81B60)

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected)
                                MaterialTheme.colorScheme.primaryContainer
                            else
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectConversation(conv.id) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        conv.title,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = pColor.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            if (isConvRem) "ريم 💙" else "رام 🌸",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = pColor,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text(
                                    dateFormat.format(Date(conv.updatedAt)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(
                                onClick = { onDeleteConversation(conv) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = "حذف المحادثة",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
