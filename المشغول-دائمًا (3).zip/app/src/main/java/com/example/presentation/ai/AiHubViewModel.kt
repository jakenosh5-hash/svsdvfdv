package com.example.presentation.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.AppContainer
import com.example.data.local.entities.*
import com.example.domain.agent.AutonomousAgentCoordinator
import com.example.domain.backup.BackupAndExportEngine
import com.example.domain.knowledge.AutonomousKnowledgeService
import com.example.network.LlmApiClient
import com.example.security.AiPreferences
import com.example.services.IAiAutomationService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TerminalLogEntry(
    val command: String,
    val outputUser: String,
    val outputJson: String,
    val isSuccess: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class AiHubUiState(
    val selectedSubTab: Int = 0, // 0: AI Agent Chat, 1: Knowledge Indexes & Chapters, 2: AI Settings & API, 3: Scopes & Audit, 4: Backup
    val conversations: List<AiConversationEntity> = emptyList(),
    val currentConversationId: Long? = null,
    val messages: List<AiMessageEntity> = emptyList(),
    val isAgentTyping: Boolean = false,
    val agentStatusText: String? = null,
    val executedActionsLog: List<String> = emptyList(),
    val storedMemoriesLog: List<String> = emptyList(),

    // Knowledge & Autonomous Hierarchical Memory
    val indexes: List<KnowledgeIndexEntity> = emptyList(),
    val sections: List<KnowledgeSectionEntity> = emptyList(),
    val knowledgeMemories: List<KnowledgeMemoryEntity> = emptyList(),
    val selectedIndexId: Long? = null,
    val knowledgeSearchQuery: String = "",

    // AI Provider Configuration (Grok, OpenAI, Gemini, Custom)
    val apiKey: String = "",
    val apiProvider: String = AiPreferences.PROVIDER_GROK,
    val apiBaseUrl: String = AiPreferences.DEFAULT_GROK_URL,
    val apiModel: String = AiPreferences.DEFAULT_GROK_MODEL,
    val isAutonomousCloud: Boolean = false,
    val isTestingApi: Boolean = false,
    val apiTestResult: String? = null,

    // Terminal & Audit
    val terminalInput: String = "",
    val terminalLogs: List<TerminalLogEntry> = emptyList(),
    val commandHistory: List<String> = emptyList(),
    val historyCursor: Int = -1,
    val scopes: List<SecurityScopeEntity> = emptyList(),
    val auditLogs: List<AuditLogEntity> = emptyList(),
    val lastExportResult: BackupAndExportEngine.ExportResult? = null,
    val denseSnapshot: String? = null,
    val toastMessage: String? = null,
    val activePersona: String = "REM",
    val replyingToMessage: AiMessageEntity? = null,
    val pendingConfirmationCommand: String? = null,
    val pendingConfirmationReason: String? = null
)

class AiHubViewModel(
    private val aiService: IAiAutomationService,
    private val agentCoordinator: AutonomousAgentCoordinator,
    private val knowledgeService: AutonomousKnowledgeService,
    private val aiPreferences: AiPreferences,
    private val llmClient: LlmApiClient
) : ViewModel() {

    private val _uiState = MutableStateFlow(AiHubUiState())
    val uiState: StateFlow<AiHubUiState> = _uiState.asStateFlow()

    init {
        loadData()
        loadAiConfig()
    }

    private fun loadAiConfig() {
        _uiState.update {
            it.copy(
                apiKey = aiPreferences.apiKey,
                apiProvider = aiPreferences.provider,
                apiBaseUrl = aiPreferences.baseUrl,
                apiModel = aiPreferences.model,
                isAutonomousCloud = aiPreferences.isConfigured,
                activePersona = aiPreferences.activePersona
            )
        }
    }

    private fun loadData() {
        viewModelScope.launch {
            aiService.getActiveConversations().collect { convs ->
                val activeId = _uiState.value.currentConversationId ?: convs.firstOrNull()?.id
                if (convs.isEmpty()) {
                    val p = aiPreferences.activePersona
                    val newId = aiService.createConversation("محادثة جديدة", persona = p)
                    _uiState.update { it.copy(currentConversationId = newId, activePersona = p) }
                } else {
                    val activeConv = convs.firstOrNull { it.id == activeId } ?: convs.first()
                    _uiState.update {
                        it.copy(
                            conversations = convs,
                            currentConversationId = activeId,
                            activePersona = activeConv.persona
                        )
                    }
                    listenToMessages(activeId ?: convs.first().id)
                }
            }
        }

        // Load Knowledge Indexes
        viewModelScope.launch {
            knowledgeService.getAllIndexes().collect { idxList ->
                _uiState.update { it.copy(indexes = idxList) }
            }
        }

        // Load Knowledge Sections
        viewModelScope.launch {
            knowledgeService.getAllSections().collect { secList ->
                _uiState.update { it.copy(sections = secList) }
            }
        }

        // Load Knowledge Memories
        viewModelScope.launch {
            knowledgeService.getAllMemories().collect { memList ->
                _uiState.update { it.copy(knowledgeMemories = memList) }
            }
        }

        viewModelScope.launch {
            _uiState.update { it.copy(scopes = aiService.gateway.getScopes()) }
        }

        viewModelScope.launch {
            _uiState.update { it.copy(auditLogs = aiService.gateway.getRecentAuditLogs(20)) }
        }
    }

    private var messagesJob: kotlinx.coroutines.Job? = null
    private var responseJob: kotlinx.coroutines.Job? = null

    private fun listenToMessages(conversationId: Long) {
        messagesJob?.cancel()
        messagesJob = viewModelScope.launch {
            aiService.getMessages(conversationId).collect { msgs ->
                _uiState.update { it.copy(messages = msgs) }
            }
        }
    }

    fun createNewConversation(title: String = "محادثة جديدة", persona: String? = null) {
        viewModelScope.launch {
            val p = persona ?: _uiState.value.activePersona
            val newId = aiService.createConversation(title = title, persona = p)
            _uiState.update { it.copy(currentConversationId = newId, activePersona = p, replyingToMessage = null) }
            listenToMessages(newId)
        }
    }

    fun selectConversation(conversationId: Long) {
        if (_uiState.value.currentConversationId == conversationId) return
        val conv = _uiState.value.conversations.firstOrNull { it.id == conversationId }
        val persona = conv?.persona ?: aiPreferences.activePersona
        _uiState.update { it.copy(currentConversationId = conversationId, activePersona = persona, replyingToMessage = null) }
        listenToMessages(conversationId)
    }

    fun setPersona(persona: String) {
        aiPreferences.activePersona = persona
        viewModelScope.launch {
            val existingConv = _uiState.value.conversations.firstOrNull {
                it.persona.equals(persona, ignoreCase = true) && !it.isArchived
            }
            if (existingConv != null) {
                _uiState.update {
                    it.copy(
                        currentConversationId = existingConv.id,
                        activePersona = persona,
                        replyingToMessage = null
                    )
                }
                listenToMessages(existingConv.id)
            } else {
                val title = if (persona.equals("RAM", ignoreCase = true)) "محادثة رام 🌸" else "محادثة ريم 💙"
                val newId = aiService.createConversation(title = title, persona = persona)
                _uiState.update {
                    it.copy(
                        currentConversationId = newId,
                        activePersona = persona,
                        replyingToMessage = null
                    )
                }
                listenToMessages(newId)
            }
        }
    }

    fun setReplyingTo(message: AiMessageEntity?) {
        _uiState.update { it.copy(replyingToMessage = message) }
    }

    fun deleteConversation(conversationId: Long) {
        viewModelScope.launch {
            aiService.deleteConversation(conversationId)
            val currentList = _uiState.value.conversations.filter { it.id != conversationId }
            if (currentList.isNotEmpty()) {
                val nextId = currentList.first().id
                _uiState.update { it.copy(conversations = currentList, currentConversationId = nextId) }
                listenToMessages(nextId)
            } else {
                val newId = aiService.createConversation("محادثة جديدة")
                _uiState.update { it.copy(currentConversationId = newId) }
                listenToMessages(newId)
            }
        }
    }

    fun selectSubTab(tabIndex: Int) {
        _uiState.update { it.copy(selectedSubTab = tabIndex) }
        if (tabIndex == 3) {
            refreshScopesAndAudit()
        }
    }

    fun selectIndex(indexId: Long?) {
        _uiState.update { it.copy(selectedIndexId = indexId) }
    }

    fun onKnowledgeSearchQueryChange(query: String) {
        _uiState.update { it.copy(knowledgeSearchQuery = query) }
        viewModelScope.launch {
            if (query.isBlank()) {
                val all = knowledgeService.getAllMemories().first()
                _uiState.update { it.copy(knowledgeMemories = all) }
            } else {
                val matches = knowledgeService.searchMemories(query)
                _uiState.update { it.copy(knowledgeMemories = matches) }
            }
        }
    }

    /**
     * Sends message using the Autonomous Agent Coordinator:
     * - Multi-turn search across indexes/sections
     * - Memory distillation & auto-filing in knowledge base
     * - Background action execution (hand/arm)
     */
    fun sendUserMessage(text: String, replyTo: AiMessageEntity? = null) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        val convId = _uiState.value.currentConversationId ?: return
        val actualReplyTo = replyTo ?: _uiState.value.replyingToMessage

        // Clear reply box once sending
        _uiState.update { it.copy(replyingToMessage = null) }

        // A second tap must not create two concurrent agent turns for the same chat.
        responseJob?.cancel()
        responseJob = viewModelScope.launch {
            try {
            agentCoordinator.processUserMessage(convId, trimmed, actualReplyTo).collect { status ->
                when (status) {
                    is AutonomousAgentCoordinator.AgentStatus.Thinking -> {
                        _uiState.update {
                            it.copy(
                                isAgentTyping = true,
                                agentStatusText = status.message
                            )
                        }
                    }
                    is AutonomousAgentCoordinator.AgentStatus.SearchingMemory -> {
                        _uiState.update {
                            it.copy(
                                isAgentTyping = true,
                                agentStatusText = "🧠 جاري البحث في فهارس المعرفة: ${status.query}..."
                            )
                        }
                    }
                    is AutonomousAgentCoordinator.AgentStatus.ExecutingCommand -> {
                        _uiState.update {
                            it.copy(
                                isAgentTyping = true,
                                agentStatusText = "⚡ الذراع المنفذ: تنفيذ أمر أتمتة [${status.action}]..."
                            )
                        }
                    }
                    is AutonomousAgentCoordinator.AgentStatus.NeedsConfirmation -> {
                        _uiState.update {
                            it.copy(
                                isAgentTyping = false,
                                agentStatusText = null,
                                pendingConfirmationCommand = status.command,
                                pendingConfirmationReason = status.reason
                            )
                        }
                    }
                    is AutonomousAgentCoordinator.AgentStatus.DistillingMemory -> {
                        _uiState.update {
                            it.copy(
                                isAgentTyping = true,
                                agentStatusText = "📝 توثيق ذاكرة تراكمية مقطرة في [${status.section}]..."
                            )
                        }
                    }
                    is AutonomousAgentCoordinator.AgentStatus.Success -> {
                        _uiState.update {
                            it.copy(
                                isAgentTyping = false,
                                agentStatusText = null,
                                executedActionsLog = status.turnResponse.executedActions,
                                storedMemoriesLog = status.turnResponse.storedMemories,
                                isAutonomousCloud = status.turnResponse.isAutonomousCloud
                            )
                        }
                        refreshScopesAndAudit()
                    }
                    is AutonomousAgentCoordinator.AgentStatus.Error -> {
                        _uiState.update {
                            it.copy(
                                isAgentTyping = false,
                                agentStatusText = null,
                                toastMessage = status.errorMessage
                            )
                        }
                    }
                }
            }
            } catch (_: kotlinx.coroutines.CancellationException) {
                // Cancellation is an expected user action, not an error toast.
            } catch (error: Throwable) {
                _uiState.update {
                    it.copy(
                        isAgentTyping = false,
                        agentStatusText = null,
                        toastMessage = error.localizedMessage ?: "تعذر إكمال الرد. حاول مرة أخرى."
                    )
                }
            } finally {
                _uiState.update { it.copy(isAgentTyping = false, agentStatusText = null) }
            }
        }
    }

    fun confirmPendingAction() {
        val command = _uiState.value.pendingConfirmationCommand ?: return
        val conversationId = _uiState.value.currentConversationId ?: return
        _uiState.update {
            it.copy(
                pendingConfirmationCommand = null,
                pendingConfirmationReason = null,
                isAgentTyping = true,
                agentStatusText = "⚡ تنفيذ الأمر بعد تأكيدك..."
            )
        }
        responseJob?.cancel()
        responseJob = viewModelScope.launch {
            try {
                agentCoordinator.processConfirmedCommand(conversationId, command).collect { status ->
                    when (status) {
                        is AutonomousAgentCoordinator.AgentStatus.ExecutingCommand -> _uiState.update {
                            it.copy(isAgentTyping = true, agentStatusText = "⚡ تنفيذ: ${status.action}")
                        }
                        is AutonomousAgentCoordinator.AgentStatus.Success -> _uiState.update {
                            it.copy(
                                isAgentTyping = false,
                                agentStatusText = null,
                                executedActionsLog = status.turnResponse.executedActions,
                                toastMessage = status.turnResponse.assistantMessage
                            )
                        }
                        is AutonomousAgentCoordinator.AgentStatus.Error -> _uiState.update {
                            it.copy(isAgentTyping = false, agentStatusText = null, toastMessage = status.errorMessage)
                        }
                        else -> Unit
                    }
                }
            } finally {
                _uiState.update { it.copy(isAgentTyping = false, agentStatusText = null) }
            }
        }
    }

    fun rejectPendingAction() {
        _uiState.update {
            it.copy(
                pendingConfirmationCommand = null,
                pendingConfirmationReason = null,
                toastMessage = "تم إلغاء العملية ولم تُنفذ."
            )
        }
    }

    /** Stops the active turn while preserving all already-persisted messages. */
    fun cancelCurrentResponse() {
        responseJob?.cancel()
        responseJob = null
        _uiState.update {
            it.copy(
                isAgentTyping = false,
                agentStatusText = null,
                toastMessage = "تم إيقاف الرد الحالي."
            )
        }
    }

    override fun onCleared() {
        responseJob?.cancel()
        messagesJob?.cancel()
        super.onCleared()
    }

    // --- Provider and API Config ---
    fun updateApiKey(key: String) {
        aiPreferences.apiKey = key
        _uiState.update { it.copy(apiKey = key, isAutonomousCloud = key.isNotBlank()) }
    }

    fun selectProviderPreset(provider: String) {
        aiPreferences.applyPreset(provider)
        _uiState.update {
            it.copy(
                apiProvider = aiPreferences.provider,
                apiBaseUrl = aiPreferences.baseUrl,
                apiModel = aiPreferences.model
            )
        }
    }

    fun updateBaseUrl(url: String) {
        aiPreferences.baseUrl = url
        _uiState.update { it.copy(apiBaseUrl = url) }
    }

    fun updateModel(model: String) {
        aiPreferences.model = model
        _uiState.update { it.copy(apiModel = model) }
    }

    fun testApiConnection() {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingApi = true, apiTestResult = null) }
            val res = llmClient.testConnection()
            val msg = if (res.isSuccess) {
                res.getOrNull() ?: "تم الاتصال بنجاح!"
            } else {
                "فشل الاتصال: " + (res.exceptionOrNull()?.message ?: "خطأ غير معروف")
            }
            _uiState.update { it.copy(isTestingApi = false, apiTestResult = msg) }
        }
    }

    // --- Knowledge Creation ---
    fun createIndex(name: String, description: String? = null) {
        viewModelScope.launch {
            knowledgeService.getOrCreateSubIndex(name, description)
            _uiState.update { it.copy(toastMessage = "تم إنشاء الفهرس: $name") }
        }
    }

    fun createSection(indexName: String, sectionName: String, description: String? = null) {
        viewModelScope.launch {
            knowledgeService.getOrCreateSection(indexName, sectionName, description)
            _uiState.update { it.copy(toastMessage = "تم إنشاء الباب: $sectionName") }
        }
    }

    fun deleteKnowledgeMemory(id: Long) {
        viewModelScope.launch {
            knowledgeService.deleteMemory(id)
            _uiState.update { it.copy(toastMessage = "تم حذف الذاكرة المقطرة.") }
        }
    }

    // --- Terminal & Scopes ---
    fun onTerminalInputChange(newInput: String) {
        _uiState.update { it.copy(terminalInput = newInput) }
    }

    fun executeTerminal(inputOverride: String? = null) {
        val cmd = (inputOverride ?: _uiState.value.terminalInput).trim()
        if (cmd.isEmpty()) return

        viewModelScope.launch {
            val result = aiService.executeTerminalCommand(cmd)
            val logEntry = TerminalLogEntry(
                command = cmd,
                outputUser = result.outputUser,
                outputJson = result.outputJson,
                isSuccess = result.isSuccess
            )

            val updatedHistory = (_uiState.value.commandHistory + cmd).takeLast(50)
            val updatedLogs = (_uiState.value.terminalLogs + logEntry).takeLast(100)

            _uiState.update {
                it.copy(
                    terminalInput = "",
                    terminalLogs = updatedLogs,
                    commandHistory = updatedHistory,
                    historyCursor = -1
                )
            }
            refreshScopesAndAudit()
        }
    }

    fun toggleScope(scopeName: String, isGranted: Boolean) {
        viewModelScope.launch {
            aiService.gateway.setScope(scopeName, isGranted)
            refreshScopesAndAudit()
        }
    }

    fun refreshScopesAndAudit() {
        viewModelScope.launch {
            val scopes = aiService.gateway.getScopes()
            val audits = aiService.gateway.getRecentAuditLogs(25)
            _uiState.update { it.copy(scopes = scopes, auditLogs = audits) }
        }
    }

    fun exportFullBackup() {
        viewModelScope.launch {
            val res = aiService.backupEngine.createFullJsonBackup()
            _uiState.update { it.copy(lastExportResult = res, toastMessage = "تم إنشاء النسخة الاحتياطية بنجاح [${res.filename}]") }
        }
    }

    fun exportFinanceCsv() {
        viewModelScope.launch {
            val res = aiService.backupEngine.exportFinanceCsv()
            _uiState.update { it.copy(lastExportResult = res, toastMessage = "تم تصدير كشف الحسابات [${res.filename}]") }
        }
    }

    fun exportTasksCsv() {
        viewModelScope.launch {
            val res = aiService.backupEngine.exportTasksCsv()
            _uiState.update { it.copy(lastExportResult = res, toastMessage = "تم تصدير ملف المهام [${res.filename}]") }
        }
    }

    fun restoreFullBackup(jsonContent: String) {
        viewModelScope.launch {
            val res = aiService.backupEngine.restoreFullJsonBackup(jsonContent)
            _uiState.update { it.copy(toastMessage = res.message) }
            refreshScopesAndAudit()
        }
    }

    fun generateSystemSnapshot() {
        viewModelScope.launch {
            val snapshot = aiService.gateway.getDenseSystemSnapshot()
            _uiState.update { it.copy(denseSnapshot = snapshot) }
        }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return AiHubViewModel(
                        aiService = container.aiAutomationService,
                        agentCoordinator = container.autonomousAgentCoordinator,
                        knowledgeService = container.knowledgeService,
                        aiPreferences = container.aiPreferences,
                        llmClient = container.llmClient
                    ) as T
                }
            }
    }
}
