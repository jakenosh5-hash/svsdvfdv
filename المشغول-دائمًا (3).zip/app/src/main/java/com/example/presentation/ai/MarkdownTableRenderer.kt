package com.example.presentation.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Rich message parser and renderer for AI responses:
 * - Parses Markdown tables into structured Compose tables
 * - Formats Code Blocks with copy buttons
 * - Handles Bullet and Numbered lists
 * - Preserves emojis and Arabic text cleanly without markdown debris
 */
@Composable
fun FormattedMessageContent(
    content: String,
    isUser: Boolean,
    modifier: Modifier = Modifier
) {
    val blocks = remember(content) { parseContentBlocks(content) }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        blocks.forEach { block ->
            when (block) {
                is ContentBlock.Table -> {
                    MarkdownTableView(table = block, isUser = isUser)
                }
                is ContentBlock.CodeBlock -> {
                    CodeBlockView(block = block)
                }
                is ContentBlock.TextBlock -> {
                    val cleanText = block.text.trim()
                    if (cleanText.isNotEmpty()) {
                        Text(
                            text = cleanText,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                lineHeight = 20.sp,
                                fontSize = 14.sp
                            ),
                            color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

sealed class ContentBlock {
    data class TextBlock(val text: String) : ContentBlock()
    data class Table(val headers: List<String>, val rows: List<List<String>>) : ContentBlock()
    data class CodeBlock(val language: String?, val code: String) : ContentBlock()
}

/**
 * Parses raw text into structured blocks (Text, Table, CodeBlock)
 */
fun parseContentBlocks(raw: String): List<ContentBlock> {
    val blocks = mutableListOf<ContentBlock>()
    val lines = raw.lines()
    var i = 0

    while (i < lines.size) {
        val line = lines[i]

        // 1. Check for Code Block: ```
        if (line.trim().startsWith("```")) {
            val lang = line.trim().removePrefix("```").trim().ifBlank { null }
            val codeBuilder = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trim().startsWith("```")) {
                codeBuilder.appendLine(lines[i])
                i++
            }
            blocks.add(ContentBlock.CodeBlock(lang, codeBuilder.toString().trimEnd()))
            i++
            continue
        }

        // 2. Check for Markdown Table: starts with `|` and subsequent line is separator `|---|`
        if (line.trim().startsWith("|") && line.trim().endsWith("|") && i + 1 < lines.size && isTableSeparator(lines[i + 1])) {
            val headers = parseTableRow(line)
            i += 2 // skip header and separator
            val rows = mutableListOf<List<String>>()
            while (i < lines.size && lines[i].trim().startsWith("|") && lines[i].trim().endsWith("|")) {
                rows.add(parseTableRow(lines[i]))
                i++
            }
            if (headers.isNotEmpty()) {
                blocks.add(ContentBlock.Table(headers, rows))
            }
            continue
        }

        // 3. Normal text accumulation
        val textBuilder = StringBuilder()
        while (i < lines.size) {
            val currentLine = lines[i]
            if (currentLine.trim().startsWith("```") ||
                (currentLine.trim().startsWith("|") && currentLine.trim().endsWith("|") && i + 1 < lines.size && isTableSeparator(lines[i + 1]))
            ) {
                break
            }
            textBuilder.appendLine(currentLine)
            i++
        }
        val textStr = textBuilder.toString()
        if (textStr.isNotBlank()) {
            blocks.add(ContentBlock.TextBlock(textStr))
        }
    }

    return blocks
}

private fun isTableSeparator(line: String): Boolean {
    val trimmed = line.trim()
    return trimmed.startsWith("|") && (trimmed.contains("---") || trimmed.contains("-|-"))
}

private fun parseTableRow(line: String): List<String> {
    return line.trim()
        .removePrefix("|")
        .removeSuffix("|")
        .split("|")
        .map { it.trim() }
}

@Composable
fun MarkdownTableView(
    table: ContentBlock.Table,
    isUser: Boolean,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val headerBg = if (isUser) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
    else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
    val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isUser) MaterialTheme.colorScheme.surface.copy(alpha = 0.15f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
        ) {
            // Header Row
            Row(
                modifier = Modifier
                    .background(headerBg)
                    .padding(vertical = 8.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                table.headers.forEach { header ->
                    Text(
                        text = header,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .widthIn(min = 90.dp)
                            .padding(horizontal = 8.dp)
                    )
                }
            }

            HorizontalDivider(color = borderColor, thickness = 1.dp)

            // Data Rows
            table.rows.forEachIndexed { index, row ->
                val rowBg = if (index % 2 == 0) Color.Transparent
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)

                Row(
                    modifier = Modifier
                        .background(rowBg)
                        .padding(vertical = 6.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    table.headers.indices.forEach { colIdx ->
                        val cellText = row.getOrNull(colIdx) ?: ""
                        Text(
                            text = cellText,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .widthIn(min = 90.dp)
                                .padding(horizontal = 8.dp)
                        )
                    }
                }
                if (index < table.rows.size - 1) {
                    HorizontalDivider(color = borderColor.copy(alpha = 0.3f), thickness = 0.5.dp)
                }
            }
        }
    }
}

@Composable
fun CodeBlockView(
    block: ContentBlock.CodeBlock,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF1E1E2E), // Dark code background
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = block.language?.uppercase() ?: "CODE",
                    color = Color(0xFF89B4FA),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                IconButton(
                    onClick = { clipboardManager.setText(AnnotatedString(block.code)) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        Icons.Default.ContentCopy,
                        contentDescription = "نسخ الكود",
                        tint = Color(0xFFA6ADC8),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            val scrollState = rememberScrollState()
            Text(
                text = block.code,
                color = Color(0xFFCDD6F4),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 18.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
            )
        }
    }
}
