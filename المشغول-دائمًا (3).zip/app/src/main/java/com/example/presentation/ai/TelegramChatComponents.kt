package com.example.presentation.ai

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entities.AiMessageEntity
import java.text.SimpleDateFormat
import java.util.*

/**
 * Authentic Telegram-style Chat Bubble with:
 * - Characteristic Telegram bubble colors (Mint #EFFDDE / Dark Blue #2B5278)
 * - Rounded bubble tails (3dp on corner)
 * - Quoted reply preview inside the bubble
 * - Character avatar (Rem/Ram) with profile click
 * - Preserved Emojis and structured tables
 * - Double checkmark timestamp row
 * - Quick reply action button
 */
@Composable
fun TelegramChatBubbleItem(
    message: AiMessageEntity,
    activePersona: String,
    onReplyToMessage: (AiMessageEntity) -> Unit,
    onOpenProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.sender.equals("USER", ignoreCase = true)
    val isRem = when {
        message.sender.contains("RAM", ignoreCase = true) -> false
        message.sender.contains("REM", ignoreCase = true) -> true
        else -> activePersona.equals("REM", ignoreCase = true)
    }
    val personaName = if (isRem) "ريم" else "رام"
    val personaEmoji = if (isRem) "💙" else "🌸"
    val personaAccent = if (isRem) Color(0xFF2481CC) else Color(0xFFD81B60)
    val avatarRes = if (isRem) R.drawable.img_rem_avatar else R.drawable.img_ram_avatar
    val clipboardManager = LocalClipboardManager.current

    val isDark = isSystemInDarkTheme()

    // Authentic Telegram bubble colors
    val bubbleColor = if (isUser) {
        if (isDark) Color(0xFF2B5278) else Color(0xFFEFFDDE)
    } else {
        if (isDark) Color(0xFF182533) else Color(0xFFFFFFFF)
    }

    val bubbleTextColor = if (isDark) Color(0xFFEDEDED) else Color(0xFF1A1A1A)

    val timeColor = if (isUser) {
        if (isDark) Color(0xFFA8C8E8) else Color(0xFF528B4E)
    } else {
        if (isDark) Color(0xFF869AA8) else Color(0xFF8E959B)
    }

    val timeFormatted = remember(message.timestamp) {
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(message.timestamp))
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        // AI Avatar on start (Telegram Style)
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, personaAccent.copy(alpha = 0.6f), CircleShape)
                    .clickable { onOpenProfile() }
            ) {
                Image(
                    painter = painterResource(id = avatarRes),
                    contentDescription = "$personaName $personaEmoji",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
        }

        // Main Telegram Bubble Surface
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 3.dp,
                bottomEnd = if (isUser) 3.dp else 16.dp
            ),
            color = bubbleColor,
            shadowElevation = if (isDark) 0.5.dp else 1.dp,
            modifier = Modifier
                .widthIn(max = 330.dp)
                .padding(vertical = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Header in bubble: sender name for AI (Telegram style)
                if (!isUser) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$personaName $personaEmoji",
                            color = personaAccent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.clickable { onOpenProfile() }
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = { clipboardManager.setText(AnnotatedString(message.content)) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.ContentCopy, "نسخ الرسالة", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f), modifier = Modifier.size(15.dp))
                            }
                            IconButton(onClick = { onReplyToMessage(message) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.AutoMirrored.Filled.Reply, "الرد على الرسالة", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f), modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = { clipboardManager.setText(AnnotatedString(message.content)) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.ContentCopy, "نسخ الرسالة", tint = timeColor.copy(alpha = 0.75f), modifier = Modifier.size(15.dp))
                            }
                            IconButton(onClick = { onReplyToMessage(message) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.AutoMirrored.Filled.Reply, "الرد على الرسالة", tint = timeColor.copy(alpha = 0.75f), modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }

                // Telegram Quoted Reply Inside Bubble (if this message is a reply to another)
                if (!message.replyToText.isNullOrBlank()) {
                    val quotedSender = when {
                        message.replyToSender.equals("USER", ignoreCase = true) -> "أنت"
                        message.replyToSender.equals("ASSISTANT", ignoreCase = true) -> "$personaName $personaEmoji"
                        else -> message.replyToSender ?: "رسالة سابقة"
                    }
                    val quoteColor = if (isUser) personaAccent else personaAccent

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = (if (isDark) Color(0xFF1E2834) else Color(0xFFF3F7F5)).copy(alpha = 0.85f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 4.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                            // Left Accent Line (Telegram Quoted Bar)
                            Box(
                                modifier = Modifier
                                    .width(3.5.dp)
                                    .fillMaxHeight()
                                    .background(quoteColor, RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp))
                            )
                            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text(
                                    text = quotedSender,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = quoteColor
                                )
                                Text(
                                    text = message.replyToText,
                                    fontSize = 11.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = bubbleTextColor.copy(alpha = 0.75f)
                                )
                            }
                        }
                    }
                }

                // Rich Message Content (Markdown, Tables, Code, Emojis preserved!)
                FormattedMessageContent(
                    content = message.content,
                    isUser = isUser
                )

                // Telegram Timestamp & Double Checkmarks
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = timeFormatted,
                        fontSize = 10.sp,
                        color = timeColor
                    )
                    if (isUser) {
                        Icon(
                            Icons.Default.DoneAll,
                            contentDescription = "مقروءة",
                            tint = if (isDark) Color(0xFF64B5F6) else Color(0xFF4FAAFF),
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Telegram floating Date Badge centered in the message feed
 */
@Composable
fun TelegramDateBadge(
    dateText: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.Black.copy(alpha = 0.28f),
            shadowElevation = 0.dp
        ) {
            Text(
                text = dateText,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }
    }
}

/**
 * Telegram Reply Preview Banner docked above the text input
 */
@Composable
fun TelegramReplyInputBanner(
    replyToMessage: AiMessageEntity,
    activePersona: String,
    onCancelReply: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isRem = activePersona.equals("REM", ignoreCase = true)
    val personaName = if (isRem) "ريم 💙" else "رام 🌸"
    val accentColor = if (isRem) Color(0xFF1E88E5) else Color(0xFFD81B60)

    val quotedSender = if (replyToMessage.sender.equals("USER", ignoreCase = true)) {
        "أنت"
    } else {
        personaName
    }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        tonalElevation = 2.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Reply icon
            Icon(
                Icons.AutoMirrored.Filled.Reply,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))

            // Vertical stripe
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(34.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(accentColor)
            )
            Spacer(modifier = Modifier.width(8.dp))

            // Text
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "رد على $quotedSender",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
                Text(
                    text = replyToMessage.content,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Dismiss Button
            IconButton(onClick = onCancelReply, modifier = Modifier.size(28.dp)) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = "إلغاء الرد",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Telegram Agent Thinking bubble showing live status
 */
@Composable
fun TelegramAgentThinkingBubble(
    statusText: String?,
    activePersona: String,
    onOpenProfile: () -> Unit
) {
    val isRem = activePersona.equals("REM", ignoreCase = true)
    val personaName = if (isRem) "ريم" else "رام"
    val personaEmoji = if (isRem) "💙" else "🌸"
    val personaAccent = if (isRem) Color(0xFF1E88E5) else Color(0xFFD81B60)
    val avatarRes = if (isRem) R.drawable.img_rem_avatar else R.drawable.img_ram_avatar

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .border(1.5.dp, personaAccent, CircleShape)
                .clickable { onOpenProfile() }
        ) {
            Image(
                painter = painterResource(id = avatarRes),
                contentDescription = "$personaName $personaEmoji",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Spacer(modifier = Modifier.width(6.dp))

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
            shadowElevation = 1.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(14.dp),
                    strokeWidth = 2.dp,
                    color = personaAccent
                )
                Text(
                    text = statusText ?: "$personaName تفكر وتنسق بالخلفية...",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
