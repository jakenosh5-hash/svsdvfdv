package com.example.presentation.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entities.GoalEntity
import com.example.data.local.entities.TaskEntity
import com.example.domain.models.GoalHorizon
import com.example.domain.models.GoalStatus
import com.example.domain.models.TaskPriority
import com.example.domain.models.TaskStatus
import com.example.presentation.dashboard.DashboardViewModel
import java.text.SimpleDateFormat
import java.util.*

enum class CalendarViewMode(val labelArabic: String) {
    DAY("يومي (Time-Blocking)"),
    WEEK("أسبوعي"),
    MONTH("شهري")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarGoalsScreen(
    viewModel: DashboardViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableStateOf(0) }
    var calendarViewMode by remember { mutableStateOf(CalendarViewMode.DAY) }
    var selectedDateMillis by remember { mutableStateOf(System.currentTimeMillis()) }

    var showAddGoalDialog by remember { mutableStateOf(false) }
    var selectedGoalForProgress by remember { mutableStateOf<GoalEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("التقويم الداخلي والأهداف", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    if (selectedTab == 1) {
                        IconButton(onClick = { showAddGoalDialog = true }) {
                            Icon(Icons.Default.Add, contentDescription = "هدف جديد", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("التقويم وتوزيع الفترات (Time-Blocking)", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("الأهداف الاستراتيجية والمعالم", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }

            if (selectedTab == 0) {
                CalendarEngineView(
                    viewMode = calendarViewMode,
                    onViewModeChange = { calendarViewMode = it },
                    selectedDateMillis = selectedDateMillis,
                    onDateSelect = { selectedDateMillis = it },
                    allTasks = uiState.allTasks,
                    onToggleTask = { viewModel.toggleTaskComplete(it) },
                    onExportTask = { task -> viewModel.exportTaskToDeviceCalendar(task) }
                )
            } else {
                StrategicGoalsView(
                    goals = uiState.goals,
                    onCreateGoal = { showAddGoalDialog = true },
                    onUpdateProgress = { goal -> selectedGoalForProgress = goal },
                    onDeleteGoal = { viewModel.deleteGoal(it) }
                )
            }
        }
    }

    if (showAddGoalDialog) {
        AddGoalDialog(
            onDismiss = { showAddGoalDialog = false },
            onConfirm = { title, desc, horizon, target ->
                viewModel.createGoal(title, desc, horizon, target, null)
                showAddGoalDialog = false
            }
        )
    }

    selectedGoalForProgress?.let { goal ->
        UpdateGoalProgressDialog(
            goal = goal,
            onDismiss = { selectedGoalForProgress = null },
            onConfirm = { newProgress ->
                viewModel.updateGoalProgress(goal.id, newProgress)
                selectedGoalForProgress = null
            }
        )
    }
}

@Composable
private fun CalendarEngineView(
    viewMode: CalendarViewMode,
    onViewModeChange: (CalendarViewMode) -> Unit,
    selectedDateMillis: Long,
    onDateSelect: (Long) -> Unit,
    allTasks: List<TaskEntity>,
    onToggleTask: (Long) -> Unit,
    onExportTask: (TaskEntity) -> Unit
) {
    val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
    val monthYearFormat = remember { SimpleDateFormat("MMMM yyyy", Locale("ar")) }
    val dayFormat = remember { SimpleDateFormat("EEEE، d MMMM", Locale("ar")) }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Mode Selector: Day / Week / Month
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            CalendarViewMode.values().forEachIndexed { index, mode ->
                SegmentedButton(
                    selected = viewMode == mode,
                    onClick = { onViewModeChange(mode) },
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = CalendarViewMode.values().size)
                ) {
                    Text(mode.labelArabic, fontSize = 11.sp)
                }
            }
        }

        // Date Navigation Bar
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    cal.add(if (viewMode == CalendarViewMode.MONTH) Calendar.MONTH else Calendar.DAY_OF_YEAR, -1)
                    onDateSelect(cal.timeInMillis)
                }) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "السابق")
                }

                Text(
                    text = if (viewMode == CalendarViewMode.MONTH) monthYearFormat.format(Date(selectedDateMillis))
                    else dayFormat.format(Date(selectedDateMillis)),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                IconButton(onClick = {
                    cal.add(if (viewMode == CalendarViewMode.MONTH) Calendar.MONTH else Calendar.DAY_OF_YEAR, 1)
                    onDateSelect(cal.timeInMillis)
                }) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "التالي")
                }
            }
        }

        when (viewMode) {
            CalendarViewMode.DAY -> {
                // Day Time-Blocking Schedule (Hours 08:00 to 22:00)
                DayTimeBlockingView(
                    selectedDateMillis = selectedDateMillis,
                    tasks = allTasks,
                    onToggleTask = onToggleTask,
                    onExportTask = onExportTask
                )
            }
            CalendarViewMode.WEEK -> {
                WeekGridView(
                    selectedDateMillis = selectedDateMillis,
                    tasks = allTasks,
                    onDateSelect = onDateSelect
                )
            }
            CalendarViewMode.MONTH -> {
                MonthCalendarGridView(
                    selectedDateMillis = selectedDateMillis,
                    tasks = allTasks,
                    onDateSelect = {
                        onDateSelect(it)
                        onViewModeChange(CalendarViewMode.DAY)
                    }
                )
            }
        }
    }
}

@Composable
private fun DayTimeBlockingView(
    selectedDateMillis: Long,
    tasks: List<TaskEntity>,
    onToggleTask: (Long) -> Unit,
    onExportTask: (TaskEntity) -> Unit
) {
    val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
    val dayYear = cal.get(Calendar.YEAR)
    val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)

    // Filter tasks for this day
    val dayTasks = remember(tasks, selectedDateMillis) {
        tasks.filter { task ->
            val tCal = Calendar.getInstance()
            val due = task.dueDate
            if (due != null) {
                tCal.timeInMillis = due
                tCal.get(Calendar.YEAR) == dayYear && tCal.get(Calendar.DAY_OF_YEAR) == dayOfYear
            } else {
                task.status != TaskStatus.COMPLETED
            }
        }
    }

    val hours = (8..21).toList()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("مهام هذا اليوم: ${dayTasks.size}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Text("المنجز: ${dayTasks.count { it.status == TaskStatus.COMPLETED }}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        items(hours) { hour ->
            val hourFormatted = String.format(Locale.getDefault(), "%02d:00", hour)
            val tasksInThisHour = dayTasks.filter {
                val mins = it.dueTimeMinutes ?: (hour * 60)
                mins / 60 == hour
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = hourFormatted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.width(44.dp)
                    )

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (tasksInThisHour.isEmpty()) {
                            Text("— فترة شاغرة للتركيز العميق —", fontSize = 11.sp, color = MaterialTheme.colorScheme.outlineVariant)
                        } else {
                            if (tasksInThisHour.size > 1) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = MaterialTheme.colorScheme.errorContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(12.dp))
                                        Text(
                                            "⚠️ تعارض زمني: ${tasksInThisHour.size} مهام في نفس الساعة!",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            tasksInThisHour.forEach { task ->
                                val isDone = task.status == TaskStatus.COMPLETED
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isDone) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            IconButton(onClick = { onToggleTask(task.id) }, modifier = Modifier.size(20.dp)) {
                                                Icon(
                                                    if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                                    contentDescription = null,
                                                    tint = if (isDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                            Column {
                                                Text(
                                                    task.title,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = if (isDone) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                                task.durationMinutes?.let {
                                                    Text("⏱️ $it دقيقة", fontSize = 9.sp, color = MaterialTheme.colorScheme.outline)
                                                }
                                            }
                                        }

                                        IconButton(onClick = { onExportTask(task) }, modifier = Modifier.size(20.dp)) {
                                            Icon(Icons.Default.CalendarToday, contentDescription = "تصدير للتقويم", modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeekGridView(
    selectedDateMillis: Long,
    tasks: List<TaskEntity>,
    onDateSelect: (Long) -> Unit
) {
    val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
    cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)

    val weekDays = remember(selectedDateMillis) {
        (0..6).map {
            val dCal = cal.clone() as Calendar
            dCal.add(Calendar.DAY_OF_WEEK, it)
            dCal
        }
    }

    val dayNameFormat = remember { SimpleDateFormat("EEE", Locale("ar")) }
    val dayNumFormat = remember { SimpleDateFormat("d", Locale.getDefault()) }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            weekDays.forEach { dayCal ->
                val isSelected = dayCal.get(Calendar.DAY_OF_YEAR) == Calendar.getInstance().apply { timeInMillis = selectedDateMillis }.get(Calendar.DAY_OF_YEAR)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .clickable { onDateSelect(dayCal.timeInMillis) }
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(dayNameFormat.format(dayCal.time), fontSize = 11.sp, color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(dayNumFormat.format(dayCal.time), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        // Tasks in selected day of week
        DayTimeBlockingView(
            selectedDateMillis = selectedDateMillis,
            tasks = tasks,
            onToggleTask = {},
            onExportTask = {}
        )
    }
}

@Composable
private fun MonthCalendarGridView(
    selectedDateMillis: Long,
    tasks: List<TaskEntity>,
    onDateSelect: (Long) -> Unit
) {
    val cal = Calendar.getInstance().apply {
        timeInMillis = selectedDateMillis
        set(Calendar.DAY_OF_MONTH, 1)
    }
    val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val days = (1..maxDay).toList()

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(days) { day ->
                val dayCal = cal.clone() as Calendar
                dayCal.set(Calendar.DAY_OF_MONTH, day)
                val dayTasks = tasks.filter {
                    val tCal = Calendar.getInstance()
                    if (it.dueDate != null) {
                        tCal.timeInMillis = it.dueDate
                        tCal.get(Calendar.YEAR) == dayCal.get(Calendar.YEAR) && tCal.get(Calendar.DAY_OF_YEAR) == dayCal.get(Calendar.DAY_OF_YEAR)
                    } else false
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (dayTasks.isNotEmpty()) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clickable { onDateSelect(dayCal.timeInMillis) }
                ) {
                    Column(
                        modifier = Modifier.padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = day.toString(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (dayTasks.isNotEmpty()) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                        if (dayTasks.isNotEmpty()) {
                            Text("• ${dayTasks.size}", fontSize = 9.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StrategicGoalsView(
    goals: List<GoalEntity>,
    onCreateGoal: () -> Unit,
    onUpdateProgress: (GoalEntity) -> Unit,
    onDeleteGoal: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("الأهداف الاستراتيجية ومؤشرات الإنجاز (OKRs)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Button(onClick = onCreateGoal) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("هدف جديد")
            }
        }

        if (goals.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Flag, contentDescription = null, modifier = Modifier.size(54.dp), tint = MaterialTheme.colorScheme.outline)
                    Text("لا توجد أهداف استراتيجية مسجلة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onCreateGoal) {
                        Text("إضافة الهدف الأول")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(goals, key = { it.id }) { goal ->
                    val progress = if (goal.targetValue > 0) (goal.currentValue / goal.targetValue).toFloat().coerceIn(0f, 1f) else 0f
                    val isAchieved = goal.status == GoalStatus.ACHIEVED || progress >= 1f

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isAchieved) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(
                                        imageVector = if (isAchieved) Icons.Default.CheckCircle else Icons.Default.Flag,
                                        contentDescription = null,
                                        tint = if (isAchieved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
                                    )
                                    Text(goal.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = goal.horizon.labelArabic,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }

                            if (!goal.description.isNullOrBlank()) {
                                Text(goal.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)),
                                color = if (isAchieved) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "التقدم: ${goal.currentValue.toInt()} / ${goal.targetValue.toInt()} (${(progress * 100).toInt()}%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TextButton(onClick = { onUpdateProgress(goal) }) {
                                        Text("تحديث التقدم", fontSize = 11.sp)
                                    }
                                    IconButton(onClick = { onDeleteGoal(goal.id) }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddGoalDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, desc: String?, horizon: GoalHorizon, target: Double) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var horizon by remember { mutableStateOf(GoalHorizon.MEDIUM_TERM) }
    var targetText by remember { mutableStateOf("100") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("إضافة هدف استراتيجي جديد", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الهدف") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Text("مدى الهدف:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GoalHorizon.values().forEach { h ->
                        FilterChip(
                            selected = horizon == h,
                            onClick = { horizon = h },
                            label = { Text(h.labelArabic, fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it.filter { c -> c.isDigit() } },
                    label = { Text("القيمة المستهدفة (مثلاً 100%)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("الوصف ومؤشرات النجاح") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("إلغاء") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val target = targetText.toDoubleOrNull() ?: 100.0
                            if (title.isNotBlank()) {
                                onConfirm(title.trim(), desc.ifBlank { null }, horizon, target)
                            }
                        },
                        enabled = title.isNotBlank()
                    ) {
                        Text("حفظ الهدف")
                    }
                }
            }
        }
    }
}

@Composable
fun UpdateGoalProgressDialog(
    goal: GoalEntity,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var progressText by remember { mutableStateOf(goal.currentValue.toInt().toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تحديث التقدم في الهدف", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(goal.title, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)

                OutlinedTextField(
                    value = progressText,
                    onValueChange = { progressText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("القيمة الحالية المحققة (من ${goal.targetValue.toInt()})") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("إلغاء") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val value = progressText.toDoubleOrNull() ?: goal.currentValue
                            onConfirm(value)
                        }
                    ) {
                        Text("تحديث")
                    }
                }
            }
        }
    }
}
