package com.example.presentation.dashboard

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.DebtEntity
import com.example.data.local.entities.TaskEntity
import com.example.domain.models.*
import com.example.presentation.components.AddTaskDialog
import com.example.presentation.components.AddDebtDialog
import com.example.presentation.components.AddTransactionDialog
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToProductivity: () -> Unit,
    onNavigateToFinance: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Dialog States
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showAddTxDialog by remember { mutableStateOf(false) }
    var showAddDebtDialog by remember { mutableStateOf(false) }
    var showSpeedDial by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.userMessage) {
        uiState.userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "المشغول دائمًا",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        val dateFormat = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar"))
                        Text(
                            text = dateFormat.format(Date()),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "الأمان والإعدادات",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AnimatedVisibility(
                    visible = showSpeedDial,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SmallFloatingActionButton(
                            onClick = {
                                showSpeedDial = false
                                showAddDebtDialog = true
                            },
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                            contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.ReceiptLong, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("دين جديد", fontSize = 12.sp)
                            }
                        }

                        SmallFloatingActionButton(
                            onClick = {
                                showSpeedDial = false
                                showAddTxDialog = true
                            },
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("حركة مالية", fontSize = 12.sp)
                            }
                        }

                        SmallFloatingActionButton(
                            onClick = {
                                showSpeedDial = false
                                showAddTaskDialog = true
                            },
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AddTask, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("مهمة جديدة", fontSize = 12.sp)
                            }
                        }
                    }
                }

                FloatingActionButton(
                    onClick = { showSpeedDial = !showSpeedDial },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = CircleShape
                ) {
                    Icon(
                        imageVector = if (showSpeedDial) Icons.Default.Close else Icons.Default.Add,
                        contentDescription = "إضافة سريعة"
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp)
        ) {
            // 1. Psychological Calm & Control Index Card
            item {
                CalmIndexCard(
                    calmScore = uiState.calmScore,
                    todayTasksCount = uiState.todayTasks.size,
                    completedTasksCount = uiState.todayTasks.count { it.status == TaskStatus.COMPLETED }
                )
            }

            // 2. Dual-Currency Financial Snapshot
            item {
                FinancialDualCurrencyCard(
                    balance = uiState.currencyBalance,
                    exchangeRate = uiState.exchangeRate,
                    onManageClick = onNavigateToFinance
                )
            }

            // 3. Nearest Debt Alert (if any active debt is approaching)
            uiState.nearestDebt?.let { debt ->
                item {
                    NearestDebtAlertCard(debt = debt, onManageClick = onNavigateToFinance)
                }
            }

            // 4. Section: Today's Urgent Focus
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تركيز اليوم (اليومي)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onNavigateToProductivity) {
                        Text("عرض كل المهام (${uiState.todayTasks.size})")
                    }
                }
            }

            if (uiState.todayTasks.isEmpty()) {
                item {
                    EmptyTodayTasksCard(onAddTaskClick = { showAddTaskDialog = true })
                }
            } else {
                items(uiState.todayTasks.take(5), key = { it.id }) { task ->
                    TodayTaskItemCard(
                        task = task,
                        onToggle = { viewModel.toggleTaskComplete(task.id) }
                    )
                }
            }
        }
    }

    // Quick Add Dialogs
    if (showAddTaskDialog) {
        AddTaskDialog(
            projects = uiState.projects,
            onDismiss = { showAddTaskDialog = false },
            onConfirm = { title, priority, duration, projId, horizon, isRecurring, recurrenceRule ->
                viewModel.quickCreateTask(
                    title = title,
                    priority = priority,
                    timeHorizon = horizon,
                    durationMinutes = duration,
                    projectId = projId,
                    isRecurring = isRecurring,
                    recurrenceRule = recurrenceRule
                )
            }
        )
    }

    if (showAddTxDialog) {
        AddTransactionDialog(
            categories = uiState.categories,
            onDismiss = { showAddTxDialog = false },
            onConfirm = { type, amount, currency, categoryId, note ->
                viewModel.recordQuickTransaction(type, amount, currency, categoryId, note)
            }
        )
    }

    if (showAddDebtDialog) {
        AddDebtDialog(
            onDismiss = { showAddDebtDialog = false },
            onConfirm = { type, person, amount, currency, phone, note ->
                viewModel.quickCreateDebt(type, person, amount, currency, null, phone, note)
            }
        )
    }
}

@Composable
fun CalmIndexCard(
    calmScore: Int,
    todayTasksCount: Int,
    completedTasksCount: Int
) {
    val gradient = Brush.horizontalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primaryContainer,
            MaterialTheme.colorScheme.surfaceVariant
        )
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(gradient)
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "مؤشر الهدوء والسيطرة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = when {
                                calmScore >= 80 -> "أنت في قمة السيطرة والوضوح الذهني اليوم ✨"
                                calmScore >= 50 -> "تقدم جيد، استمر بإنهاء الأولويات الحرجة 🎯"
                                else -> "تجنب تشتت المهام وركز على الأهم أولاً 🌿"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Score Badge
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(
                                color = MaterialTheme.colorScheme.primary,
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$calmScore%",
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                    }
                }

                // Progress Bar
                LinearProgressIndicator(
                    progress = { calmScore / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "المهام المنجزة: $completedTasksCount من $todayTasksCount",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "نظام حياة خالي من الوهم",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun FinancialDualCurrencyCard(
    balance: com.example.services.CurrencyBalance,
    exchangeRate: Double,
    onManageClick: () -> Unit
) {
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "المركز المالي المزدوج",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                TextButton(onClick = onManageClick) {
                    Text("إدارة")
                }
            }

            // Dual Currency Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // SYP Box
                Surface(
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "الليرة السورية (SYP)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "${numberFormat.format(balance.sypNet)} ل.س",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (balance.sypNet >= 0) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "دخل: +${numberFormat.format(balance.sypIncome)}",
                                fontSize = 10.sp,
                                color = Color(0xFF2E7D32)
                            )
                            Text(
                                text = "صرف: -${numberFormat.format(balance.sypExpense)}",
                                fontSize = 10.sp,
                                color = Color(0xFFD32F2F)
                            )
                        }
                    }
                }

                // USD Box
                Surface(
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "الدولار الأمريكي (USD)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1565C0)
                        )
                        Text(
                            text = "$${numberFormat.format(balance.usdNet)}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (balance.usdNet >= 0) Color(0xFF1565C0) else Color(0xFFD32F2F)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "دخل: +$${numberFormat.format(balance.usdIncome)}",
                                fontSize = 10.sp,
                                color = Color(0xFF1565C0)
                            )
                            Text(
                                text = "صرف: -$${numberFormat.format(balance.usdExpense)}",
                                fontSize = 10.sp,
                                color = Color(0xFFD32F2F)
                            )
                        }
                    }
                }
            }

            // Exchange rate pill
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "سعر الصرف المحلي المدخل: 1$ = ${numberFormat.format(exchangeRate)} ل.س",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Icon(
                        imageVector = Icons.Default.CurrencyExchange,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun NearestDebtAlertCard(
    debt: DebtEntity,
    onManageClick: () -> Unit
) {
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)
    val isIOwe = debt.type == DebtType.I_OWE

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isIOwe) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)
        )
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = if (isIOwe) Icons.Default.Warning else Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = if (isIOwe) Color(0xFFC62828) else Color(0xFF2E7D32)
                )
                Column {
                    Text(
                        text = if (isIOwe) "التزام سداد قادم: ${debt.personName}" else "مستحق تحصيل: ${debt.personName}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isIOwe) Color(0xFFB71C1C) else Color(0xFF1B5E20)
                    )
                    Text(
                        text = "المتبقي: ${numberFormat.format(debt.remainingAmount)} ${debt.currency.symbol}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            TextButton(onClick = onManageClick) {
                Text(
                    text = "سداد / كشف",
                    color = if (isIOwe) Color(0xFFC62828) else Color(0xFF2E7D32),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun TodayTaskItemCard(
    task: TaskEntity,
    onToggle: () -> Unit
) {
    val isCompleted = task.status == TaskStatus.COMPLETED

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onToggle() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isCompleted) 0.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconButton(
                onClick = onToggle,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = if (isCompleted) "مكتمل" else "غير مكتمل",
                    tint = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (isCompleted) FontWeight.Normal else FontWeight.SemiBold,
                    textDecoration = if (isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Priority tag
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = when (task.priority) {
                            TaskPriority.URGENT_IMPORTANT -> Color(0xFFFFEBEE)
                            TaskPriority.IMPORTANT_NOT_URGENT -> Color(0xFFE8F5E9)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                    ) {
                        Text(
                            text = task.priority.labelArabic,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            color = when (task.priority) {
                                TaskPriority.URGENT_IMPORTANT -> Color(0xFFC62828)
                                TaskPriority.IMPORTANT_NOT_URGENT -> Color(0xFF2E7D32)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            fontWeight = FontWeight.Medium
                        )
                    }

                    task.durationMinutes?.let {
                        Text(
                            text = "⏱️ $it دقيقة",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyTodayTasksCard(onAddTaskClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.DoneAll,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp)
            )
            Text(
                text = "لا توجد مهام ملحة معلقة اليوم",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "ذهنك صافٍ! يمكنك إضافة مهام اليوم للتركيز على ما يهم دون إرهاق.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedButton(onClick = onAddTaskClick) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إضافة مهمة لليوم")
            }
        }
    }
}
