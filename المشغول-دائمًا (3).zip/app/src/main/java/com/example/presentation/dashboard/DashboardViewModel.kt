package com.example.presentation.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.AppContainer
import com.example.data.local.entities.*
import com.example.domain.models.*
import com.example.services.CurrencyBalance
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

data class DashboardUiState(
    val todayTasks: List<TaskEntity> = emptyList(),
    val allTasks: List<TaskEntity> = emptyList(),
    val calmScore: Int = 100,
    val currencyBalance: CurrencyBalance = CurrencyBalance(),
    val exchangeRate: Double = 14500.0,
    val nearestDebt: DebtEntity? = null,
    val allDebts: List<DebtEntity> = emptyList(),
    val financeTransactions: List<FinanceTransactionEntity> = emptyList(),
    val assets: List<AssetEntity> = emptyList(),
    val budgets: List<BudgetEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val projects: List<ProjectEntity> = emptyList(),
    val templates: List<TaskTemplateEntity> = emptyList(),
    val notes: List<NoteEntity> = emptyList(),
    val goals: List<GoalEntity> = emptyList(),
    val timeEntries: List<TimeEntryEntity> = emptyList(),
    val runningTimeEntry: TimeEntryEntity? = null,
    val isCalendarSyncEnabled: Boolean = false,
    val isSessionLocked: Boolean = false,
    val isBiometricEnabled: Boolean = false,
    val isAiConfigInstalled: Boolean = false,
    val aiProvider: String = "",
    val aiBaseUrl: String = "",
    val aiModel: String = "",
    val aiKeySlots: List<String> = emptyList(),
    val aiKeysCount: Int = 0,
    val isTestingAiConnection: Boolean = false,
    val aiTestConnectionResult: String? = null,
    val userMessage: String? = null
)

private data class Tuple4<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)

private data class FinancialFlowState(
    val balance: CurrencyBalance,
    val rate: Double,
    val debts: List<DebtEntity>,
    val categories: List<CategoryEntity>,
    val transactions: List<FinanceTransactionEntity>,
    val assets: List<AssetEntity>,
    val budgets: List<BudgetEntity>
)

private data class ProductivityFlowState(
    val todayTasks: List<TaskEntity>,
    val allTasks: List<TaskEntity>,
    val projects: List<ProjectEntity>,
    val templates: List<TaskTemplateEntity>,
    val notes: List<NoteEntity>,
    val goals: List<GoalEntity>,
    val timeEntries: List<TimeEntryEntity>
)

class DashboardViewModel(
    private val appContainer: AppContainer
) : ViewModel() {

    private val _userMessage = MutableStateFlow<String?>(null)
    private val _runningTimeEntry = MutableStateFlow<TimeEntryEntity?>(null)

    init {
        // Disable biometric lock by default and unlock session immediately
        appContainer.securityPreferences.setBiometricEnabled(false)
        appContainer.securityPreferences.unlockSession()
        checkRunningTimer()
    }

    private fun checkRunningTimer() {
        viewModelScope.launch {
            _runningTimeEntry.value = appContainer.timeTrackingService.getRunningEntry()
        }
    }

    private val currentYearMonth = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US).format(java.util.Date())

    private val financeCoreFlow = combine(
        appContainer.financeService.getBalanceSummary(),
        appContainer.financeService.getLatestExchangeRate(),
        appContainer.debtService.getAllDebts(),
        appContainer.financeService.getCategories()
    ) { balance, rate, debts, categories ->
        Tuple4(balance, rate, debts, categories)
    }

    private val financeDetailsFlow = combine(
        appContainer.financeService.getAllTransactions(),
        appContainer.financeService.getAllAssets(),
        appContainer.financeService.getBudgetsForMonth(currentYearMonth)
    ) { txs, assets, budgets ->
        Triple(txs, assets, budgets)
    }

    private val financialFlow: Flow<FinancialFlowState> = combine(
        financeCoreFlow,
        financeDetailsFlow
    ) { core, details ->
        FinancialFlowState(
            balance = core.first,
            rate = core.second?.rate ?: 14500.0,
            debts = core.third,
            categories = core.fourth,
            transactions = details.first,
            assets = details.second,
            budgets = details.third
        )
    }

    private val tasksAndProjectsFlow = combine(
        appContainer.taskService.getTodayTasks(),
        appContainer.taskService.getAllTasks(),
        appContainer.taskService.getProjects(),
        appContainer.taskService.getAllTemplates()
    ) { today, all, projects, templates ->
        Tuple4(today, all, projects, templates)
    }

    private val notesGoalsTimeFlow = combine(
        appContainer.noteService.getActiveNotes(),
        appContainer.goalService.getAllGoals(),
        appContainer.timeTrackingService.getAllEntries()
    ) { notes, goals, timeEntries ->
        Triple(notes, goals, timeEntries)
    }

    private val productivityFlow: Flow<ProductivityFlowState> = combine(
        tasksAndProjectsFlow,
        notesGoalsTimeFlow
    ) { tp, ngt ->
        ProductivityFlowState(
            todayTasks = tp.first,
            allTasks = tp.second,
            projects = tp.third,
            templates = tp.fourth,
            notes = ngt.first,
            goals = ngt.second,
            timeEntries = ngt.third
        )
    }

    private val _isTestingAiConnection = MutableStateFlow(false)
    private val _aiTestConnectionResult = MutableStateFlow<String?>(null)
    private val _aiConfigVersion = MutableStateFlow(0)

    private data class AiSettingsExtraState(
        val isTestingAi: Boolean = false,
        val aiTestResult: String? = null,
        val message: String? = null
    )

    private val _aiSettingsExtraFlow = combine(
        _isTestingAiConnection,
        _aiTestConnectionResult,
        _userMessage,
        _aiConfigVersion
    ) { testing, testRes, msg, _ ->
        AiSettingsExtraState(
            isTestingAi = testing,
            aiTestResult = testRes,
            message = msg
        )
    }

    val uiState: StateFlow<DashboardUiState> = combine(
        productivityFlow,
        financialFlow,
        appContainer.securityPreferences.isLocked,
        _runningTimeEntry,
        _aiSettingsExtraFlow
    ) { prod, finance, locked, runningTimer, extra ->
        val score = appContainer.taskService.calculateCalmScore(prod.todayTasks)
        val activeDebts = finance.debts.filter { it.status == DebtStatus.ACTIVE && it.dueDate != null }
            .sortedBy { it.dueDate }
        val nearest = activeDebts.firstOrNull()

        val aiPrefs = appContainer.aiPreferences

        DashboardUiState(
            todayTasks = prod.todayTasks,
            allTasks = prod.allTasks,
            calmScore = score,
            currencyBalance = finance.balance,
            exchangeRate = finance.rate,
            nearestDebt = nearest,
            allDebts = finance.debts,
            financeTransactions = finance.transactions,
            assets = finance.assets,
            budgets = finance.budgets,
            categories = finance.categories,
            projects = prod.projects,
            templates = prod.templates,
            notes = prod.notes,
            goals = prod.goals,
            timeEntries = prod.timeEntries,
            runningTimeEntry = runningTimer,
            isCalendarSyncEnabled = appContainer.deviceCalendarService.hasCalendarPermission(),
            isSessionLocked = locked,
            isBiometricEnabled = appContainer.securityPreferences.isBiometricEnabled(),
            isAiConfigInstalled = aiPrefs.isConfigInstalled || aiPrefs.isConfigured,
            aiProvider = aiPrefs.provider,
            aiBaseUrl = aiPrefs.baseUrl,
            aiModel = aiPrefs.model,
            aiKeySlots = aiPrefs.getKeySlots(),
            aiKeysCount = aiPrefs.keysCount,
            isTestingAiConnection = extra.isTestingAi,
            aiTestConnectionResult = extra.aiTestResult,
            userMessage = extra.message
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState()
    )

    fun toggleTaskComplete(taskId: Long) {
        viewModelScope.launch {
            appContainer.taskService.toggleTaskComplete(taskId)
        }
    }

    fun deleteTask(taskId: Long) {
        viewModelScope.launch {
            appContainer.taskService.deleteTask(taskId)
            _userMessage.value = "تم حذف المهمة"
        }
    }

    fun createTaskFromTemplate(
        title: String,
        templateId: Long,
        customValues: Map<Long, String>
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            appContainer.taskService.createTask(
                title = title.trim(),
                priority = TaskPriority.IMPORTANT_NOT_URGENT,
                timeHorizon = TimeHorizon.DAILY,
                dueDate = System.currentTimeMillis(),
                templateId = templateId,
                customValues = customValues
            )
            _userMessage.value = "تم إنشاء المهمة بنجاح من القالب"
        }
    }

    suspend fun getFieldsForTemplate(templateId: Long): List<TemplateFieldEntity> =
        appContainer.taskService.getFieldsForTemplateList(templateId)

    suspend fun getCustomValuesForTask(taskId: Long): List<TaskCustomValueEntity> =
        appContainer.taskService.getCustomValuesForTaskList(taskId)

    suspend fun getTemplateById(templateId: Long): TaskTemplateEntity? =
        appContainer.taskService.getTemplateById(templateId)

    fun quickCreateTask(
        title: String,
        priority: TaskPriority = TaskPriority.IMPORTANT_NOT_URGENT,
        timeHorizon: TimeHorizon = TimeHorizon.DAILY,
        durationMinutes: Int? = 30,
        projectId: Long? = null,
        parentTaskId: Long? = null,
        dueDate: Long? = System.currentTimeMillis(),
        dueTimeMinutes: Int? = null,
        isRecurring: Boolean = false,
        recurrenceRule: String? = null
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            appContainer.taskService.createTask(
                title = title.trim(),
                priority = priority,
                timeHorizon = timeHorizon,
                durationMinutes = durationMinutes,
                projectId = projectId,
                parentTaskId = parentTaskId,
                dueDate = dueDate,
                dueTimeMinutes = dueTimeMinutes,
                isRecurring = isRecurring,
                recurrenceRule = recurrenceRule
            )
            _userMessage.value = "تمت إضافة المهمة بنجاح"
        }
    }

    fun startTimerForTask(taskId: Long, notes: String? = null) {
        viewModelScope.launch {
            appContainer.timeTrackingService.startTimer(taskId, notes)
            _runningTimeEntry.value = appContainer.timeTrackingService.getRunningEntry()
            _userMessage.value = "تم بدء تشغيل المؤقت الزمني للمهمة"
        }
    }

    fun stopRunningTimer() {
        viewModelScope.launch {
            val stopped = appContainer.timeTrackingService.stopTimer()
            _runningTimeEntry.value = null
            if (stopped != null) {
                val mins = (stopped.durationSeconds ?: 0L) / 60
                _userMessage.value = "تم إيقاف المؤقت وحفظ الجلسة ($mins دقيقة)"
            }
        }
    }

    fun logManualTime(taskId: Long, durationMinutes: Int, notes: String? = null) {
        if (durationMinutes <= 0) return
        viewModelScope.launch {
            appContainer.timeTrackingService.logManualTime(taskId, durationMinutes, notes)
            _userMessage.value = "تم تسجيل $durationMinutes دقيقة في سجل العمل"
        }
    }

    fun exportTaskToDeviceCalendar(task: TaskEntity) {
        val eventId = appContainer.deviceCalendarService.exportTaskToCalendar(task)
        if (eventId != null) {
            _userMessage.value = "تم تصدير المهمة بنجاح إلى تقويم الهاتف"
        } else {
            _userMessage.value = "تنبيه: يتطلب إذن الوصول لتقويم الهاتف لتصدير المهام"
        }
    }

    fun createGoal(
        title: String,
        description: String?,
        horizon: GoalHorizon,
        targetValue: Double,
        targetDate: Long?
    ) {
        if (title.isBlank() || targetValue <= 0.0) return
        viewModelScope.launch {
            appContainer.goalService.createGoal(
                title = title.trim(),
                description = description,
                horizon = horizon,
                targetValue = targetValue,
                targetDate = targetDate
            )
            _userMessage.value = "تم إنشاء الهدف بنجاح"
        }
    }

    fun updateGoalProgress(goalId: Long, currentValue: Double) {
        viewModelScope.launch {
            appContainer.goalService.updateGoalProgress(goalId, currentValue)
            _userMessage.value = "تم تحديث التقدم في الهدف"
        }
    }

    fun deleteGoal(goalId: Long) {
        viewModelScope.launch {
            appContainer.goalService.deleteGoal(goalId)
            _userMessage.value = "تم حذف الهدف"
        }
    }

    fun createProject(name: String, description: String?, colorHex: String, iconName: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            appContainer.taskService.createProject(name.trim(), description, colorHex, iconName)
            _userMessage.value = "تم إنشاء المشروع بنجاح"
        }
    }

    fun archiveProject(projectId: Long) {
        viewModelScope.launch {
            appContainer.taskService.archiveProject(projectId)
            _userMessage.value = "تم أرشفة المشروع بنجاح"
        }
    }

    fun updateTaskStatus(taskId: Long, newStatus: TaskStatus) {
        viewModelScope.launch {
            appContainer.taskService.updateTaskStatus(taskId, newStatus)
            _userMessage.value = "تم تحديث حالة المهمة إلى: ${newStatus.labelArabic}"
        }
    }

    fun createTask(
        title: String,
        description: String? = null,
        priority: TaskPriority = TaskPriority.IMPORTANT_NOT_URGENT,
        timeHorizon: TimeHorizon = TimeHorizon.DAILY,
        dueDate: Long? = System.currentTimeMillis(),
        dueTimeMinutes: Int? = null,
        durationMinutes: Int? = 30,
        tags: String? = null,
        projectId: Long? = null,
        parentTaskId: Long? = null,
        isRecurring: Boolean = false,
        recurrenceRule: String? = null,
        imageUri: String? = null,
        reminderTime: Long? = null,
        isReminderEnabled: Boolean = false
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            appContainer.taskService.createTask(
                title = title.trim(),
                description = description,
                priority = priority,
                timeHorizon = timeHorizon,
                durationMinutes = durationMinutes,
                projectId = projectId,
                parentTaskId = parentTaskId,
                dueDate = dueDate,
                dueTimeMinutes = dueTimeMinutes,
                tags = tags,
                isRecurring = isRecurring,
                recurrenceRule = recurrenceRule,
                imageUri = imageUri,
                reminderTime = reminderTime,
                isReminderEnabled = isReminderEnabled
            )
            _userMessage.value = "تمت إضافة المهمة بنجاح"
        }
    }

    fun updateTaskPriority(taskId: Long, newPriority: TaskPriority) {
        viewModelScope.launch {
            val task = appContainer.database.taskDao().getTaskById(taskId) ?: return@launch
            val updated = task.copy(priority = newPriority, updatedAt = System.currentTimeMillis())
            appContainer.database.taskDao().updateTask(updated)
            _userMessage.value = "تم تحديث أولوية المهمة إلى: ${newPriority.labelArabic}"
        }
    }

    fun postponeTaskToTomorrow(task: TaskEntity) {
        viewModelScope.launch {
            val cal = Calendar.getInstance()
            cal.timeInMillis = task.dueDate ?: System.currentTimeMillis()
            cal.add(Calendar.DAY_OF_YEAR, 1)
            val updated = task.copy(
                dueDate = cal.timeInMillis,
                status = TaskStatus.POSTPONED,
                updatedAt = System.currentTimeMillis()
            )
            appContainer.database.taskDao().updateTask(updated)
            _userMessage.value = "تم تأجيل المهمة إلى الغد"
        }
    }

    fun moveTaskToEvening(task: TaskEntity) {
        viewModelScope.launch {
            val updated = task.copy(
                dueTimeMinutes = 19 * 60, // 7:00 PM
                updatedAt = System.currentTimeMillis()
            )
            appContainer.database.taskDao().updateTask(updated)
            _userMessage.value = "تم نقل موعد المهمة إلى الفترة المسائية (7:00 م)"
        }
    }

    fun addSubtask(parentTaskId: Long, title: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            appContainer.taskService.createTask(
                title = title.trim(),
                parentTaskId = parentTaskId,
                timeHorizon = TimeHorizon.DAILY,
                priority = TaskPriority.IMPORTANT_NOT_URGENT
            )
            _userMessage.value = "تمت إضافة المهمة الفرعية"
        }
    }

    fun scheduleTaskReminder(taskId: Long, title: String, triggerAtMillis: Long) {
        appContainer.reminderScheduler.scheduleExactReminder(taskId, title, triggerAtMillis)
        _userMessage.value = "تم جدولة التنبيه الدقيق للمهمة"
    }

    fun cancelTaskReminder(taskId: Long) {
        appContainer.reminderScheduler.cancelReminder(taskId)
        _userMessage.value = "تم إلغاء التنبيه"
    }

    fun saveNote(
        title: String,
        contentMarkdown: String,
        tags: String? = null,
        projectId: Long? = null,
        taskId: Long? = null,
        debtId: Long? = null
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            appContainer.noteService.saveNote(
                title = title.trim(),
                contentMarkdown = contentMarkdown,
                tags = tags,
                projectId = projectId,
                taskId = taskId,
                debtId = debtId
            )
            _userMessage.value = "تم حفظ الملاحظة المعرفية بنجاح"
        }
    }

    fun togglePinNote(noteId: Long) {
        viewModelScope.launch {
            appContainer.noteService.togglePinNote(noteId)
        }
    }

    fun archiveNote(noteId: Long) {
        viewModelScope.launch {
            appContainer.noteService.archiveNote(noteId)
            _userMessage.value = "تم نقل الملاحظة إلى الأرشيف"
        }
    }

    fun deleteNote(noteId: Long) {
        viewModelScope.launch {
            appContainer.noteService.deleteNote(noteId)
            _userMessage.value = "تم حذف الملاحظة نهائياً"
        }
    }

    fun recordQuickTransaction(
        type: TransactionType,
        amount: Double,
        currency: CurrencyType,
        categoryId: Long,
        note: String? = null
    ) {
        if (amount <= 0.0) return
        viewModelScope.launch {
            appContainer.financeService.recordTransaction(
                type = type,
                amount = amount,
                currency = currency,
                categoryId = categoryId,
                note = note
            )
            _userMessage.value = "تم تسجيل الحركة المالية بنجاح"
        }
    }

    fun quickCreateDebt(
        type: DebtType,
        personName: String,
        amount: Double,
        currency: CurrencyType,
        dueDate: Long? = null,
        phoneNumber: String? = null,
        note: String? = null
    ) {
        if (personName.isBlank() || amount <= 0.0) return
        viewModelScope.launch {
            appContainer.debtService.createDebt(
                type = type,
                personName = personName.trim(),
                amount = amount,
                currency = currency,
                dueDate = dueDate,
                phoneNumber = phoneNumber,
                note = note
            )
            _userMessage.value = "تم تدوين الدين في السجل"
        }
    }

    fun saveQuickNote(title: String, content: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            appContainer.noteService.saveNote(
                title = title.trim(),
                contentMarkdown = content
            )
            _userMessage.value = "تم حفظ الملاحظة بنجاح"
        }
    }

    fun updateManualExchangeRate(newRate: Double) {
        if (newRate <= 0.0) return
        viewModelScope.launch {
            appContainer.financeService.updateExchangeRate(newRate)
            _userMessage.value = "تم تحديث سعر الصرف المحلي: $newRate ل.س"
        }
    }

    fun recordPartialDebtPayment(debtId: Long, amount: Double, receiptNote: String? = null) {
        if (amount <= 0.0) return
        viewModelScope.launch {
            appContainer.debtService.recordPartialPayment(debtId, amount, receiptNote)
            _userMessage.value = "تم تسجيل سداد الدفعة بنجاح وتحديث المتبقي"
        }
    }

    fun deleteDebt(debtId: Long) {
        viewModelScope.launch {
            appContainer.debtService.deleteDebt(debtId)
            _userMessage.value = "تم حذف الدين من السجل"
        }
    }

    fun saveAsset(
        name: String,
        category: String,
        currentValue: Double,
        currency: CurrencyType,
        purchaseCost: Double? = null,
        note: String? = null,
        assetId: Long = 0
    ) {
        if (name.isBlank() || currentValue < 0.0) return
        viewModelScope.launch {
            appContainer.financeService.saveAsset(
                name = name.trim(),
                category = category,
                currentValue = currentValue,
                currency = currency,
                purchaseCost = purchaseCost,
                note = note,
                assetId = assetId
            )
            _userMessage.value = if (assetId > 0) "تم تحديث الأصل بنجاح" else "تمت إضافة الأصل للمحفظة المالية"
        }
    }

    fun deleteAsset(asset: AssetEntity) {
        viewModelScope.launch {
            appContainer.financeService.deleteAsset(asset)
            _userMessage.value = "تم حذف الأصل من المحفظة"
        }
    }

    fun setBudgetLimit(categoryId: Long, limit: Double, currency: CurrencyType, yearMonth: String) {
        if (limit < 0.0) return
        viewModelScope.launch {
            appContainer.financeService.setBudget(categoryId, limit, currency, yearMonth)
            _userMessage.value = "تم حفظ سقف الميزانية للشهر المحدد"
        }
    }

    fun deleteTransaction(tx: FinanceTransactionEntity) {
        viewModelScope.launch {
            appContainer.financeService.deleteTransaction(tx)
            _userMessage.value = "تم حذف الحركة المالية"
        }
    }

    fun setBiometricLockEnabled(enabled: Boolean) {
        appContainer.securityPreferences.setBiometricEnabled(enabled)
    }

    fun unlockSession() {
        appContainer.securityPreferences.unlockSession()
    }

    fun lockSessionNow() {
        appContainer.securityPreferences.lockSession()
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // --- AI Configuration via Encrypted File & Multi-Key Failover ---
    fun saveKeySlots(slots: List<String>, baseUrl: String? = null, model: String? = null) {
        if (!baseUrl.isNullOrBlank()) {
            appContainer.aiPreferences.baseUrl = baseUrl.trim()
        }
        if (!model.isNullOrBlank()) {
            appContainer.aiPreferences.model = model.trim()
        }
        appContainer.aiPreferences.saveKeySlots(slots)
        _aiConfigVersion.update { it + 1 }
        _userMessage.value = "تم حفظ المعرفات بنجاح"
    }

    fun getKeySlots(): List<String> {
        return appContainer.aiPreferences.getKeySlots()
    }

    fun saveThreeAiKeys(
        primary: String,
        backup: String,
        reserve: String,
        model: String = com.example.security.AiPreferences.DEFAULT_GROK_MODEL
    ) {
        val keys = listOf(primary, backup, reserve).map { it.trim() }.filter { it.isNotBlank() }
        appContainer.aiPreferences.provider = com.example.security.AiPreferences.PROVIDER_GROK
        appContainer.aiPreferences.baseUrl = com.example.security.AiPreferences.DEFAULT_GROK_URL
        appContainer.aiPreferences.model = model.ifBlank { com.example.security.AiPreferences.DEFAULT_GROK_MODEL }
        appContainer.aiPreferences.saveThreeKeySlots(primary, backup, reserve)
        _aiConfigVersion.update { it + 1 }
        _aiTestConnectionResult.value = null
        _userMessage.value = if (keys.isNotEmpty()) "تم حفظ مفاتيح التشغيل بأمان" else "تم مسح المفاتيح"
    }

    fun getThreeAiKeys(): Triple<String, String, String> {
        return appContainer.aiPreferences.getThreeKeySlots()
    }

    fun testAiConnection() {
        viewModelScope.launch {
            _isTestingAiConnection.value = true
            _aiTestConnectionResult.value = null
            val result = appContainer.llmClient.testConnection()
            result.onSuccess { msg ->
                _isTestingAiConnection.value = false
                _aiTestConnectionResult.value = msg
                _aiConfigVersion.update { it + 1 }
            }.onFailure { err ->
                _isTestingAiConnection.value = false
                _aiTestConnectionResult.value = "فشل: ${err.message}"
            }
        }
    }

    fun applyAiPreset(presetName: String) {
        appContainer.aiPreferences.applyPreset(presetName)
        _aiConfigVersion.update { it + 1 }
        _aiTestConnectionResult.value = null
        _userMessage.value = "تم تطبيق إعدادات المزود: $presetName بنجاح"
    }

    fun clearAiConfiguration() {
        appContainer.aiPreferences.clearConfig()
        _aiConfigVersion.update { it + 1 }
        _aiTestConnectionResult.value = null
        _userMessage.value = "تم مسح المفاتيح بنجاح"
    }

    companion object {
        fun provideFactory(appContainer: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return DashboardViewModel(appContainer) as T
                }
            }
    }
}
