package com.example.presentation.finance

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.AssetEntity
import com.example.data.local.entities.CategoryEntity
import com.example.data.local.entities.DebtEntity
import com.example.data.local.entities.FinanceTransactionEntity
import com.example.domain.finance.FinancialAnalytics
import com.example.domain.models.CurrencyType
import com.example.domain.models.TransactionType
import com.example.services.CurrencyBalance
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AssetsPortfolioView(
    assets: List<AssetEntity>,
    rate: Double,
    onSaveAsset: (name: String, category: String, currentValue: Double, currency: CurrencyType, purchaseCost: Double?, note: String?, assetId: Long) -> Unit,
    onDeleteAsset: (AssetEntity) -> Unit
) {
    var showAddAssetDialog by remember { mutableStateOf(false) }
    var assetToEdit by remember { mutableStateOf<AssetEntity?>(null) }
    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()) }

    // Liquidity Calculation (P3-T22)
    val liquidity = remember(assets, rate) {
        FinancialAnalytics.calculateLiquidity(assets, CurrencyType.SYP, rate)
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Liquidity ratio card (P3-T22)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (liquidity.isHealthy) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
                else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.WaterDrop, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "مؤشر الأصول السائلة (Liquidity Ratio)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "${liquidity.liquidityRatioPercent.toInt()}%",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = if (liquidity.isHealthy) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                    )
                }

                LinearProgressIndicator(
                    progress = { (liquidity.liquidityRatioPercent / 100.0).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (liquidity.isHealthy) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                Text(
                    text = if (liquidity.isHealthy)
                        "ممتاز! لديك وسادة نقدية سائلة تزيد عن 20% لتأمين الطوارئ والالتزامات غير المتوقعة."
                    else
                        "تنبيه: نسبة الأصول السائلة أقل من 20%، يُستحسن تعزيز السيولة النقدية للأمان المالي.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Assets header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "قائمة الأصول والممتلكات (${assets.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = { showAddAssetDialog = true },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("إضافة أصل", fontSize = 12.sp)
            }
        }

        if (assets.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.HomeWork, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
                    Text("لم تُضف أي أصول بعد (نقد، عقارات، ذهب، أسهم، معدات...).")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(assets, key = { it.id }) { asset ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(text = asset.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                    Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                        Text(text = asset.category, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                                Text(
                                    text = "آخر تقييم: ${dateFormat.format(Date(asset.lastValuedAt))}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                if (!asset.note.isNullOrBlank()) {
                                    Text(text = asset.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "${numberFormat.format(asset.currentValue)} ${asset.currency.symbol}",
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(onClick = { assetToEdit = asset }, modifier = Modifier.size(28.dp)) {
                                        Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(onClick = { onDeleteAsset(asset) }, modifier = Modifier.size(28.dp)) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddAssetDialog || assetToEdit != null) {
        val target = assetToEdit
        AssetEditorDialog(
            initialAsset = target,
            onDismiss = {
                showAddAssetDialog = false
                assetToEdit = null
            },
            onSave = { name, category, currentValue, currency, purchaseCost, note ->
                onSaveAsset(name, category, currentValue, currency, purchaseCost, note, target?.id ?: 0L)
                showAddAssetDialog = false
                assetToEdit = null
            }
        )
    }
}

@Composable
fun AssetEditorDialog(
    initialAsset: AssetEntity?,
    onDismiss: () -> Unit,
    onSave: (name: String, category: String, currentValue: Double, currency: CurrencyType, purchaseCost: Double?, note: String?) -> Unit
) {
    var name by remember { mutableStateOf(initialAsset?.name ?: "") }
    val categories = listOf("نقد", "حساب بنكي", "ذهب", "عقارات", "أسهم", "معدات عمل", "أخرى")
    var selectedCategory by remember { mutableStateOf(initialAsset?.category ?: categories[0]) }
    var currentValueInput by remember { mutableStateOf(initialAsset?.currentValue?.toInt()?.toString() ?: "") }
    var purchaseCostInput by remember { mutableStateOf(initialAsset?.purchaseCost?.toInt()?.toString() ?: "") }
    var selectedCurrency by remember { mutableStateOf(initialAsset?.currency ?: CurrencyType.SYP) }
    var note by remember { mutableStateOf(initialAsset?.note ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initialAsset != null) "تحديث تقييم الأصل" else "إضافة أصل للمحفظة", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الأصل (مثال: ذهب عيار 21، شقة، لابتوب)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("تصنيف الأصل:", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(CurrencyType.SYP, CurrencyType.USD).forEach { curr ->
                        FilterChip(
                            selected = selectedCurrency == curr,
                            onClick = { selectedCurrency = curr },
                            label = { Text(curr.displayNameArabic) }
                        )
                    }
                }

                OutlinedTextField(
                    value = currentValueInput,
                    onValueChange = { currentValueInput = it },
                    label = { Text("القيمة التقديرية الحالية (${selectedCurrency.symbol})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = purchaseCostInput,
                    onValueChange = { purchaseCostInput = it },
                    label = { Text("تكلفة الشراء الأصلية (اختياري)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة أو مكان الحفظ (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val value = currentValueInput.toDoubleOrNull() ?: 0.0
                    val cost = purchaseCostInput.toDoubleOrNull()
                    if (name.isNotBlank() && value >= 0.0) {
                        onSave(name.trim(), selectedCategory, value, selectedCurrency, cost, note.ifBlank { null })
                    }
                }
            ) {
                Text("حفظ الأصل")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun FinancialAnalyticsAndForecastHub(
    balance: CurrencyBalance,
    transactions: List<FinanceTransactionEntity>,
    categories: List<CategoryEntity>,
    debts: List<DebtEntity>,
    assets: List<AssetEntity>,
    rate: Double
) {
    val context = LocalContext.current
    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }
    val categoryMap = remember(categories) { categories.associateBy { it.id } }

    // Financial Leakage (P3-T25)
    val leakageItems = remember(transactions, rate) {
        FinancialAnalytics.detectFinancialLeakage(
            transactions = transactions,
            categoryNameLookup = { catId -> categoryMap[catId]?.name ?: "أخرى" },
            targetCurrency = CurrencyType.SYP,
            usdToSypRate = rate
        )
    }

    // Cashflow Forecast (P3-T26)
    val forecast = remember(balance, transactions, debts, rate) {
        FinancialAnalytics.forecastNextMonth(
            currentBalance = balance.sypNet,
            recentTransactions = transactions,
            activeDebts = debts,
            targetCurrency = CurrencyType.SYP,
            usdToSypRate = rate
        )
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Forecast Card (P3-T26)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (forecast.isDeficitRisk) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.Timeline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("محرك التوقعات والتدفق المالي القادم", fontWeight = FontWeight.Bold)
                    }
                    if (forecast.isDeficitRisk) {
                        Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFD32F2F)) {
                            Text("خطر عجز نقدي!", color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                }

                Text(
                    text = "الرصيد التقديري المتوقع بنهاية الشهر القادم (SYP):",
                    style = MaterialTheme.typography.bodySmall
                )

                Text(
                    text = "${numberFormat.format(forecast.projectedSurplusOrDeficit)} ل.س",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    color = if (forecast.projectedSurplusOrDeficit >= 0) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                )

                Text(
                    text = "بناءً على متوسط إيراداتك ومصروفاتك الحالية بالإضافة إلى ديون مستحقة بقيمة ${numberFormat.format(forecast.upcomingDebtsDue)} ل.س.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Leakage Detector (P3-T25)
        if (leakageItems.isNotEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF57C00))
                        Text("كاشف النزيف المالي والمصاريف الدقيقة المتكررة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    }
                    Text(
                        text = "تم رصد مصاريف صغيرة تتكرر باستمرار وتستنزف ميزانيتك دون انتباه:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    leakageItems.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("• ${item.categoryName} (${item.count} مرات)", style = MaterialTheme.typography.bodySmall)
                            Text("${numberFormat.format(item.totalAmount)} ل.س (${item.percentageOfTotal.toInt()}%)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        // Category Breakdown Chart (P3-T23)
        val expenses = transactions.filter { it.type == TransactionType.EXPENSE }
        val categoryExpenses = remember(expenses) {
            expenses.groupBy { it.categoryId }.mapValues { entry -> entry.value.sumOf { it.amount } }
        }
        val totalExpenses = remember(categoryExpenses) { categoryExpenses.values.sum() }

        if (totalExpenses > 0) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("توزيع المصروفات حسب التصنيف (Category Breakdown)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                    // Compose Canvas Donut Chart
                    val colors = listOf(
                        Color(0xFF2E7D32), Color(0xFF1565C0), Color(0xFFE65100),
                        Color(0xFF6A1B9A), Color(0xFFC2185B), Color(0xFF00838F)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Canvas(modifier = Modifier.size(110.dp)) {
                            var startAngle = -90f
                            categoryExpenses.entries.forEachIndexed { idx, entry ->
                                val sweep = ((entry.value / totalExpenses) * 360f).toFloat()
                                val color = colors[idx % colors.size]
                                drawArc(
                                    color = color,
                                    startAngle = startAngle,
                                    sweepAngle = sweep,
                                    useCenter = false,
                                    style = Stroke(width = 24.dp.toPx(), cap = StrokeCap.Butt)
                                )
                                startAngle += sweep
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            categoryExpenses.entries.take(4).forEachIndexed { idx, entry ->
                                val catName = categoryMap[entry.key]?.name ?: "عام"
                                val pct = ((entry.value / totalExpenses) * 100).toInt()
                                val color = colors[idx % colors.size]
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Box(modifier = Modifier.size(10.dp).background(color, CircleShape))
                                    Text("$catName: $pct%", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Export Statement Summary Button (P3-T28)
        OutlinedButton(
            onClick = {
                val summaryText = FinancialAnalytics.generateFinancialSummaryText(
                    monthName = SimpleDateFormat("MMMM yyyy", Locale("ar")).format(Date()),
                    balance = balance,
                    rate = rate,
                    assets = assets,
                    debts = debts
                )
                shareFinancialReport(context, summaryText)
            },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("مشاركة وتصدير التقرير المالي الشامل")
        }
    }
}

private fun shareFinancialReport(context: Context, text: String) {
    try {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "مشاركة التقرير المالي")
        shareIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(shareIntent)
    } catch (_: Exception) {}
}
