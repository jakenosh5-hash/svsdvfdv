package com.example.presentation.finance

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.DebtEntity
import com.example.data.local.entities.DebtPaymentEntity
import com.example.domain.finance.FinancialAnalytics
import com.example.domain.models.CurrencyType
import com.example.domain.models.DebtStatus
import com.example.domain.models.DebtType
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DebtsAndLiabilitiesHub(
    debts: List<DebtEntity>,
    onAddDebtClick: () -> Unit,
    onRecordPayment: (debtId: Long, amount: Double, receiptNote: String?) -> Unit,
    onDeleteDebt: (Long) -> Unit
) {
    var selectedDebtType by remember { mutableStateOf(DebtType.I_OWE) }
    var strategy by remember { mutableStateOf<FinancialAnalytics.PayoffStrategy?>(null) }
    var selectedDebtForPayment by remember { mutableStateOf<DebtEntity?>(null) }
    val context = LocalContext.current
    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()) }

    val debtsForTab = remember(debts, selectedDebtType, strategy) {
        val filtered = debts.filter { it.type == selectedDebtType }
        if (selectedDebtType == DebtType.I_OWE && strategy != null) {
            FinancialAnalytics.prioritizeDebts(filtered, strategy!!)
        } else {
            filtered.sortedWith(compareBy<DebtEntity> { it.status != DebtStatus.ACTIVE }.thenBy { it.dueDate ?: Long.MAX_VALUE })
        }
    }

    // Totals for this tab
    val totalRemainingSyp = remember(debtsForTab) {
        debtsForTab.filter { it.currency == CurrencyType.SYP && it.status == DebtStatus.ACTIVE }.sumOf { it.remainingAmount }
    }
    val totalRemainingUsd = remember(debtsForTab) {
        debtsForTab.filter { it.currency == CurrencyType.USD && it.status == DebtStatus.ACTIVE }.sumOf { it.remainingAmount }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Debt Category Tabs: I Owe vs Owed To Me
        TabRow(selectedTabIndex = if (selectedDebtType == DebtType.I_OWE) 0 else 1) {
            Tab(
                selected = selectedDebtType == DebtType.I_OWE,
                onClick = { selectedDebtType = DebtType.I_OWE },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.CallMade, contentDescription = null, tint = Color(0xFFD32F2F), modifier = Modifier.size(16.dp))
                        Text("ديون عليّ (I Owe)", fontWeight = FontWeight.Bold)
                    }
                }
            )
            Tab(
                selected = selectedDebtType == DebtType.OWED_TO_ME,
                onClick = { selectedDebtType = DebtType.OWED_TO_ME },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.CallReceived, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                        Text("ديون لي (Owed to Me)", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // Summary Card for this debt tab
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (selectedDebtType == DebtType.I_OWE) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = if (selectedDebtType == DebtType.I_OWE) "إجمالي المتبقي عليك سداده:" else "إجمالي المستحقات لك لتحصيلها:",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "${numberFormat.format(totalRemainingSyp)} ل.س  |  $${numberFormat.format(totalRemainingUsd)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = if (selectedDebtType == DebtType.I_OWE) Color(0xFFD32F2F) else Color(0xFF2E7D32)
                    )
                }

                Button(
                    onClick = onAddDebtClick,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تدوين دين", fontSize = 12.sp)
                }
            }
        }

        // Payoff Strategy selector (only for I Owe)
        if (selectedDebtType == DebtType.I_OWE && debtsForTab.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "خطة الترتيب والسداد المقترحة:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = strategy == FinancialAnalytics.PayoffStrategy.SNOWBALL,
                        onClick = {
                            strategy = if (strategy == FinancialAnalytics.PayoffStrategy.SNOWBALL) null
                            else FinancialAnalytics.PayoffStrategy.SNOWBALL
                        },
                        label = { Text("كرة الثلج (الأصغر أولاً)", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = strategy == FinancialAnalytics.PayoffStrategy.AVALANCHE,
                        onClick = {
                            strategy = if (strategy == FinancialAnalytics.PayoffStrategy.AVALANCHE) null
                            else FinancialAnalytics.PayoffStrategy.AVALANCHE
                        },
                        label = { Text("الانهيار الجليدي (الأكبر/الفائدة)", fontSize = 11.sp) }
                    )
                }
            }
        }

        // Debts list
        if (debtsForTab.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.ThumbUp, contentDescription = null, tint = Color(0xFF2E7D32))
                    Text(
                        text = if (selectedDebtType == DebtType.I_OWE) "لا توجد ديون مسجلة عليك حالياً. ذمتك بريئة ومرتاحة!"
                        else "لا توجد مستحقات مسجلة لك حالياً.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(debtsForTab, key = { it.id }) { debt ->
                    DebtCardItem(
                        debt = debt,
                        numberFormat = numberFormat,
                        dateFormat = dateFormat,
                        onRecordPaymentClick = { selectedDebtForPayment = debt },
                        onDeleteClick = { onDeleteDebt(debt.id) },
                        onCallPhone = { phone ->
                            if (!phone.isNullOrBlank()) {
                                launchDialer(context, phone)
                            }
                        },
                        onSendSms = { phone ->
                            if (!phone.isNullOrBlank()) {
                                launchSms(context, phone)
                            }
                        }
                    )
                }
            }
        }
    }

    if (selectedDebtForPayment != null) {
        RecordPaymentDialog(
            debt = selectedDebtForPayment!!,
            onDismiss = { selectedDebtForPayment = null },
            onConfirmPayment = { amount, receiptNote ->
                onRecordPayment(selectedDebtForPayment!!.id, amount, receiptNote)
                selectedDebtForPayment = null
            }
        )
    }
}

@Composable
fun DebtCardItem(
    debt: DebtEntity,
    numberFormat: NumberFormat,
    dateFormat: SimpleDateFormat,
    onRecordPaymentClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onCallPhone: (String?) -> Unit,
    onSendSms: (String?) -> Unit
) {
    val isPaid = debt.status == DebtStatus.PAID
    val isNearDue = debt.dueDate != null && (debt.dueDate - System.currentTimeMillis()) in 0..(3L * 24 * 3600 * 1000)
    val isOverdue = debt.dueDate != null && debt.dueDate < System.currentTimeMillis() && !isPaid

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = if (isPaid) Color(0xFF2E7D32).copy(alpha = 0.15f)
                        else if (debt.type == DebtType.I_OWE) Color(0xFFD32F2F).copy(alpha = 0.15f)
                        else Color(0xFF1565C0).copy(alpha = 0.15f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isPaid) Icons.Default.CheckCircle else Icons.Default.Person,
                                contentDescription = null,
                                tint = if (isPaid) Color(0xFF2E7D32)
                                else if (debt.type == DebtType.I_OWE) Color(0xFFD32F2F)
                                else Color(0xFF1565C0),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Column {
                        Text(
                            text = debt.personName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (!debt.phoneNumber.isNullOrBlank()) {
                            Text(
                                text = debt.phoneNumber,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                }

                // Status chip
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when {
                        isPaid -> Color(0xFF2E7D32)
                        isOverdue -> Color(0xFFD32F2F)
                        isNearDue -> Color(0xFFF57C00)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Text(
                        text = when {
                            isPaid -> "تم السداد بالكامل ✓"
                            isOverdue -> "متأخر عن الموعد!"
                            isNearDue -> "قريب الاستحقاق!"
                            else -> "نشط"
                        },
                        color = if (isPaid || isOverdue || isNearDue) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Financial Numbers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "المبلغ المتبقي:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Text(
                        text = "${numberFormat.format(debt.remainingAmount)} ${debt.currency.symbol}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = if (isPaid) Color(0xFF2E7D32) else if (debt.type == DebtType.I_OWE) Color(0xFFD32F2F) else Color(0xFF1565C0)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "الأصل: ${numberFormat.format(debt.originalAmount)} ${debt.currency.symbol}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (debt.dueDate != null) {
                        Text(
                            text = "الموعد: ${dateFormat.format(Date(debt.dueDate))}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isOverdue) Color(0xFFD32F2F) else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            if (!debt.note.isNullOrBlank()) {
                Text(
                    text = debt.note,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quick Call & SMS
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (!debt.phoneNumber.isNullOrBlank()) {
                        IconButton(onClick = { onCallPhone(debt.phoneNumber) }, modifier = Modifier.size(32.dp)) {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = "اتصال", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = { onSendSms(debt.phoneNumber) }, modifier = Modifier.size(32.dp)) {
                            Icon(imageVector = Icons.Default.Sms, contentDescription = "رسالة", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                    }
                    IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(18.dp))
                    }
                }

                if (!isPaid) {
                    Button(
                        onClick = onRecordPaymentClick,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تسجيل دفعة سداد", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RecordPaymentDialog(
    debt: DebtEntity,
    onDismiss: () -> Unit,
    onConfirmPayment: (amount: Double, receiptNote: String?) -> Unit
) {
    var amountInput by remember { mutableStateOf(debt.remainingAmount.toInt().toString()) }
    var noteInput by remember { mutableStateOf("") }
    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.Payment, contentDescription = null)
                Text("تسجيل دفعة سداد", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "سداد دفعة للدين المسجل لـ: ${debt.personName}\nالمبلغ المتبقي الحالي: ${numberFormat.format(debt.remainingAmount)} ${debt.currency.symbol}",
                    style = MaterialTheme.typography.bodyMedium
                )

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("مبلغ الدفعة المسددة (${debt.currency.symbol})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = noteInput,
                    onValueChange = { noteInput = it },
                    label = { Text("رقم الإيصال أو ملاحظة الدفعة (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountInput.toDoubleOrNull() ?: 0.0
                    if (amount > 0.0) {
                        onConfirmPayment(amount, noteInput.ifBlank { null })
                    }
                }
            ) {
                Text("تأكيد السداد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

private fun launchDialer(context: Context, phoneNumber: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${phoneNumber.trim()}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Exception) {}
}

private fun launchSms(context: Context, phoneNumber: String) {
    try {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${phoneNumber.trim()}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Exception) {}
}
