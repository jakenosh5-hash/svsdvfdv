package com.example.presentation.finance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.AssetEntity
import com.example.data.local.entities.DebtEntity
import com.example.domain.finance.FinancialAnalytics
import com.example.domain.models.CurrencyType
import com.example.services.CurrencyBalance
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun UnifiedNetWorthCard(
    balance: CurrencyBalance,
    rate: Double,
    assets: List<AssetEntity>,
    debts: List<DebtEntity>,
    onOpenConverter: () -> Unit,
    onOpenRateEditor: () -> Unit
) {
    var netWorthCurrency by remember { mutableStateOf(CurrencyType.SYP) }
    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }

    val netWorth = remember(netWorthCurrency, rate, balance, assets, debts) {
        FinancialAnalytics.calculateUnifiedNetWorth(netWorthCurrency, rate, balance, assets, debts)
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Savings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Text(
                        text = "صافي القيمة التقديرية (Net Worth)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                // Currency toggle button (SYP / USD)
                Row(
                    modifier = Modifier
                        .background(
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    listOf(CurrencyType.SYP, CurrencyType.USD).forEach { curr ->
                        val selected = netWorthCurrency == curr
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                            onClick = { netWorthCurrency = curr },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = curr.symbol,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Big Net Worth Number
            Text(
                text = "${numberFormat.format(netWorth)} ${netWorthCurrency.symbol}",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = if (netWorth >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )

            Text(
                text = "تشمل الأرصدة النقدية، تقييم الأصول المسجلة، وطرح الديون المستحقة بسعر الصرف الحالي.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )

            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Default.CurrencyExchange,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "1 USD = ${numberFormat.format(rate)} SYP",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(
                        onClick = onOpenConverter,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("محول العملات", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onOpenRateEditor,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تعديل السعر", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CurrencyConverterDialog(
    currentRate: Double,
    onDismiss: () -> Unit
) {
    var amountInput by remember { mutableStateOf("100") }
    var directionUsdToSyp by remember { mutableStateOf(true) }
    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }

    val inputVal = amountInput.toDoubleOrNull() ?: 0.0
    val convertedVal = if (directionUsdToSyp) {
        inputVal * currentRate
    } else {
        if (currentRate > 0) inputVal / currentRate else 0.0
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.Calculate, contentDescription = null)
                Text("محول العملات الداخلي السريع", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = "التحويل الفوري بناءً على سعر الصرف اليدوي: 1 USD = ${numberFormat.format(currentRate)} SYP",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = directionUsdToSyp,
                        onClick = { directionUsdToSyp = true },
                        label = { Text("USD ➔ SYP") }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = !directionUsdToSyp,
                        onClick = { directionUsdToSyp = false },
                        label = { Text("SYP ➔ USD") }
                    )
                }

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text(if (directionUsdToSyp) "المبلغ بالدولار ($)" else "المبلغ بالليرة السورية (ل.س)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "المبلغ المحسوب:",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "${numberFormat.format(convertedVal)} ${if (directionUsdToSyp) "ل.س" else "$"}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
fun EditExchangeRateDialog(
    currentRate: Double,
    onDismiss: () -> Unit,
    onSaveRate: (Double) -> Unit
) {
    var rateInput by remember { mutableStateOf(currentRate.toInt().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.CurrencyExchange, contentDescription = null)
                Text("إدارة سعر الصرف اليدوي", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "أدخل سعر صرف 1 دولار أمريكي بالليرة السورية كما هو متداول محلياً. يتم حفظ السعر بتاريخ وتوقيت التعديل وتحديث الحسابات فوراً.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = rateInput,
                    onValueChange = { rateInput = it },
                    label = { Text("سعر الصرف (ل.س لكل دولار)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val rate = rateInput.toDoubleOrNull() ?: 0.0
                    if (rate > 0) {
                        onSaveRate(rate)
                        onDismiss()
                    }
                }
            ) {
                Text("حفظ السعر")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
