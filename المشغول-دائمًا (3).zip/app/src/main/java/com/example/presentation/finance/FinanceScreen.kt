package com.example.presentation.finance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.CurrencyType
import com.example.presentation.components.AddDebtDialog
import com.example.presentation.components.AddTransactionDialog
import com.example.presentation.dashboard.DashboardViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    viewModel: DashboardViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: المركز المالي، 1: الديون، 2: الميزانيات، 3: الأصول والتحليلات
    var selectedCurrency by remember { mutableStateOf(CurrencyType.SYP) }

    var showAddTxDialog by remember { mutableStateOf(false) }
    var showAddDebtDialog by remember { mutableStateOf(false) }
    var showAddBudgetDialog by remember { mutableStateOf(false) }
    var showConverterDialog by remember { mutableStateOf(false) }
    var showRateDialog by remember { mutableStateOf(false) }

    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }
    val currentYearMonth = remember { SimpleDateFormat("yyyy-MM", Locale.US).format(Date()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الجناح المالي المزدوج (SYP & USD)", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showConverterDialog = true }) {
                        Icon(imageVector = Icons.Default.Calculate, contentDescription = "محول العملات")
                    }
                    IconButton(onClick = { showRateDialog = true }) {
                        Icon(imageVector = Icons.Default.CurrencyExchange, contentDescription = "سعر الصرف")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    when (selectedTab) {
                        0 -> showAddTxDialog = true
                        1 -> showAddDebtDialog = true
                        2 -> showAddBudgetDialog = true
                        3 -> showAddTxDialog = true
                    }
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = when (selectedTab) {
                        0 -> Icons.Default.AddCard
                        1 -> Icons.Default.ReceiptLong
                        2 -> Icons.Default.PieChart
                        else -> Icons.Default.Add
                    },
                    contentDescription = "إضافة"
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Scrollable TabRow for the 4 core Finance sections
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 0.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("المركز والحركات", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("دفتر الديون", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("الميزانيات الشهرية", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("الأصول والتحليلات", fontWeight = FontWeight.Bold) }
                )
            }

            when (selectedTab) {
                0 -> {
                    // Tab 0: Core Finance & Transactions
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        // 1. Unified Net Worth Card (P3-T04, P3-T02, P3-T03)
                        item {
                            UnifiedNetWorthCard(
                                balance = uiState.currencyBalance,
                                rate = uiState.exchangeRate,
                                assets = uiState.assets,
                                debts = uiState.allDebts,
                                onOpenConverter = { showConverterDialog = true },
                                onOpenRateEditor = { showRateDialog = true }
                            )
                        }

                        // 2. Dual-currency Balances
                        item {
                            // Currency selector
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(CurrencyType.SYP, CurrencyType.USD).forEach { c ->
                                    val isSelected = selectedCurrency == c
                                    Button(
                                        onClick = { selectedCurrency = c },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = if (isSelected) {
                                            ButtonDefaults.buttonColors(
                                                containerColor = if (c == CurrencyType.SYP) Color(0xFF2E7D32) else Color(0xFF1565C0)
                                            )
                                        } else {
                                            ButtonDefaults.buttonColors(
                                                containerColor = Color.Transparent,
                                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    ) {
                                        Text("${c.displayNameArabic} (${c.symbol})", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        item {
                            val net = if (selectedCurrency == CurrencyType.SYP) uiState.currencyBalance.sypNet else uiState.currencyBalance.usdNet
                            val income = if (selectedCurrency == CurrencyType.SYP) uiState.currencyBalance.sypIncome else uiState.currencyBalance.usdIncome
                            val expense = if (selectedCurrency == CurrencyType.SYP) uiState.currencyBalance.sypExpense else uiState.currencyBalance.usdExpense

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "صافي الرصيد النقدي (${selectedCurrency.displayNameArabic})",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${numberFormat.format(net)} ${selectedCurrency.symbol}",
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Black,
                                        color = if (net >= 0) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "الدخل: +${numberFormat.format(income)}",
                                            color = Color(0xFF2E7D32),
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "المصروف: -${numberFormat.format(expense)}",
                                            color = Color(0xFFD32F2F),
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                            }
                        }

                        // 3. Transactions Ledger with multi-filtering (P3-T05)
                        item {
                            Text(
                                text = "سجل الحركات والمعاملات",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        item {
                            TransactionLedgerView(
                                transactions = uiState.financeTransactions,
                                categories = uiState.categories,
                                projects = uiState.projects,
                                onDeleteTransaction = { tx -> viewModel.deleteTransaction(tx) },
                                onAddNewTransaction = { showAddTxDialog = true }
                            )
                        }
                    }
                }

                1 -> {
                    // Tab 1: Comprehensive Debts Hub (P3-T13 to P3-T18, P3-T27)
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        item {
                            DebtsAndLiabilitiesHub(
                                debts = uiState.allDebts,
                                onAddDebtClick = { showAddDebtDialog = true },
                                onRecordPayment = { debtId, amount, note ->
                                    viewModel.recordPartialDebtPayment(debtId, amount, note)
                                },
                                onDeleteDebt = { debtId -> viewModel.deleteDebt(debtId) }
                            )
                        }
                    }
                }

                2 -> {
                    // Tab 2: Monthly Budgets (P3-T10 to P3-T12)
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        item {
                            MonthlyBudgetsView(
                                budgets = uiState.budgets,
                                transactions = uiState.financeTransactions,
                                categories = uiState.categories,
                                currentYearMonth = currentYearMonth,
                                onOpenAddBudget = { showAddBudgetDialog = true }
                            )
                        }
                    }
                }

                3 -> {
                    // Tab 3: Assets Portfolio & Analytics (P3-T19 to P3-T26, P3-T28)
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        item {
                            AssetsPortfolioView(
                                assets = uiState.assets,
                                rate = uiState.exchangeRate,
                                onSaveAsset = { name, category, value, currency, cost, note, assetId ->
                                    viewModel.saveAsset(name, category, value, currency, cost, note, assetId)
                                },
                                onDeleteAsset = { asset -> viewModel.deleteAsset(asset) }
                            )
                        }

                        item {
                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        }

                        item {
                            FinancialAnalyticsAndForecastHub(
                                balance = uiState.currencyBalance,
                                transactions = uiState.financeTransactions,
                                categories = uiState.categories,
                                debts = uiState.allDebts,
                                assets = uiState.assets,
                                rate = uiState.exchangeRate
                            )
                        }
                    }
                }
            }
        }
    }

    // Dialogs
    if (showAddTxDialog) {
        AddTransactionDialog(
            categories = uiState.categories,
            onDismiss = { showAddTxDialog = false },
            onConfirm = { type, amount, currency, categoryId, note ->
                viewModel.recordQuickTransaction(type, amount, currency, categoryId, note)
                showAddTxDialog = false
            }
        )
    }

    if (showAddDebtDialog) {
        AddDebtDialog(
            onDismiss = { showAddDebtDialog = false },
            onConfirm = { type, person, amount, currency, phone, note ->
                viewModel.quickCreateDebt(type, person, amount, currency, null, phone, note)
                showAddDebtDialog = false
            }
        )
    }

    if (showAddBudgetDialog) {
        AddBudgetDialog(
            categories = uiState.categories,
            currentYearMonth = currentYearMonth,
            onDismiss = { showAddBudgetDialog = false },
            onSaveBudget = { catId, limit, curr, ym ->
                viewModel.setBudgetLimit(catId, limit, curr, ym)
                showAddBudgetDialog = false
            }
        )
    }

    if (showConverterDialog) {
        CurrencyConverterDialog(
            currentRate = uiState.exchangeRate,
            onDismiss = { showConverterDialog = false }
        )
    }

    if (showRateDialog) {
        EditExchangeRateDialog(
            currentRate = uiState.exchangeRate,
            onDismiss = { showRateDialog = false },
            onSaveRate = { newRate ->
                viewModel.updateManualExchangeRate(newRate)
                showRateDialog = false
            }
        )
    }
}
