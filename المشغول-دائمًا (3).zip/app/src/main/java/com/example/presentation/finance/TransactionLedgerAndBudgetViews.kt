package com.example.presentation.finance

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.BudgetEntity
import com.example.data.local.entities.CategoryEntity
import com.example.data.local.entities.FinanceTransactionEntity
import com.example.data.local.entities.ProjectEntity
import com.example.domain.models.CurrencyType
import com.example.domain.models.TransactionType
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionLedgerView(
    transactions: List<FinanceTransactionEntity>,
    categories: List<CategoryEntity>,
    projects: List<ProjectEntity>,
    onDeleteTransaction: (FinanceTransactionEntity) -> Unit,
    onAddNewTransaction: () -> Unit
) {
    var filterType by remember { mutableStateOf<TransactionType?>(null) }
    var filterCurrency by remember { mutableStateOf<CurrencyType?>(null) }
    var filterCategoryId by remember { mutableStateOf<Long?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }

    val categoryMap = remember(categories) { categories.associateBy { it.id } }
    val projectMap = remember(projects) { projects.associateBy { it.id } }

    val filteredTransactions = remember(transactions, filterType, filterCurrency, filterCategoryId, searchQuery) {
        transactions.filter { tx ->
            val matchType = filterType == null || tx.type == filterType
            val matchCurrency = filterCurrency == null || tx.currency == filterCurrency
            val matchCat = filterCategoryId == null || tx.categoryId == filterCategoryId
            val matchQuery = searchQuery.isBlank() ||
                    (tx.note?.contains(searchQuery, ignoreCase = true) == true) ||
                    tx.amount.toString().contains(searchQuery)
            matchType && matchCurrency && matchCat && matchQuery
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("بحث في المعاملات أو الملاحظات...") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح")
                    }
                }
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        // Filters Row 1: Type
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                FilterChip(
                    selected = filterType == null,
                    onClick = { filterType = null },
                    label = { Text("الكل") }
                )
            }
            item {
                FilterChip(
                    selected = filterType == TransactionType.INCOME,
                    onClick = { filterType = if (filterType == TransactionType.INCOME) null else TransactionType.INCOME },
                    label = { Text("إيرادات (+)") }
                )
            }
            item {
                FilterChip(
                    selected = filterType == TransactionType.EXPENSE,
                    onClick = { filterType = if (filterType == TransactionType.EXPENSE) null else TransactionType.EXPENSE },
                    label = { Text("مصروفات (-)") }
                )
            }
            item {
                FilterChip(
                    selected = filterCurrency == CurrencyType.SYP,
                    onClick = { filterCurrency = if (filterCurrency == CurrencyType.SYP) null else CurrencyType.SYP },
                    label = { Text("ليرة سورية (SYP)") }
                )
            }
            item {
                FilterChip(
                    selected = filterCurrency == CurrencyType.USD,
                    onClick = { filterCurrency = if (filterCurrency == CurrencyType.USD) null else CurrencyType.USD },
                    label = { Text("دولار أمريكي (USD)") }
                )
            }
        }

        // Transactions count
        Text(
            text = "عدد الحركات المعروضة: ${filteredTransactions.size}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (filteredTransactions.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("لا توجد حركات تطابق الفلاتر المحددة", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredTransactions, key = { it.id }) { tx ->
                    val isIncome = tx.type == TransactionType.INCOME
                    val cat = categoryMap[tx.categoryId]
                    val project = tx.projectId?.let { projectMap[it] }

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (isIncome) Color(0xFF2E7D32).copy(alpha = 0.15f) else Color(0xFFD32F2F).copy(alpha = 0.15f),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = if (isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                            contentDescription = null,
                                            tint = if (isIncome) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = cat?.name ?: "تصنيف عام",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    if (!tx.note.isNullOrBlank()) {
                                        Text(
                                            text = tx.note,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(
                                            text = dateFormat.format(Date(tx.transactionDate)),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                        if (project != null) {
                                            Text(
                                                text = "• مشروع: ${project.name}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "${if (isIncome) "+" else "-"}${numberFormat.format(tx.amount)} ${tx.currency.symbol}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (isIncome) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                                    style = MaterialTheme.typography.titleMedium
                                )

                                IconButton(
                                    onClick = { onDeleteTransaction(tx) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف الحركة",
                                        tint = MaterialTheme.colorScheme.outline,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MonthlyBudgetsView(
    budgets: List<BudgetEntity>,
    transactions: List<FinanceTransactionEntity>,
    categories: List<CategoryEntity>,
    currentYearMonth: String,
    onOpenAddBudget: () -> Unit
) {
    val numberFormat = remember { NumberFormat.getNumberInstance(Locale.US) }
    val categoryMap = remember(categories) { categories.associateBy { it.id } }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الميزانيات الشهرية ($currentYearMonth)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = onOpenAddBudget,
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("ضبط ميزانية", fontSize = 12.sp)
            }
        }

        if (budgets.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "لم يتم تحديد سقوف ميزانية لهذا الشهر حتى الآن.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "حدد حداً أقصى للصرف على أي تصنيف لتفعيل الإنذار المبكر عند وصول الإنفاق إلى 80% أو تجاوزه 100%.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                budgets.forEach { budget ->
                    val cat = categoryMap[budget.categoryId]
                    // Calculate actual spent in this category and currency
                    val spent = transactions
                        .filter { it.type == TransactionType.EXPENSE && it.categoryId == budget.categoryId && it.currency == budget.currency }
                        .sumOf { it.amount }

                    val percent = if (budget.monthlyLimit > 0) (spent / budget.monthlyLimit).toFloat() else 0f
                    val isExceeded = spent >= budget.monthlyLimit
                    val isNearLimit = spent >= (budget.monthlyLimit * 0.8) && !isExceeded

                    val barColor = when {
                        isExceeded -> Color(0xFFD32F2F) // Red warning 100%
                        isNearLimit -> Color(0xFFF57C00) // Amber warning 80%
                        else -> Color(0xFF2E7D32) // Healthy Green
                    }

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = cat?.name ?: "تصنيف غير معروف",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    if (isExceeded) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFFD32F2F)
                                        ) {
                                            Text(
                                                text = "تجاوز السقف!",
                                                color = Color.White,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    } else if (isNearLimit) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFFF57C00)
                                        ) {
                                            Text(
                                                text = "اقترب من الحد (80%)",
                                                color = Color.White,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = "${numberFormat.format(spent)} / ${numberFormat.format(budget.monthlyLimit)} ${budget.currency.symbol}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            LinearProgressIndicator(
                                progress = { percent.coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = barColor,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "نسبة الاستهلاك: ${(percent * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = barColor
                                )
                                val remaining = (budget.monthlyLimit - spent).coerceAtLeast(0.0)
                                Text(
                                    text = "المتبقي: ${numberFormat.format(remaining)} ${budget.currency.symbol}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddBudgetDialog(
    categories: List<CategoryEntity>,
    currentYearMonth: String,
    onDismiss: () -> Unit,
    onSaveBudget: (categoryId: Long, limit: Double, currency: CurrencyType, yearMonth: String) -> Unit
) {
    var selectedCategoryId by remember { mutableStateOf(categories.firstOrNull()?.id ?: 0L) }
    var limitInput by remember { mutableStateOf("") }
    var selectedCurrency by remember { mutableStateOf(CurrencyType.SYP) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ضبط سقف الميزانية الشهرية", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "حدد الحد الأقصى للمصروف في شهر $currentYearMonth للتنبيه المبكر عند وصول الإنفاق إلى 80% وتجاوزه.",
                    style = MaterialTheme.typography.bodySmall
                )

                // Category Selector
                Text("التصنيف المستهدف:", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategoryId == cat.id,
                            onClick = { selectedCategoryId = cat.id },
                            label = { Text(cat.name) }
                        )
                    }
                }

                // Currency selector
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(CurrencyType.SYP, CurrencyType.USD).forEach { curr ->
                        FilterChip(
                            selected = selectedCurrency == curr,
                            onClick = { selectedCurrency = curr },
                            label = { Text(curr.displayNameArabic) }
                        )
                    }
                }

                OutlinedTextField(
                    value = limitInput,
                    onValueChange = { limitInput = it },
                    label = { Text("الحد الأقصى الشهري (${selectedCurrency.symbol})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val limit = limitInput.toDoubleOrNull() ?: 0.0
                    if (selectedCategoryId > 0 && limit > 0) {
                        onSaveBudget(selectedCategoryId, limit, selectedCurrency, currentYearMonth)
                        onDismiss()
                    }
                }
            ) {
                Text("حفظ الميزانية")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
