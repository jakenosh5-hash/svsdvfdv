package com.example.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val titleArabic: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "الرئيسية", Icons.Default.Home)
    object Productivity : Screen("productivity", "الإنتاجية", Icons.Default.CheckCircle)
    object Finance : Screen("finance", "المالية", Icons.Default.AccountBalanceWallet)
    object CalendarGoals : Screen("calendar_goals", "التقويم والأهداف", Icons.Default.CalendarMonth)
    object AiHub : Screen("ai_hub", "AI", Icons.Default.AutoAwesome)
    object Settings : Screen("settings", "الإعدادات", Icons.Default.Settings)
}
