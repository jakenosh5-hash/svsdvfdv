package com.example.presentation.productivity

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entities.*
import com.example.domain.models.TaskPriority
import com.example.domain.models.TaskStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// -----------------------------------------------------------------------------
// EISENHOWER MATRIX VIEW (P2-T04)
// -----------------------------------------------------------------------------

@Composable
fun EisenhowerMatrixView(
    tasks: List<TaskEntity>,
    onToggleTask: (Long) -> Unit,
    onUpdatePriority: (Long, TaskPriority) -> Unit,
    onTaskClick: (TaskEntity) -> Unit
) {
    val q1 = tasks.filter { it.priority == TaskPriority.URGENT_IMPORTANT && it.status != TaskStatus.COMPLETED }
    val q2 = tasks.filter { it.priority == TaskPriority.IMPORTANT_NOT_URGENT && it.status != TaskStatus.COMPLETED }
    val q3 = tasks.filter { it.priority == TaskPriority.URGENT_NOT_IMPORTANT && it.status != TaskStatus.COMPLETED }
    val q4 = tasks.filter { it.priority == TaskPriority.NEITHER && it.status != TaskStatus.COMPLETED }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "مصفوفة أيزنهاور لتحديد الأولويات",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            EisenhowerQuadrantCard(
                title = "افعل أولاً (عاجل ومهم)",
                subtitle = "أزمات ومواعيد حاسمة",
                tasks = q1,
                containerColor = Color(0xFFFFEBEE),
                headerColor = Color(0xFFC62828),
                modifier = Modifier.weight(1f),
                onToggleTask = onToggleTask,
                onTaskClick = onTaskClick
            )
            EisenhowerQuadrantCard(
                title = "خطط وركز (مهم غير عاجل)",
                subtitle = "النمو والتطوير الذاتي",
                tasks = q2,
                containerColor = Color(0xFFE8F5E9),
                headerColor = Color(0xFF2E7D32),
                modifier = Modifier.weight(1f),
                onToggleTask = onToggleTask,
                onTaskClick = onTaskClick
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            EisenhowerQuadrantCard(
                title = "فوّض أو اختصر (عاجل غير مهم)",
                subtitle = "مقاطعات وتفاصيل",
                tasks = q3,
                containerColor = Color(0xFFFFF8E1),
                headerColor = Color(0xFFF57F17),
                modifier = Modifier.weight(1f),
                onToggleTask = onToggleTask,
                onTaskClick = onTaskClick
            )
            EisenhowerQuadrantCard(
                title = "تخلّ عنها (غير عاجل وغير مهم)",
                subtitle = "مشتتات ومضيعات وقت",
                tasks = q4,
                containerColor = Color(0xFFECEFF1),
                headerColor = Color(0xFF455A64),
                modifier = Modifier.weight(1f),
                onToggleTask = onToggleTask,
                onTaskClick = onTaskClick
            )
        }
    }
}

@Composable
private fun EisenhowerQuadrantCard(
    title: String,
    subtitle: String,
    tasks: List<TaskEntity>,
    containerColor: Color,
    headerColor: Color,
    modifier: Modifier = Modifier,
    onToggleTask: (Long) -> Unit,
    onTaskClick: (TaskEntity) -> Unit
) {
    Card(
        modifier = modifier.fillMaxHeight(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = headerColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Badge(containerColor = headerColor) {
                    Text("${tasks.size}", color = Color.White, fontSize = 10.sp)
                }
            }
            Text(text = subtitle, fontSize = 10.sp, color = headerColor.copy(alpha = 0.8f))
            Spacer(modifier = Modifier.height(6.dp))

            if (tasks.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("فارغ", fontSize = 11.sp, color = Color.Gray)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(tasks, key = { it.id }) { task ->
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onTaskClick(task) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = task.status == TaskStatus.COMPLETED,
                                    onCheckedChange = { onToggleTask(task.id) },
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = task.title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// KANBAN & TIMELINE HUB (P2-T08)
// -----------------------------------------------------------------------------

@Composable
fun ProjectKanbanAndTimelineHub(
    project: ProjectEntity,
    projectTasks: List<TaskEntity>,
    onBack: () -> Unit,
    onUpdateTaskStatus: (Long, TaskStatus) -> Unit,
    onToggleTask: (Long) -> Unit,
    onTaskClick: (TaskEntity) -> Unit,
    onArchiveProject: () -> Unit
) {
    var isTimelineMode by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = project.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "المهام: ${projectTasks.size} (المنجز: ${projectTasks.count { it.status == TaskStatus.COMPLETED }})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row {
                IconButton(onClick = { isTimelineMode = !isTimelineMode }) {
                    Icon(
                        imageVector = if (isTimelineMode) Icons.Default.ViewKanban else Icons.Default.Timeline,
                        contentDescription = "تبديل العرض"
                    )
                }
                IconButton(onClick = onArchiveProject) {
                    Icon(Icons.Default.Archive, contentDescription = "أرشفة المشروع")
                }
            }
        }

        if (isTimelineMode) {
            ProjectTimelineView(
                tasks = projectTasks,
                onTaskClick = onTaskClick,
                onToggleTask = onToggleTask
            )
        } else {
            ProjectKanbanBoard(
                tasks = projectTasks,
                onUpdateStatus = onUpdateTaskStatus,
                onTaskClick = onTaskClick
            )
        }
    }
}

@Composable
private fun ProjectKanbanBoard(
    tasks: List<TaskEntity>,
    onUpdateStatus: (Long, TaskStatus) -> Unit,
    onTaskClick: (TaskEntity) -> Unit
) {
    val todoTasks = tasks.filter { it.status == TaskStatus.PENDING }
    val inProgressTasks = tasks.filter { it.status == TaskStatus.IN_PROGRESS }
    val completedTasks = tasks.filter { it.status == TaskStatus.COMPLETED }

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        KanbanColumn(
            title = "قيد الانتظار",
            tasks = todoTasks,
            status = TaskStatus.PENDING,
            modifier = Modifier.weight(1f),
            onTaskClick = onTaskClick,
            onMoveTask = onUpdateStatus
        )
        KanbanColumn(
            title = "قيد التنفيذ",
            tasks = inProgressTasks,
            status = TaskStatus.IN_PROGRESS,
            modifier = Modifier.weight(1f),
            onTaskClick = onTaskClick,
            onMoveTask = onUpdateStatus
        )
        KanbanColumn(
            title = "مكتملة",
            tasks = completedTasks,
            status = TaskStatus.COMPLETED,
            modifier = Modifier.weight(1f),
            onTaskClick = onTaskClick,
            onMoveTask = onUpdateStatus
        )
    }
}

@Composable
private fun KanbanColumn(
    title: String,
    tasks: List<TaskEntity>,
    status: TaskStatus,
    modifier: Modifier = Modifier,
    onTaskClick: (TaskEntity) -> Unit,
    onMoveTask: (Long, TaskStatus) -> Unit
) {
    Card(
        modifier = modifier.fillMaxHeight(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Badge { Text("${tasks.size}") }
            }
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(tasks, key = { it.id }) { task ->
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onTaskClick(task) }
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = task.title,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                if (status != TaskStatus.PENDING) {
                                    IconButton(
                                        onClick = { onMoveTask(task.id, TaskStatus.PENDING) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.ArrowBack, contentDescription = "نقل للانتظار", modifier = Modifier.size(14.dp))
                                    }
                                }
                                if (status != TaskStatus.IN_PROGRESS) {
                                    IconButton(
                                        onClick = { onMoveTask(task.id, TaskStatus.IN_PROGRESS) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "قيد التنفيذ", modifier = Modifier.size(14.dp))
                                    }
                                }
                                if (status != TaskStatus.COMPLETED) {
                                    IconButton(
                                        onClick = { onMoveTask(task.id, TaskStatus.COMPLETED) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = "إكمال", modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectTimelineView(
    tasks: List<TaskEntity>,
    onTaskClick: (TaskEntity) -> Unit,
    onToggleTask: (Long) -> Unit
) {
    val sortedTasks = tasks.sortedBy { it.dueDate ?: Long.MAX_VALUE }
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(sortedTasks, key = { it.id }) { task ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onTaskClick(task) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = task.status == TaskStatus.COMPLETED,
                        onCheckedChange = { onToggleTask(task.id) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            textDecoration = if (task.status == TaskStatus.COMPLETED) TextDecoration.LineThrough else TextDecoration.None
                        )
                        Text(
                            text = task.dueDate?.let { "تاريخ الاستحقاق: ${dateFormat.format(Date(it))}" } ?: "بدون تاريخ استحقاق",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    task.durationMinutes?.let { mins ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                "$mins دقيقة",
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// TIME VARIANCE & ANALYTICS HUB (P2-T13)
// -----------------------------------------------------------------------------

@Composable
fun TimeVarianceAndAnalyticsHub(
    timeEntries: List<TimeEntryEntity>,
    allTasks: List<TaskEntity>,
    projects: List<ProjectEntity>,
    runningEntry: TimeEntryEntity?,
    onStopTimer: () -> Unit,
    onOpenManualTime: () -> Unit,
    onTaskClick: (TaskEntity) -> Unit
) {
    val totalSeconds = timeEntries.sumOf { it.durationSeconds }
    val totalHours = totalSeconds / 3600.0
    val totalEstimatedHours = allTasks.filter { it.durationMinutes != null }.sumOf { (it.durationMinutes ?: 0) } / 60.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "تحليلات الوقت وتباين الإنجاز",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        // Running Timer Alert Card
        runningEntry?.let { running ->
            val task = allTasks.find { it.id == running.taskId }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("مؤقت قيد التشغيل حالياً", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(task?.title ?: "مهمة غير معروفة", fontSize = 13.sp)
                    }
                    Button(
                        onClick = onStopTimer,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("إيقاف وحفظ")
                    }
                }
            }
        }

        // Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("الوقت الفعلي المسجل", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(String.format(Locale.US, "%.1f ساعة", totalHours), fontWeight = FontWeight.Black, fontSize = 20.sp)
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("الوقت المخطط (التقديري)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(String.format(Locale.US, "%.1f ساعة", totalEstimatedHours), fontWeight = FontWeight.Black, fontSize = 20.sp)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("سجل جلسات العمل (${timeEntries.size})", fontWeight = FontWeight.Bold)
            FilledTonalButton(onClick = onOpenManualTime) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تسجيل يدوي")
            }
        }

        if (timeEntries.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لم يتم تسجيل أي وقت عمل بعد", color = MaterialTheme.colorScheme.outline)
            }
        } else {
            val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(timeEntries, key = { it.id }) { entry ->
                    val task = allTasks.find { it.id == entry.taskId }
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(task?.title ?: "مهمة #${entry.taskId}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(dateFormat.format(Date(entry.startTime)), fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                entry.notes?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            }
                            Text(
                                "${entry.durationSeconds / 60} دقيقة",
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// DAILY FOCUS SECTION (P2-T02)
// -----------------------------------------------------------------------------

@Composable
fun DailyFocusSection(
    tasks: List<TaskEntity>,
    onToggleTask: (Long) -> Unit,
    onPostponeToTomorrow: (TaskEntity) -> Unit,
    onMoveToEvening: (TaskEntity) -> Unit,
    onTaskClick: (TaskEntity) -> Unit
) {
    val topFocusTasks = tasks.filter { it.status != TaskStatus.COMPLETED }.take(3)
    if (topFocusTasks.isEmpty()) return

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Stars,
                        contentDescription = "التركيز اليومي",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "محور التركيز اليومي (أهم 3 مهام)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            topFocusTasks.forEach { task ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onTaskClick(task) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Checkbox(
                                checked = task.status == TaskStatus.COMPLETED,
                                onCheckedChange = { onToggleTask(task.id) }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = task.title,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row {
                            TextButton(
                                onClick = { onPostponeToTomorrow(task) },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("غداً", fontSize = 11.sp)
                            }
                            TextButton(
                                onClick = { onMoveToEvening(task) },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("مساءً", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// ADD TEMPLATE TASK DIALOG
// -----------------------------------------------------------------------------

@Composable
fun AddTemplateTaskDialog(
    templates: List<TaskTemplateEntity>,
    onDismiss: () -> Unit,
    onFetchFields: suspend (Long) -> List<TemplateFieldEntity>,
    onCreate: (title: String, templateId: Long, customValues: Map<Long, String>) -> Unit
) {
    var selectedTemplate by remember { mutableStateOf<TaskTemplateEntity?>(templates.firstOrNull()) }
    var taskTitle by remember { mutableStateOf("") }
    var fields by remember { mutableStateOf<List<TemplateFieldEntity>>(emptyList()) }
    val customValues = remember { mutableStateMapOf<Long, String>() }

    LaunchedEffect(selectedTemplate) {
        selectedTemplate?.let { tmpl ->
            fields = onFetchFields(tmpl.id)
            customValues.clear()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "إنشاء مهمة من قالب مخصص",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                if (templates.isEmpty()) {
                    Text("لا توجد قوالب مهام مهيأة في النظام", color = MaterialTheme.colorScheme.outline)
                } else {
                    Text("اختر القالب:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(templates) { tmpl ->
                            FilterChip(
                                selected = selectedTemplate?.id == tmpl.id,
                                onClick = { selectedTemplate = tmpl },
                                label = { Text(tmpl.name) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = taskTitle,
                        onValueChange = { taskTitle = it },
                        label = { Text("عنوان المهمة") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    if (fields.isNotEmpty()) {
                        Text("الحقول المخصصة:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        fields.forEach { field ->
                            OutlinedTextField(
                                value = customValues[field.id] ?: "",
                                onValueChange = { customValues[field.id] = it },
                                label = { Text("${field.fieldName}${if (field.isRequired) " *" else ""}") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("إلغاء") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            selectedTemplate?.let { tmpl ->
                                if (taskTitle.isNotBlank()) {
                                    onCreate(taskTitle.trim(), tmpl.id, customValues.toMap())
                                }
                            }
                        },
                        enabled = taskTitle.isNotBlank() && selectedTemplate != null
                    ) {
                        Text("إنشاء المهمة")
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// SUBTASKS TREE SECTION (P2-T07)
// -----------------------------------------------------------------------------

@Composable
fun SubtasksTreeSection(
    parentTaskId: Long,
    allTasks: List<TaskEntity>,
    onToggleTask: (Long) -> Unit,
    onDeleteTask: (Long) -> Unit,
    onAddSubtask: (Long, String) -> Unit
) {
    val childTasks = allTasks.filter { it.parentTaskId == parentTaskId }
    var newSubtaskTitle by remember { mutableStateOf("") }
    val completedCount = childTasks.count { it.status == TaskStatus.COMPLETED }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "المهام الفرعية والشجرة (${completedCount}/${childTasks.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            if (childTasks.isNotEmpty()) {
                LinearProgressIndicator(
                    progress = { if (childTasks.isNotEmpty()) completedCount.toFloat() / childTasks.size else 0f },
                    modifier = Modifier
                        .width(100.dp)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }
        }

        childTasks.forEach { subtask ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Checkbox(
                        checked = subtask.status == TaskStatus.COMPLETED,
                        onCheckedChange = { onToggleTask(subtask.id) },
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = subtask.title,
                        fontSize = 12.sp,
                        textDecoration = if (subtask.status == TaskStatus.COMPLETED) TextDecoration.LineThrough else TextDecoration.None
                    )
                }
                IconButton(onClick = { onDeleteTask(subtask.id) }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "حذف المهمة الفرعية", modifier = Modifier.size(14.dp))
                }
            }
        }

        // Quick inline add
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newSubtaskTitle,
                onValueChange = { newSubtaskTitle = it },
                placeholder = { Text("أضف مهمة فرعية جديدة...", fontSize = 11.sp) },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
                onClick = {
                    if (newSubtaskTitle.isNotBlank()) {
                        onAddSubtask(parentTaskId, newSubtaskTitle.trim())
                        newSubtaskTitle = ""
                    }
                },
                enabled = newSubtaskTitle.isNotBlank()
            ) {
                Icon(Icons.Default.AddCircle, contentDescription = "إضافة", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
