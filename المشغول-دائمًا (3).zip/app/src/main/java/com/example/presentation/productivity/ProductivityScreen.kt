package com.example.presentation.productivity

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.local.entities.*
import com.example.domain.models.*
import com.example.presentation.components.AddTaskDialog
import com.example.presentation.dashboard.DashboardUiState
import com.example.presentation.dashboard.DashboardViewModel
import com.example.presentation.notes.NotesHubView
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class ProductivityHubTab(val titleArabic: String) {
    HORIZONS("الآفاق والتركيز"),
    EISENHOWER("مصفوفة أيزنهاور"),
    PROJECTS("المشاريع وكانبان"),
    NOTES("الملاحظات المعرفية"),
    TIME_TRACKING("الوقت والتحليلات"),
    RECURRING("المهام المتكررة")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductivityScreen(
    viewModel: DashboardViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    ProductivityScreenContent(viewModel = viewModel, uiState = uiState)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductivityScreenContent(
    viewModel: DashboardViewModel,
    uiState: DashboardUiState
) {
    var activeTab by remember { mutableStateOf(ProductivityHubTab.HORIZONS) }
    var selectedHorizon by remember { mutableStateOf(TimeHorizon.DAILY) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedProjectFilter by remember { mutableStateOf<Long?>(null) }
    var selectedStatusFilter by remember { mutableStateOf<TaskStatus?>(null) }
    var selectedContextTag by remember { mutableStateOf<String?>(null) }
    var selectedProjectForKanban by remember { mutableStateOf<ProjectEntity?>(null) }

    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showDetailedTaskSheet by remember { mutableStateOf(false) }
    var showAddTemplateDialog by remember { mutableStateOf(false) }
    var showAddProjectDialog by remember { mutableStateOf(false) }
    var showManualTimeDialog by remember { mutableStateOf(false) }
    var selectedTaskForTimeLog by remember { mutableStateOf<TaskEntity?>(null) }

    var selectedTaskForDetail by remember { mutableStateOf<TaskEntity?>(null) }
    var detailTemplate by remember { mutableStateOf<TaskTemplateEntity?>(null) }
    var detailFields by remember { mutableStateOf<List<TemplateFieldEntity>>(emptyList()) }
    var detailCustomValues by remember { mutableStateOf<List<TaskCustomValueEntity>>(emptyList()) }

    val coroutineScope = rememberCoroutineScope()

    // Base filtered tasks
    val filteredTasks = remember(uiState.allTasks, selectedHorizon, selectedProjectFilter, searchQuery, selectedStatusFilter, selectedContextTag) {
        uiState.allTasks.filter { task ->
            val matchesHorizon = task.timeHorizon == selectedHorizon
            val matchesProject = selectedProjectFilter == null || task.projectId == selectedProjectFilter
            val matchesQuery = searchQuery.isBlank() || task.title.contains(searchQuery, ignoreCase = true)
            val matchesStatus = selectedStatusFilter == null || task.status == selectedStatusFilter
            val matchesTag = selectedContextTag == null || (task.tags != null && task.tags.contains(selectedContextTag!!, ignoreCase = true))
            matchesHorizon && matchesProject && matchesQuery && matchesStatus && matchesTag
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("مركز المهام والخطط (Tasks Hub)", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    uiState.runningTimeEntry?.let { running ->
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .clickable { viewModel.stopRunningTimer() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                Text("إيقاف المؤقت", fontSize = 11.sp, color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Extended FAB: Detailed Task Sheet
                ExtendedFloatingActionButton(
                    onClick = { showDetailedTaskSheet = true },
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                    contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                    icon = { Icon(Icons.Default.Tune, contentDescription = null) },
                    text = { Text("مهمة متكاملة", fontSize = 12.sp) }
                )

                // Secondary FAB: Add template task
                ExtendedFloatingActionButton(
                    onClick = { showAddTemplateDialog = true },
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    icon = { Icon(Icons.Default.Spa, contentDescription = null) },
                    text = { Text("مهمة بقالب", fontSize = 12.sp) }
                )

                // Primary FAB: Quick task
                FloatingActionButton(
                    onClick = { showAddTaskDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = CircleShape
                ) {
                    Icon(Icons.Default.Add, contentDescription = "مهمة سريعة")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Main Top Tabs
            ScrollableTabRow(
                selectedTabIndex = activeTab.ordinal,
                modifier = Modifier.fillMaxWidth(),
                edgePadding = 0.dp
            ) {
                ProductivityHubTab.values().forEach { tab ->
                    Tab(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        text = {
                            Text(
                                text = tab.titleArabic,
                                fontWeight = if (activeTab == tab) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                        }
                    )
                }
            }

            when (activeTab) {
                ProductivityHubTab.HORIZONS -> {
                    // Time Horizons & Daily Focus Hub
                    HorizonsView(
                        tasks = filteredTasks,
                        selectedHorizon = selectedHorizon,
                        onHorizonSelected = { selectedHorizon = it },
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        projects = uiState.projects,
                        selectedProjectId = selectedProjectFilter,
                        onSelectProject = { selectedProjectFilter = it },
                        selectedStatus = selectedStatusFilter,
                        onSelectStatus = { selectedStatusFilter = it },
                        selectedTag = selectedContextTag,
                        onSelectTag = { selectedContextTag = it },
                        runningTimerId = uiState.runningTimeEntry?.taskId,
                        onToggleTask = { viewModel.toggleTaskComplete(it) },
                        onStartTimer = { viewModel.startTimerForTask(it) },
                        onLogTime = {
                            val task = uiState.allTasks.find { t -> t.id == it }
                            selectedTaskForTimeLog = task
                            showManualTimeDialog = true
                        },
                        onExportCalendar = { task -> viewModel.exportTaskToDeviceCalendar(task) },
                        onPostponeToTomorrow = { viewModel.postponeTaskToTomorrow(it) },
                        onMoveToEvening = { viewModel.moveTaskToEvening(it) },
                        onTaskClick = { task ->
                            selectedTaskForDetail = task
                            coroutineScope.launch {
                                val tmplId = task.templateId
                                if (tmplId != null) {
                                    detailTemplate = viewModel.getTemplateById(tmplId)
                                    detailFields = viewModel.getFieldsForTemplate(tmplId)
                                    detailCustomValues = viewModel.getCustomValuesForTask(task.id)
                                } else {
                                    detailTemplate = null
                                    detailFields = emptyList()
                                    detailCustomValues = emptyList()
                                }
                            }
                        },
                        onOpenAddTask = { showAddTaskDialog = true },
                        onOpenAddTemplate = { showAddTemplateDialog = true }
                    )
                }

                ProductivityHubTab.EISENHOWER -> {
                    EisenhowerMatrixView(
                        tasks = uiState.allTasks,
                        onToggleTask = { viewModel.toggleTaskComplete(it) },
                        onUpdatePriority = { taskId, newP -> viewModel.updateTaskPriority(taskId, newP) },
                        onTaskClick = { task -> selectedTaskForDetail = task }
                    )
                }

                ProductivityHubTab.PROJECTS -> {
                    if (selectedProjectForKanban != null) {
                        ProjectKanbanAndTimelineHub(
                            project = selectedProjectForKanban!!,
                            projectTasks = uiState.allTasks.filter { it.projectId == selectedProjectForKanban!!.id },
                            onBack = { selectedProjectForKanban = null },
                            onUpdateTaskStatus = { taskId, newStatus -> viewModel.updateTaskStatus(taskId, newStatus) },
                            onToggleTask = { viewModel.toggleTaskComplete(it) },
                            onTaskClick = { task -> selectedTaskForDetail = task },
                            onArchiveProject = {
                                viewModel.archiveProject(selectedProjectForKanban!!.id)
                                selectedProjectForKanban = null
                            }
                        )
                    } else {
                        ProjectsView(
                            projects = uiState.projects,
                            allTasks = uiState.allTasks,
                            onCreateProject = { showAddProjectDialog = true },
                            onSelectProject = { projId ->
                                selectedProjectForKanban = uiState.projects.find { it.id == projId }
                            }
                        )
                    }
                }

                ProductivityHubTab.NOTES -> {
                    NotesHubView(
                        notes = uiState.notes,
                        projects = uiState.projects,
                        tasks = uiState.allTasks,
                        onSaveNote = { title, content, tags, projId, taskId, debtId ->
                            viewModel.saveNote(title, content, tags, projId, taskId, debtId)
                        },
                        onTogglePin = { viewModel.togglePinNote(it) },
                        onArchiveNote = { viewModel.archiveNote(it) },
                        onDeleteNote = { viewModel.deleteNote(it) }
                    )
                }

                ProductivityHubTab.TIME_TRACKING -> {
                    TimeVarianceAndAnalyticsHub(
                        timeEntries = uiState.timeEntries,
                        allTasks = uiState.allTasks,
                        projects = uiState.projects,
                        runningEntry = uiState.runningTimeEntry,
                        onStopTimer = { viewModel.stopRunningTimer() },
                        onOpenManualTime = {
                            selectedTaskForTimeLog = uiState.allTasks.firstOrNull()
                            showManualTimeDialog = true
                        },
                        onTaskClick = { task -> selectedTaskForDetail = task }
                    )
                }

                ProductivityHubTab.RECURRING -> {
                    RecurringTasksView(
                        allTasks = uiState.allTasks,
                        onToggleTask = { viewModel.toggleTaskComplete(it) },
                        onOpenAddTask = { showDetailedTaskSheet = true }
                    )
                }
            }
        }
    }

    // Comprehensive Detailed Task Sheet
    if (showDetailedTaskSheet) {
        TaskCreateEditSheet(
            initialTask = null,
            projects = uiState.projects,
            onDismiss = { showDetailedTaskSheet = false },
            onSave = { title, description, priority, horizon, dueDate, dueTime, duration, tags, projectId, parentTaskId, isRecurring, recurrenceRule, imageUri, reminderTime, isReminderEnabled ->
                viewModel.createTask(
                    title = title,
                    description = description,
                    priority = priority,
                    timeHorizon = horizon,
                    dueDate = dueDate,
                    dueTimeMinutes = dueTime,
                    durationMinutes = duration,
                    tags = tags,
                    projectId = projectId,
                    parentTaskId = parentTaskId,
                    isRecurring = isRecurring,
                    recurrenceRule = recurrenceRule,
                    imageUri = imageUri,
                    reminderTime = reminderTime,
                    isReminderEnabled = isReminderEnabled
                )
                showDetailedTaskSheet = false
            }
        )
    }

    // Quick Task Dialog (Fixed Fields with recurrence and horizon)
    if (showAddTaskDialog) {
        AddTaskDialog(
            projects = uiState.projects,
            onDismiss = { showAddTaskDialog = false },
            onConfirm = { title, priority, duration, projId, horizon, isRecurring, recurrenceRule ->
                viewModel.quickCreateTask(
                    title = title,
                    priority = priority,
                    timeHorizon = horizon,
                    durationMinutes = duration,
                    projectId = projId,
                    isRecurring = isRecurring,
                    recurrenceRule = recurrenceRule
                )
            }
        )
    }

    // Add Template Task Dialog (Dynamic Fields)
    if (showAddTemplateDialog) {
        AddTemplateTaskDialog(
            templates = uiState.templates,
            onDismiss = { showAddTemplateDialog = false },
            onFetchFields = { tmplId ->
                viewModel.getFieldsForTemplate(tmplId)
            },
            onCreate = { title, tmplId, customValues ->
                viewModel.createTaskFromTemplate(title, tmplId, customValues)
                showAddTemplateDialog = false
            }
        )
    }

    // Create Project Dialog
    if (showAddProjectDialog) {
        AddProjectDialog(
            onDismiss = { showAddProjectDialog = false },
            onConfirm = { name, desc, colorHex, icon ->
                viewModel.createProject(name, desc, colorHex, icon)
                showAddProjectDialog = false
            }
        )
    }

    // Manual Time Log Dialog
    if (showManualTimeDialog && selectedTaskForTimeLog != null) {
        ManualTimeLogDialog(
            task = selectedTaskForTimeLog!!,
            onDismiss = { showManualTimeDialog = false },
            onConfirm = { minutes, notes ->
                viewModel.logManualTime(selectedTaskForTimeLog!!.id, minutes, notes)
                showManualTimeDialog = false
            }
        )
    }

    // Task Detail Dialog
    selectedTaskForDetail?.let { task ->
        TaskDetailDialog(
            task = task,
            template = detailTemplate,
            templateFields = detailFields,
            customValues = detailCustomValues,
            allTasks = uiState.allTasks,
            onAddSubtask = { parentId, title -> viewModel.addSubtask(parentId, title) },
            onToggleTask = { viewModel.toggleTaskComplete(it) },
            onDeleteTask = { viewModel.deleteTask(it) },
            onDismiss = { selectedTaskForDetail = null },
            onToggleStatus = {
                viewModel.toggleTaskComplete(task.id)
                selectedTaskForDetail = null
            },
            onDelete = {
                viewModel.deleteTask(task.id)
                selectedTaskForDetail = null
            }
        )
    }
}

@Composable
private fun HorizonsView(
    tasks: List<TaskEntity>,
    selectedHorizon: TimeHorizon,
    onHorizonSelected: (TimeHorizon) -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    projects: List<ProjectEntity>,
    selectedProjectId: Long?,
    onSelectProject: (Long?) -> Unit,
    selectedStatus: TaskStatus?,
    onSelectStatus: (TaskStatus?) -> Unit,
    selectedTag: String?,
    onSelectTag: (String?) -> Unit,
    runningTimerId: Long?,
    onToggleTask: (Long) -> Unit,
    onStartTimer: (Long) -> Unit,
    onLogTime: (Long) -> Unit,
    onExportCalendar: (TaskEntity) -> Unit,
    onPostponeToTomorrow: (TaskEntity) -> Unit,
    onMoveToEvening: (TaskEntity) -> Unit,
    onTaskClick: (TaskEntity) -> Unit,
    onOpenAddTask: () -> Unit,
    onOpenAddTemplate: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Horizon filter chips
        ScrollableTabRow(
            selectedTabIndex = selectedHorizon.ordinal,
            edgePadding = 0.dp,
            divider = {}
        ) {
            TimeHorizon.values().forEach { horizon ->
                Tab(
                    selected = selectedHorizon == horizon,
                    onClick = { onHorizonSelected(horizon) },
                    text = {
                        Text(
                            text = horizon.labelArabic,
                            fontWeight = if (selectedHorizon == horizon) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        // Search & Project Filter Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("بحث في المهام والوسوم...", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح", modifier = Modifier.size(16.dp))
                        }
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            if (selectedProjectId != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.clickable { onSelectProject(null) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("إلغاء المشروع", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        // Status Lifecycle Filter Chips (P2-T07)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedStatus == null,
                onClick = { onSelectStatus(null) },
                label = { Text("كافة الحالات", fontSize = 10.sp) }
            )
            TaskStatus.values().forEach { st ->
                FilterChip(
                    selected = selectedStatus == st,
                    onClick = { onSelectStatus(if (selectedStatus == st) null else st) },
                    label = { Text(st.labelArabic, fontSize = 10.sp) }
                )
            }
        }

        // Context Tags Filter Chips (P2-T06)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("@عمل", "@منزل", "@دراسة", "@كمبيوتر", "@مكالمات").forEach { tag ->
                FilterChip(
                    selected = selectedTag == tag,
                    onClick = { onSelectTag(if (selectedTag == tag) null else tag) },
                    label = { Text(tag, fontSize = 10.sp) }
                )
            }
        }

        // Summary Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "مهام ${selectedHorizon.labelArabic}: ${tasks.size}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "المنجز: ${tasks.count { it.status == TaskStatus.COMPLETED }}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Daily Focus Split (Morning / Evening / Quick Reschedule) (P2-T02)
        if (selectedHorizon == TimeHorizon.DAILY && tasks.isNotEmpty()) {
            DailyFocusSection(
                tasks = tasks,
                onToggleTask = onToggleTask,
                onPostponeToTomorrow = onPostponeToTomorrow,
                onMoveToEvening = onMoveToEvening,
                onTaskClick = onTaskClick
            )
        }

        // Tasks List
        if (tasks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AssignmentTurnedIn,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Text(
                        text = "لا توجد مهام مطابقة",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onOpenAddTask) {
                            Text("إضافة مهمة سريعة")
                        }
                        OutlinedButton(onClick = onOpenAddTemplate) {
                            Text("تصميم مهمة")
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(tasks, key = { it.id }) { task ->
                    val isTimerRunning = runningTimerId == task.id
                    ProductivityHubTaskCard(
                        task = task,
                        isTimerRunning = isTimerRunning,
                        onToggle = { onToggleTask(task.id) },
                        onStartTimer = { onStartTimer(task.id) },
                        onLogTime = { onLogTime(task.id) },
                        onExportCalendar = { onExportCalendar(task) },
                        onClick = { onTaskClick(task) }
                    )
                }
            }
        }
    }
}

@Composable
fun ProductivityHubTaskCard(
    task: TaskEntity,
    isTimerRunning: Boolean,
    onToggle: () -> Unit,
    onStartTimer: () -> Unit,
    onLogTime: () -> Unit,
    onExportCalendar: () -> Unit,
    onClick: () -> Unit
) {
    val isCompleted = task.status == TaskStatus.COMPLETED

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isCompleted) 0.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(onClick = onToggle, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = if (isCompleted) FontWeight.Normal else FontWeight.SemiBold,
                            textDecoration = if (isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                            modifier = Modifier.weight(1f)
                        )

                        // Task Thumbnail or Cover Icon if present
                        if (!task.imageUri.isNullOrBlank()) {
                            if (task.imageUri.startsWith("preset:")) {
                                val presetId = task.imageUri.removePrefix("preset:")
                                val iconStr = when (presetId) {
                                    "work" -> "💼"
                                    "agri" -> "🌾"
                                    "code" -> "💻"
                                    "study" -> "📚"
                                    "finance" -> "💰"
                                    "home" -> "🏠"
                                    "health" -> "🏋️"
                                    "travel" -> "✈️"
                                    else -> "📌"
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(iconStr, fontSize = 14.sp)
                                    }
                                }
                            } else {
                                AsyncImage(
                                    model = task.imageUri,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp)),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Alarm / Reminder Badge
                        if (task.isReminderEnabled) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(10.dp), tint = MaterialTheme.colorScheme.error)
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("منبه", fontSize = 10.sp, color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        // Dynamic Template Badge
                        if (task.templateId != null) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Spa, contentDescription = null, modifier = Modifier.size(10.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("قالب", fontSize = 10.sp, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Recurring Badge
                        if (task.isRecurring) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.tertiaryContainer
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Repeat, contentDescription = null, modifier = Modifier.size(10.dp), tint = MaterialTheme.colorScheme.onTertiaryContainer)
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(task.recurrenceRule ?: "متكرر", fontSize = 9.sp, color = MaterialTheme.colorScheme.onTertiaryContainer, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Priority Badge
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = when (task.priority) {
                                TaskPriority.URGENT_IMPORTANT -> Color(0xFFFFEBEE)
                                TaskPriority.IMPORTANT_NOT_URGENT -> Color(0xFFE8F5E9)
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        ) {
                            Text(
                                text = task.priority.labelArabic,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                color = when (task.priority) {
                                    TaskPriority.URGENT_IMPORTANT -> Color(0xFFC62828)
                                    TaskPriority.IMPORTANT_NOT_URGENT -> Color(0xFF2E7D32)
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }

                        task.durationMinutes?.let {
                            Text("⏱️ $it دقيقة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Action Menu Icons: Start Timer, Log Time, Export to Calendar
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(
                        onClick = onStartTimer,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isTimerRunning) Icons.Default.HourglassBottom else Icons.Default.PlayArrow,
                            contentDescription = "بدء المؤقت",
                            tint = if (isTimerRunning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onLogTime,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.AddAlarm, contentDescription = "تسجيل وقت يدوي", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(16.dp))
                    }

                    IconButton(
                        onClick = onExportCalendar,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = "تصدير للتقويم", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectsView(
    projects: List<ProjectEntity>,
    allTasks: List<TaskEntity>,
    onCreateProject: () -> Unit,
    onSelectProject: (Long) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("المشاريع والتصنيفات الاستراتيجية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Button(onClick = onCreateProject) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("مشروع جديد")
            }
        }

        if (projects.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(54.dp), tint = MaterialTheme.colorScheme.outline)
                    Text("لا توجد مشاريع مضافة حتى الآن", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onCreateProject) {
                        Text("إنشاء أول مشروع")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(projects, key = { it.id }) { project ->
                    val projectTasks = allTasks.filter { it.projectId == project.id }
                    val completed = projectTasks.count { it.status == TaskStatus.COMPLETED }
                    val progress = if (projectTasks.isNotEmpty()) completed.toFloat() / projectTasks.size.toFloat() else 0f

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectProject(project.id) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                    Text(project.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                Text("${(progress * 100).toInt()}%", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }

                            if (!project.description.isNullOrBlank()) {
                                Text(project.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp))
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("إجمالي المهام: ${projectTasks.size}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("المنجز: $completed", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeTrackingView(
    timeEntries: List<TimeEntryEntity>,
    allTasks: List<TaskEntity>,
    runningEntry: TimeEntryEntity?,
    onStopTimer: () -> Unit,
    onOpenManualTime: () -> Unit
) {
    val totalSeconds = remember(timeEntries) {
        timeEntries.sumOf { it.durationSeconds ?: 0L }
    }
    val totalHours = totalSeconds / 3600
    val totalMinutes = (totalSeconds % 3600) / 60

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Time Summary Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("إجمالي وقت العمل والتركيز المسجل", fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(
                    text = "$totalHours ساعة و $totalMinutes دقيقة",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text("عدد جلسات العمل: ${timeEntries.size}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
            }
        }

        // Running timer banner if any
        runningEntry?.let { running ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.HourglassTop, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Text("مؤقت العمل قيد التشغيل حالياً...", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                    Button(
                        onClick = onStopTimer,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("إيقاف وحفظ")
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("سجل جلسات العمل المنفذة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = onOpenManualTime) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تسجيل يدوي")
            }
        }

        if (timeEntries.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد جلسات عمل مسجلة حتى الآن", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(timeEntries, key = { it.id }) { entry ->
                    val task = allTasks.find { it.id == entry.taskId }
                    val mins = (entry.durationSeconds ?: 0L) / 60

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(task?.title ?: "مهمة رقم #${entry.taskId}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(dateFormat.format(Date(entry.startTime)), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (!entry.notes.isNullOrBlank()) {
                                    Text(entry.notes, fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                }
                            }
                            Text("⏱️ $mins دقيقة", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecurringTasksView(
    allTasks: List<TaskEntity>,
    onToggleTask: (Long) -> Unit,
    onOpenAddTask: () -> Unit
) {
    val recurringTasks = remember(allTasks) {
        allTasks.filter { it.isRecurring }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("المهام المتكررة تلقائياً (Recurring Rules)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Button(onClick = onOpenAddTask) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("إضافة مهمة دورية")
            }
        }

        if (recurringTasks.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                    Text("لا توجد مهام دورية متكررة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onOpenAddTask) {
                        Text("إضافة مهمة متكررة الآن")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(recurringTasks, key = { it.id }) { task ->
                    val isCompleted = task.status == TaskStatus.COMPLETED
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            IconButton(onClick = { onToggleTask(task.id) }) {
                                Icon(
                                    if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    task.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    textDecoration = if (isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "التكرار: ${when(task.recurrenceRule) { "DAILY" -> "يومياً"; "WEEKLY" -> "أسبوعياً"; "MONTHLY" -> "شهرياً"; else -> task.recurrenceRule ?: "تلقائي" }}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = task.timeHorizon.labelArabic,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddProjectDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, desc: String?, colorHex: String, icon: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("إنشاء مشروع استراتيجي جديد", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المشروع") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("وصف المشروع والهدف العام") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    maxLines = 3
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("إلغاء") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                onConfirm(name.trim(), desc.ifBlank { null }, "#2E7D32", "folder")
                            }
                        },
                        enabled = name.isNotBlank()
                    ) {
                        Text("إنشاء")
                    }
                }
            }
        }
    }
}

@Composable
fun ManualTimeLogDialog(
    task: TaskEntity,
    onDismiss: () -> Unit,
    onConfirm: (minutes: Int, notes: String?) -> Unit
) {
    var minutesText by remember { mutableStateOf("30") }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تسجيل وقت عمل يدوي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("المهمة: ${task.title}", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)

                OutlinedTextField(
                    value = minutesText,
                    onValueChange = { minutesText = it.filter { c -> c.isDigit() } },
                    label = { Text("المدة بالدقائق") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات إنجاز الجلسة") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("إلغاء") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val mins = minutesText.toIntOrNull() ?: 0
                            if (mins > 0) {
                                onConfirm(mins, notes.ifBlank { null })
                            }
                        },
                        enabled = (minutesText.toIntOrNull() ?: 0) > 0
                    ) {
                        Text("تسجيل")
                    }
                }
            }
        }
    }
}
