package com.example.presentation.productivity

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.local.entities.TaskCustomValueEntity
import com.example.data.local.entities.TaskEntity
import com.example.data.local.entities.TaskTemplateEntity
import com.example.data.local.entities.TemplateFieldEntity
import com.example.domain.models.TaskPriority
import com.example.domain.models.TaskStatus
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TaskDetailDialog(
    task: TaskEntity,
    template: TaskTemplateEntity? = null,
    templateFields: List<TemplateFieldEntity> = emptyList(),
    customValues: List<TaskCustomValueEntity> = emptyList(),
    allTasks: List<TaskEntity> = emptyList(),
    onAddSubtask: ((Long, String) -> Unit)? = null,
    onToggleTask: ((Long) -> Unit)? = null,
    onDeleteTask: ((Long) -> Unit)? = null,
    onDismiss: () -> Unit,
    onToggleStatus: () -> Unit,
    onDelete: () -> Unit
) {
    val isCompleted = task.status == TaskStatus.COMPLETED
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Task Cover / Image Banner if present
                if (!task.imageUri.isNullOrBlank()) {
                    if (task.imageUri.startsWith("preset:")) {
                        val presetId = task.imageUri.removePrefix("preset:")
                        val preset = TASK_COVER_PRESETS.find { it.id == presetId } ?: TASK_COVER_PRESETS.first()
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(android.graphics.Color.parseColor(preset.colorHex)).copy(alpha = 0.85f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(preset.icon, fontSize = 38.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(preset.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    } else {
                        AsyncImage(
                            model = task.imageUri,
                            contentDescription = "صورة المهمة",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }
                }

                // Header: Title and Type Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        if (task.templateId != null) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Spa,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "قالب مخصص: ${template?.name ?: "قالب ديناميكي"}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "مهمة قياسية (حقول ثابتة)",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // DUAL LOGIC DISPLAY: Custom Fields vs Fixed Fields
                if (task.templateId != null) {
                    // --- DYNAMIC CUSTOM FIELDS SECTION ---
                    Text(
                        text = "الحقول والمعايير المخصصة للقالب",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (customValues.isEmpty() && templateFields.isEmpty()) {
                        Text(
                            text = "لا توجد قيم مخصصة مسجلة لهذه المهمة بعد.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        val fieldMap = remember(templateFields) { templateFields.associateBy { it.id } }
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            customValues.forEach { customVal ->
                                val fieldDef = fieldMap[customVal.fieldId]
                                val label = fieldDef?.fieldName ?: "حقل مخصص #${customVal.fieldId}"
                                val unit = fieldDef?.unit?.let { " $it" } ?: ""

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = label,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )

                                        val displayValue = when {
                                            customVal.valueNumber != null -> "${customVal.valueNumber}$unit"
                                            !customVal.valueText.isNullOrBlank() -> "${customVal.valueText}$unit"
                                            customVal.valueDate != null -> dateFormat.format(Date(customVal.valueDate))
                                            else -> "غير محدد"
                                        }

                                        Text(
                                            text = displayValue,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Optional progression info if available
                    template?.autoNextTaskRule?.let { rule ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Autorenew,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "قاعدة التوليد التلقائي القادمة نشطة: عند الإنجاز سيتم اشتقاق المهمة التالية تلقائياً.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                    }

                } else {
                    // --- STANDARD FIXED FIELDS SECTION ---
                    Text(
                        text = "تفاصيل المهمة الثابتة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        DetailItem(
                            label = "الأفق الزمني",
                            value = task.timeHorizon.labelArabic,
                            icon = Icons.Default.Schedule
                        )
                        DetailItem(
                            label = "الأولوية (مصفوفة أيزنهاور)",
                            value = task.priority.labelArabic,
                            icon = Icons.Default.Flag,
                            valueColor = when (task.priority) {
                                TaskPriority.URGENT_IMPORTANT -> MaterialTheme.colorScheme.error
                                TaskPriority.IMPORTANT_NOT_URGENT -> MaterialTheme.colorScheme.primary
                                TaskPriority.URGENT_NOT_IMPORTANT -> Color(0xFFE65100)
                                TaskPriority.NEITHER -> Color(0xFF757575)
                            }
                        )
                        task.dueDate?.let { due ->
                            DetailItem(
                                label = "تاريخ الاستحقاق",
                                value = dateFormat.format(Date(due)),
                                icon = Icons.Default.CalendarToday
                            )
                        }
                        task.durationMinutes?.let { dur ->
                            DetailItem(
                                label = "المدة التقديرية",
                                value = "$dur دقيقة",
                                icon = Icons.Default.Timer
                            )
                        }
                        if (task.isReminderEnabled || task.reminderTime != null) {
                            val reminderFormatted = if (task.reminderTime != null) {
                                SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.getDefault()).format(Date(task.reminderTime))
                            } else "مفعل عند الموعد"
                            DetailItem(
                                label = "المنبه والتذكير المجدول",
                                value = "⏰ رنين في $reminderFormatted",
                                icon = Icons.Default.Alarm,
                                valueColor = MaterialTheme.colorScheme.error
                            )
                        }
                        if (!task.description.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("الوصف والملاحظات:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(task.description, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }

                // Subtasks Recursive Tree Section
                if (onAddSubtask != null && onToggleTask != null && onDeleteTask != null) {
                    SubtasksTreeSection(
                        parentTaskId = task.id,
                        allTasks = allTasks,
                        onToggleTask = onToggleTask,
                        onDeleteTask = onDeleteTask,
                        onAddSubtask = onAddSubtask
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action Buttons: Complete / Delete
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onToggleStatus,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCompleted) Color(0xFF558B2F) else MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            if (isCompleted) Icons.Default.CheckCircle else Icons.Default.Check,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isCompleted) "مكتملة (إعادة للعمل)" else "تم الإنجاز")
                    }

                    OutlinedButton(
                        onClick = onDelete,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف")
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailItem(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = valueColor)
        }
    }
}
