package com.example.presentation.productivity

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.local.entities.ProjectEntity
import com.example.data.local.entities.TaskEntity
import com.example.domain.models.TaskPriority
import com.example.domain.models.TaskStatus
import com.example.domain.models.TimeHorizon
import java.text.SimpleDateFormat
import java.util.*

// Predefined task cover themes for instant selection
data class TaskCoverPreset(
    val id: String,
    val title: String,
    val icon: String,
    val colorHex: String
)

val TASK_COVER_PRESETS = listOf(
    TaskCoverPreset("work", "عمل", "💼", "#1976D2"),
    TaskCoverPreset("agri", "زراعة", "🌾", "#388E3C"),
    TaskCoverPreset("code", "برمجة", "💻", "#5C6BC0"),
    TaskCoverPreset("study", "دراسة", "📚", "#E65100"),
    TaskCoverPreset("finance", "مالية", "💰", "#2E7D32"),
    TaskCoverPreset("home", "منزل", "🏠", "#8D6E63"),
    TaskCoverPreset("health", "صحة", "🏋️", "#D32F2F"),
    TaskCoverPreset("travel", "سفر", "✈️", "#00838F")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskCreateEditSheet(
    initialTask: TaskEntity? = null,
    projects: List<ProjectEntity>,
    parentTasks: List<TaskEntity> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        description: String?,
        priority: TaskPriority,
        timeHorizon: TimeHorizon,
        dueDate: Long?,
        dueTimeMinutes: Int?,
        durationMinutes: Int?,
        tags: String?,
        projectId: Long?,
        parentTaskId: Long?,
        isRecurring: Boolean,
        recurrenceRule: String?,
        imageUri: String?,
        reminderTime: Long?,
        isReminderEnabled: Boolean
    ) -> Unit
) {
    var title by remember { mutableStateOf(initialTask?.title ?: "") }
    var description by remember { mutableStateOf(initialTask?.description ?: "") }
    var priority by remember { mutableStateOf(initialTask?.priority ?: TaskPriority.IMPORTANT_NOT_URGENT) }
    var timeHorizon by remember { mutableStateOf(initialTask?.timeHorizon ?: TimeHorizon.DAILY) }
    var durationText by remember { mutableStateOf((initialTask?.durationMinutes ?: 30).toString()) }
    var tags by remember { mutableStateOf(initialTask?.tags ?: "") }
    var selectedProjectId by remember { mutableStateOf(initialTask?.projectId) }
    var selectedParentTaskId by remember { mutableStateOf(initialTask?.parentTaskId) }
    var isRecurring by remember { mutableStateOf(initialTask?.isRecurring ?: false) }
    var recurrenceRule by remember { mutableStateOf(initialTask?.recurrenceRule ?: "DAILY") }
    var hasSpecificTime by remember { mutableStateOf(initialTask?.dueTimeMinutes != null) }
    var hour by remember { mutableStateOf((initialTask?.dueTimeMinutes ?: 600) / 60) }
    var minute by remember { mutableStateOf((initialTask?.dueTimeMinutes ?: 600) % 60) }

    // Image attachment state
    var imageUri by remember { mutableStateOf<String?>(initialTask?.imageUri) }
    var showUrlInputDialog by remember { mutableStateOf(false) }
    var customUrlInput by remember { mutableStateOf("") }

    // Exact Alarm & Reminder state
    var isReminderEnabled by remember { mutableStateOf(initialTask?.isReminderEnabled ?: false) }
    var reminderOffsetMinutes by remember { mutableStateOf(0) } // 0 = at time, 15 = 15m before, 30 = 30m before, 60 = 1h before

    // Photo picker launcher (Android Photo Picker)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            imageUri = uri.toString()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .padding(vertical = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (initialTask == null) "إنشاء مهمة جديدة" else "تعديل تفاصيل المهمة",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "نظام إدارة المهام والمواعيد المتكامل",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إلغاء")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // --- 1. Task Image / Cover Section ---
                Text("صورة أو غلاف المهمة:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                if (imageUri != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        if (imageUri!!.startsWith("preset:")) {
                            val presetId = imageUri!!.removePrefix("preset:")
                            val preset = TASK_COVER_PRESETS.find { it.id == presetId } ?: TASK_COVER_PRESETS.first()
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(android.graphics.Color.parseColor(preset.colorHex)).copy(alpha = 0.85f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(preset.icon, fontSize = 42.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(preset.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                            }
                        } else {
                            AsyncImage(
                                model = imageUri,
                                contentDescription = "صورة المهمة",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Remove image button
                        FilledTonalIconButton(
                            onClick = { imageUri = null },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp)
                                .size(32.dp),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                            )
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف الصورة", modifier = Modifier.size(16.dp))
                        }
                    }
                } else {
                    // Image picker action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("من المعرض", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { showUrlInputDialog = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("رابط صورة", fontSize = 12.sp)
                        }
                    }

                    // Quick Cover Presets
                    Text("أو اختر غلافاً سريعاً:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(TASK_COVER_PRESETS) { preset ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(android.graphics.Color.parseColor(preset.colorHex)).copy(alpha = 0.2f),
                                border = null,
                                modifier = Modifier
                                    .clickable { imageUri = "preset:${preset.id}" }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(preset.icon, fontSize = 16.sp)
                                    Text(preset.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }

                // --- 2. Title & Description ---
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان المهمة *") },
                    placeholder = { Text("مثال: فحص رطوبة التربة وري محصول القمح") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("التفاصيل والوصف") },
                    placeholder = { Text("الملاحظات، الخطوات، أو أي توجيهات إضافية...") },
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // --- 3. Exact Alarm / Reminder Section ---
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (isReminderEnabled) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isReminderEnabled) MaterialTheme.colorScheme.primary else Color.Transparent
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(
                                    Icons.Default.Alarm,
                                    contentDescription = null,
                                    tint = if (isReminderEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                )
                                Column {
                                    Text("تفعيل المنبه والتنبيه الدقيق", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Text("إشعار مع منبه واهتزاز في الموعد المجدول", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Switch(
                                checked = isReminderEnabled,
                                onCheckedChange = { isReminderEnabled = it }
                            )
                        }

                        if (isReminderEnabled) {
                            Text("توقيت رنين المنبه:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(
                                    0 to "في الموعد",
                                    15 to "قبل 15 دقيقة",
                                    30 to "قبل 30 دقيقة",
                                    60 to "قبل ساعة"
                                ).forEach { (offset, label) ->
                                    FilterChip(
                                        selected = reminderOffsetMinutes == offset,
                                        onClick = { reminderOffsetMinutes = offset },
                                        label = { Text(label, fontSize = 10.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                // --- 4. Eisenhower Priority ---
                Text("أولوية مصفوفة أيزنهاور:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    TaskPriority.values().forEach { p ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (priority == p) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { priority = p }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                RadioButton(selected = priority == p, onClick = { priority = p })
                                Text(p.labelArabic, fontSize = 12.sp, fontWeight = if (priority == p) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }

                // --- 5. Time Horizon ---
                Text("الأفق الزمني للتخطيط:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TimeHorizon.values().forEach { h ->
                        FilterChip(
                            selected = timeHorizon == h,
                            onClick = { timeHorizon = h },
                            label = { Text(h.labelArabic, fontSize = 10.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Estimated Duration in Minutes
                OutlinedTextField(
                    value = durationText,
                    onValueChange = { durationText = it.filter { c -> c.isDigit() } },
                    label = { Text("المدة التقديرية بالدقائق") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Context & Tags
                OutlinedTextField(
                    value = tags,
                    onValueChange = { tags = it },
                    label = { Text("السياقات والوسوم (@عمل, @منزل, @دراسة)") },
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Quick Context Chips
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("@عمل", "@منزل", "@دراسة", "@كمبيوتر", "@مكالمات").forEach { chip ->
                        SuggestionChip(
                            onClick = {
                                tags = if (tags.isBlank()) chip else "$tags, $chip"
                            },
                            label = { Text(chip, fontSize = 10.sp) }
                        )
                    }
                }

                // Project Selector
                if (projects.isNotEmpty()) {
                    Text("المشروع المرتبط:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedProjectId == null,
                            onClick = { selectedProjectId = null },
                            label = { Text("بدون مشروع", fontSize = 11.sp) }
                        )
                        projects.take(3).forEach { proj ->
                            FilterChip(
                                selected = selectedProjectId == proj.id,
                                onClick = { selectedProjectId = proj.id },
                                label = { Text(proj.name, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                // Recurrence Engine Option
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("تكرار المهمة تلقائياً", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Switch(checked = isRecurring, onCheckedChange = { isRecurring = it })
                        }

                        if (isRecurring) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf("DAILY" to "يومي", "WEEKLY" to "أسبوعي", "MONTHLY" to "شهري").forEach { (rule, label) ->
                                    FilterChip(
                                        selected = recurrenceRule == rule,
                                        onClick = { recurrenceRule = rule },
                                        label = { Text(label, fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                // Save & Cancel Buttons
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("إلغاء") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                val dueTimeMin = if (hasSpecificTime) (hour * 60 + minute) else null
                                val baseDueDate = System.currentTimeMillis()
                                val computedReminderTime = if (isReminderEnabled) {
                                    val cal = Calendar.getInstance()
                                    if (dueTimeMin != null) {
                                        cal.set(Calendar.HOUR_OF_DAY, dueTimeMin / 60)
                                        cal.set(Calendar.MINUTE, dueTimeMin % 60)
                                        cal.set(Calendar.SECOND, 0)
                                        cal.add(Calendar.MINUTE, -reminderOffsetMinutes)
                                        if (cal.timeInMillis <= System.currentTimeMillis()) {
                                            // If time already passed today, set to 1 hour from now or next day
                                            cal.add(Calendar.DAY_OF_YEAR, 1)
                                        }
                                        cal.timeInMillis
                                    } else {
                                        // Default alarm: 1 hour from now
                                        System.currentTimeMillis() + 60 * 60 * 1000
                                    }
                                } else null

                                onSave(
                                    title.trim(),
                                    description.ifBlank { null },
                                    priority,
                                    timeHorizon,
                                    baseDueDate,
                                    dueTimeMin,
                                    durationText.toIntOrNull() ?: 30,
                                    tags.ifBlank { null },
                                    selectedProjectId,
                                    selectedParentTaskId,
                                    isRecurring,
                                    if (isRecurring) recurrenceRule else null,
                                    imageUri,
                                    computedReminderTime,
                                    isReminderEnabled
                                )
                            }
                        },
                        enabled = title.isNotBlank()
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ المهمة")
                    }
                }
            }
        }
    }

    // Custom URL input dialog
    if (showUrlInputDialog) {
        AlertDialog(
            onDismissRequest = { showUrlInputDialog = false },
            title = { Text("إدخال رابط صورة مباشرة") },
            text = {
                OutlinedTextField(
                    value = customUrlInput,
                    onValueChange = { customUrlInput = it },
                    label = { Text("رابط الصورة (URL)") },
                    placeholder = { Text("https://example.com/image.jpg") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customUrlInput.isNotBlank()) {
                            imageUri = customUrlInput.trim()
                            customUrlInput = ""
                            showUrlInputDialog = false
                        }
                    }
                ) {
                    Text("إضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUrlInputDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
