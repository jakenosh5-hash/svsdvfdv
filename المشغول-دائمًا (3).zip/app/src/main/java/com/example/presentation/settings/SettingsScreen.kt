package com.example.presentation.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.presentation.dashboard.DashboardViewModel
import com.example.security.AiPreferences

/**
 * Settings Screen:
 * - Direct 3-tier Grok API Keys setup (Primary, Backup, Reserve).
 * - Multi-key failover with automatic cooldown rotation.
 * - Test connection with immediate visual feedback.
 * - Dual currency exchange rates (USD / SYP).
 * - Biometric security and session locking.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: DashboardViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val uiState by viewModel.uiState.collectAsState()

    var isBiometricEnabled by remember(uiState.isBiometricEnabled) {
        mutableStateOf(uiState.isBiometricEnabled)
    }

    var exchangeRateText by remember(uiState.exchangeRate) {
        mutableStateOf(uiState.exchangeRate.toInt().toString())
    }

    val currentKeys = remember(uiState.aiKeysCount, uiState.aiKeySlots) {
        viewModel.getThreeAiKeys()
    }
    var primaryKey by remember(currentKeys) { mutableStateOf(currentKeys.first) }
    var backupKey by remember(currentKeys) { mutableStateOf(currentKeys.second) }
    var reserveKey by remember(currentKeys) { mutableStateOf(currentKeys.third) }

    var selectedModel by remember(uiState.aiModel) {
        mutableStateOf(if (uiState.aiModel.isNotBlank()) uiState.aiModel else AiPreferences.DEFAULT_GROK_MODEL)
    }

    var showPrimaryKey by remember { mutableStateOf(false) }
    var showBackupKey by remember { mutableStateOf(false) }
    var showReserveKey by remember { mutableStateOf(false) }
    var showClearConfigDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Notification / Toast Banner
            uiState.userMessage?.let { msg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            msg,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.clearUserMessage() }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
            }

            // ════════════════════════════════════════════════════════════
            // 1. AI Configuration Card (Grok 3-Tier Multi-Key Setup)
            // ════════════════════════════════════════════════════════════
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Key,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "مفاتيح التشغيل (Token)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (uiState.aiKeysCount > 0) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    "متصل (${uiState.aiKeysCount}/3)",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Text(
                        "نظام التدوير التلقائي: يتم الاعتماد على الرمز الأساسي أولاً، مع التبديل التلقائي السلس إلى الرموز الاحتياطية لضمان استمرار الاستجابة الفورية دون انقطاع.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Slot 1: Primary Key
                    OutlinedTextField(
                        value = primaryKey,
                        onValueChange = { primaryKey = it },
                        label = { Text("1. الرمز الأساسي (Primary)") },
                        placeholder = { Text("••••••••••••••••") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        visualTransformation = if (showPrimaryKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { showPrimaryKey = !showPrimaryKey }) {
                                    Icon(
                                        if (showPrimaryKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (showPrimaryKey) "إخفاء" else "إظهار"
                                    )
                                }
                                if (primaryKey.isNotBlank()) {
                                    IconButton(onClick = { primaryKey = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                                    }
                                }
                            }
                        }
                    )

                    // Slot 2: Backup Key
                    OutlinedTextField(
                        value = backupKey,
                        onValueChange = { backupKey = it },
                        label = { Text("2. الرمز الاحتياطي (Backup)") },
                        placeholder = { Text("••••••••••••••••") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        visualTransformation = if (showBackupKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { showBackupKey = !showBackupKey }) {
                                    Icon(
                                        if (showBackupKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (showBackupKey) "إخفاء" else "إظهار"
                                    )
                                }
                                if (backupKey.isNotBlank()) {
                                    IconButton(onClick = { backupKey = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                                    }
                                }
                            }
                        }
                    )

                    // Slot 3: Reserve Backup Key
                    OutlinedTextField(
                        value = reserveKey,
                        onValueChange = { reserveKey = it },
                        label = { Text("3. رمز الطوارئ الاحتياطي (Reserve)") },
                        placeholder = { Text("••••••••••••••••") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        visualTransformation = if (showReserveKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { showReserveKey = !showReserveKey }) {
                                    Icon(
                                        if (showReserveKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (showReserveKey) "إخفاء" else "إظهار"
                                    )
                                }
                                if (reserveKey.isNotBlank()) {
                                    IconButton(onClick = { reserveKey = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                                    }
                                }
                            }
                        }
                    )

                    // Save Button
                    Button(
                        onClick = {
                            viewModel.saveThreeAiKeys(
                                primary = primaryKey,
                                backup = backupKey,
                                reserve = reserveKey,
                                model = selectedModel
                            )
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("حفظ وتفعيل المفاتيح", fontWeight = FontWeight.Bold)
                    }

                    // Test & Clear Buttons
                    if (uiState.aiKeysCount > 0 || primaryKey.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.testAiConnection() },
                                enabled = !uiState.isTestingAiConnection,
                                modifier = Modifier.weight(1f).height(44.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary
                                )
                            ) {
                                if (uiState.isTestingAiConnection) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onSecondary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("جاري الفحص...", fontSize = 13.sp)
                                } else {
                                    Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("اختبار الجاهزية", fontSize = 13.sp)
                                }
                            }

                            OutlinedButton(
                                onClick = { showClearConfigDialog = true },
                                modifier = Modifier.weight(1f).height(44.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("مسح المفاتيح", fontSize = 13.sp)
                            }
                        }
                    }

                    // Connection Test Result Banner
                    uiState.aiTestConnectionResult?.let { result ->
                        val isSuccess = result.startsWith("تم", ignoreCase = true)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSuccess)
                                MaterialTheme.colorScheme.primaryContainer
                            else
                                MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (isSuccess) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                                Text(
                                    result,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isSuccess) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }
            }

            // ════════════════════════════════════════════════════════════
            // 2. Dual Currency Exchange Rate Card
            // ════════════════════════════════════════════════════════════
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CurrencyExchange, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("العملات وأسعار الصرف", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        "حدد سعر صرف 1 دولار أمريكي (USD) مقابل الليرة السورية (SYP):",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = exchangeRateText,
                            onValueChange = { exchangeRateText = it },
                            label = { Text("سعر الصرف (ل.س)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        Button(
                            onClick = {
                                exchangeRateText.toDoubleOrNull()
                                    ?.takeIf { it > 0.0 }
                                    ?.let(viewModel::updateManualExchangeRate)
                            }
                        ) {
                            Text("تحديث")
                        }
                    }
                }
            }

            // ════════════════════════════════════════════════════════════
            // 3. Security & Biometric Lock Card
            // ════════════════════════════════════════════════════════════
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("الأمان والخصوصية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("القفل البيومتري (بصمة الإصبع)", fontWeight = FontWeight.Medium)
                            Text(
                                "طلب البصمة عند فتح التطبيق وتأمين العمليات الحساسة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isBiometricEnabled,
                            onCheckedChange = { checked ->
                                isBiometricEnabled = checked
                                viewModel.setBiometricLockEnabled(checked)
                            }
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    OutlinedButton(
                        onClick = { viewModel.lockSessionNow() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("قفل الجلسة الآن")
                    }
                }
            }

            // ════════════════════════════════════════════════════════════
            // 4. Local Storage & Privacy Notice
            // ════════════════════════════════════════════════════════════
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("البيانات والتخزين المحلي", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        "كافة المهام والبيانات المالية والذواكر مخزنة محلياً على جهازك بمحرك Room وقاعدة بيانات SQLite مشفرة وبحماية كاملة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    // Confirmation dialog for clearing installed keys
    if (showClearConfigDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfigDialog = false },
            title = { Text("مسح مفاتيح التشغيل؟") },
            text = { Text("هل تريد مسح مفاتيح الذكاء الاصطناعي المسجلة؟ لن يتم إرسال أي طلبات بعد المسح حتى إدخال مفتاح جديد.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAiConfiguration()
                        primaryKey = ""
                        backupKey = ""
                        reserveKey = ""
                        showClearConfigDialog = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("مسح")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfigDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
