package com.example.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import org.json.JSONArray
import org.json.JSONObject

/**
 * Stores and manages external AI provider configurations:
 * API keys (unlimited list with failover rotation & 18h demotion cooldown),
 * base URLs, selected models, and encrypted configuration file state.
 */
class AiPreferences(context: Context) {

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        PREFS_NAME,
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context.applicationContext,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    companion object {
        private const val PREFS_NAME = "always_busy_ai_config"

        private const val KEY_ORIGINAL_KEYS = "ai_original_keys_json"
        private const val KEY_ACTIVE_KEYS = "ai_active_keys_json"
        private const val KEY_DEMOTIONS = "ai_demotions_json"
        private const val KEY_CONFIG_INSTALLED = "ai_config_installed"

        private const val KEY_PROVIDER = "ai_provider"
        private const val KEY_BASE_URL = "ai_base_url"
        private const val KEY_MODEL = "ai_model"
        private const val KEY_AUTONOMOUS_ENABLED = "ai_autonomous_enabled"

        // Provider Presets
        const val PROVIDER_GROQ = "GROQ"
        const val PROVIDER_GEMINI = "GEMINI"
        const val PROVIDER_OPENROUTER = "OPENROUTER"
        const val PROVIDER_GROK = "GROK"
        const val PROVIDER_OPENAI = "OPENAI"
        const val PROVIDER_CUSTOM = "CUSTOM"

        const val DEFAULT_GROQ_URL = "https://api.groq.com/openai/v1"
        const val MODEL_GROQ_GPT_OSS_120B = "openai/gpt-oss-120b"
        const val MODEL_GROQ_GPT_OSS_20B = "openai/gpt-oss-20b"
        const val DEFAULT_GROQ_MODEL = "openai/gpt-oss-120b"
        const val MODEL_GROQ_LLAMA_70B = "llama-3.3-70b-versatile"
        const val MODEL_GROQ_DEEPSEEK_R1 = "deepseek-r1-distill-llama-70b"
        const val MODEL_GROQ_LLAMA_8B = "llama-3.1-8b-instant"

        const val DEFAULT_GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
        const val DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
        const val MODEL_GEMINI_2_FLASH = "gemini-2.0-flash"

        const val DEFAULT_OPENROUTER_URL = "https://openrouter.ai/api/v1"
        const val DEFAULT_OPENROUTER_MODEL = "openrouter/free"
        const val MODEL_OPENROUTER_DEEPSEEK_R1 = "deepseek/deepseek-r1-zero:free"

        const val DEFAULT_GROK_URL = "https://api.x.ai/v1"
        const val DEFAULT_GROK_MODEL = "grok-2-latest"
        const val MODEL_GROK_2 = "grok-2"
        const val MODEL_GROK_BETA = "grok-beta"
        const val MODEL_GROK_VISION = "grok-2-vision-1212"

        const val DEFAULT_OPENAI_URL = "https://api.openai.com/v1"
        const val DEFAULT_OPENAI_MODEL = "gpt-4o-mini"

        // Personas (Re:Zero Strategic Advisors)
        const val PERSONA_REM = "REM"
        const val PERSONA_RAM = "RAM"
        private const val KEY_ACTIVE_PERSONA = "ai_active_persona"

        // 18 hours cooldown in milliseconds: 18 * 60 * 60 * 1000
        const val DEMOTION_COOLDOWN_MS = 18 * 60 * 60 * 1000L
    }

    var activePersona: String
        get() = prefs.getString(KEY_ACTIVE_PERSONA, PERSONA_REM) ?: PERSONA_REM
        set(value) = prefs.edit().putString(KEY_ACTIVE_PERSONA, value).apply()

    /**
     * Whether an AI configuration is currently installed.
     */
    var isConfigInstalled: Boolean
        get() = prefs.getBoolean(KEY_CONFIG_INSTALLED, false) || getActiveKeys().isNotEmpty()
        private set(value) = prefs.edit().putBoolean(KEY_CONFIG_INSTALLED, value).apply()

    var provider: String
        get() = prefs.getString(KEY_PROVIDER, PROVIDER_GROK) ?: PROVIDER_GROK
        set(value) = prefs.edit().putString(KEY_PROVIDER, value).apply()

    var baseUrl: String
        get() = prefs.getString(KEY_BASE_URL, DEFAULT_GROK_URL) ?: DEFAULT_GROK_URL
        set(value) = prefs.edit().putString(KEY_BASE_URL, value.trim().removeSuffix("/")).apply()

    var model: String
        get() = prefs.getString(KEY_MODEL, DEFAULT_GROK_MODEL) ?: DEFAULT_GROK_MODEL
        set(value) = prefs.edit().putString(KEY_MODEL, value.trim()).apply()

    fun applyPreset(providerName: String) {
        when (providerName.uppercase()) {
            "GEMINI", "GOOGLE" -> {
                provider = PROVIDER_GEMINI
                baseUrl = DEFAULT_GEMINI_URL
                model = DEFAULT_GEMINI_MODEL
            }
            "OPENROUTER" -> {
                provider = PROVIDER_OPENROUTER
                baseUrl = DEFAULT_OPENROUTER_URL
                model = DEFAULT_OPENROUTER_MODEL
            }
            "GROQ", "GROQ_120B" -> {
                provider = PROVIDER_GROQ
                baseUrl = DEFAULT_GROQ_URL
                model = MODEL_GROQ_GPT_OSS_120B
            }
            "GROQ_20B" -> {
                provider = PROVIDER_GROQ
                baseUrl = DEFAULT_GROQ_URL
                model = MODEL_GROQ_GPT_OSS_20B
            }
            "DEEPSEEK_GROQ", "DEEPSEEK", "DEEPSEEK_R1" -> {
                provider = PROVIDER_GROQ
                baseUrl = DEFAULT_GROQ_URL
                model = MODEL_GROQ_DEEPSEEK_R1
            }
            "GROK", "XAI" -> {
                provider = PROVIDER_GROK
                baseUrl = DEFAULT_GROK_URL
                model = DEFAULT_GROK_MODEL
            }
            "OPENAI" -> {
                provider = PROVIDER_OPENAI
                baseUrl = DEFAULT_OPENAI_URL
                model = DEFAULT_OPENAI_MODEL
            }
        }
    }

    var isAutonomousEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTONOMOUS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTONOMOUS_ENABLED, value).apply()

    /**
     * Returns the active primary API key, performing automatic 18-hour cooldown
     * check and resetting to the original order if 18 hours have passed.
     */
    var apiKey: String
        get() = getActivePrimaryApiKey()
        set(value) {
            val trimmed = value.trim()
            if (trimmed.isNotBlank()) {
                setKeysList(listOf(trimmed))
            } else {
                clearConfig()
            }
        }

    val isConfigured: Boolean
        get() = getActiveKeys().isNotEmpty()

    val keysCount: Int
        get() = getActiveKeys().size

    // -------------------------------------------------------------
    // Multi-Key Failover & 18-Hour Demotion Rotation Engine
    // -------------------------------------------------------------

    /**
     * Saves user key slots directly (الأساسي، الاحتياطي، احتياطي الاحتياطي).
     */
    fun saveThreeKeySlots(primary: String, backup: String, reserve: String) {
        val cleanKeys = listOf(primary, backup, reserve).map { it.trim() }.filter { it.isNotBlank() }
        setKeysList(cleanKeys)
        isConfigInstalled = cleanKeys.isNotEmpty()
    }

    fun getThreeKeySlots(): Triple<String, String, String> {
        val original = getOriginalKeys()
        return Triple(
            original.getOrNull(0) ?: "",
            original.getOrNull(1) ?: "",
            original.getOrNull(2) ?: ""
        )
    }

    private fun setKeysList(keys: List<String>) {
        val cleanKeys = keys.map { it.trim() }.filter { it.isNotBlank() }
        val array = JSONArray()
        cleanKeys.forEach { array.put(it) }

        prefs.edit()
            .putString(KEY_ORIGINAL_KEYS, array.toString())
            .putString(KEY_ACTIVE_KEYS, array.toString())
            .remove(KEY_DEMOTIONS)
            .apply()
    }

    /**
     * Retrieves the current list of original keys.
     */
    fun getOriginalKeys(): List<String> {
        val json = prefs.getString(KEY_ORIGINAL_KEYS, null) ?: return emptyList()
        return try {
            val array = JSONArray(json)
            val list = mutableListOf<String>()
            for (i in 0 until array.length()) {
                val k = array.optString(i, "")
                if (k.isNotBlank()) list.add(k)
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Retrieves the active working order of keys, applying 18-hour expiration rule.
     * Falls back to BuildConfig.API_TOKEN if present and no custom keys stored.
     */
    @Synchronized
    fun getActiveKeys(): List<String> {
        checkAndApply18HourCooldown()
        val json = prefs.getString(KEY_ACTIVE_KEYS, null)
        val list = mutableListOf<String>()
        if (json != null) {
            try {
                val array = JSONArray(json)
                for (i in 0 until array.length()) {
                    val k = array.optString(i, "")
                    if (k.isNotBlank()) list.add(k)
                }
            } catch (e: Exception) {
                // ignore
            }
        }
        if (list.isEmpty()) {
            val builtInToken = getBuildConfigToken()
            if (builtInToken.isNotEmpty() && !builtInToken.contains("DEFAULT") && !builtInToken.contains("MY_")) {
                list.add(builtInToken)
            }
        }
        return list
    }

    private fun getBuildConfigToken(): String {
        return runCatching {
            val field = com.example.BuildConfig::class.java.getField("token")
            field.get(null) as? String
        }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() }
            ?: runCatching {
                val field = com.example.BuildConfig::class.java.getField("TOKEN")
                field.get(null) as? String
            }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() }
            ?: runCatching {
                val field = com.example.BuildConfig::class.java.getField("API_TOKEN")
                field.get(null) as? String
            }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() }
            ?: runCatching {
                val field = com.example.BuildConfig::class.java.getField("GEMINI_API_KEY")
                field.get(null) as? String
            }.getOrNull()?.trim() ?: ""
    }

    /**
     * Saves user key slots directly (الأول، الثاني، الثالث، ...).
     */
    fun saveKeySlots(keys: List<String>) {
        val cleanKeys = keys.map { it.trim() }.filter { it.isNotBlank() }
        setKeysList(cleanKeys)
        isConfigInstalled = cleanKeys.isNotEmpty()
    }

    /**
     * Gets user key slots for editing.
     */
    fun getKeySlots(): List<String> {
        val original = getOriginalKeys()
        if (original.isNotEmpty()) return original
        val builtInToken = getBuildConfigToken()
        if (builtInToken.isNotEmpty() && !builtInToken.contains("DEFAULT") && !builtInToken.contains("MY_")) {
            return listOf(builtInToken)
        }
        return emptyList()
    }

    /**
     * Gets the currently active primary key.
     */
    @Synchronized
    fun getActivePrimaryApiKey(): String {
        return getActiveKeys().firstOrNull() ?: ""
    }

    /**
     * Records a key failure and demotes it according to the rule:
     * - The first key becomes the second, and the second becomes the first.
     * - If it fails again, it moves to the third, etc.
     * - The demotion is valid for 18 hours, after which keys revert to original order.
     */
    @Synchronized
    fun recordKeyFailureAndDemote(failedKey: String) {
        val trimmed = failedKey.trim()
        val currentKeys = getActiveKeys().toMutableList()
        val idx = currentKeys.indexOf(trimmed)
        if (idx == -1 || currentKeys.size <= 1) return

        // Demote by moving one position backwards (e.g. from 0 to 1, or 1 to 2)
        currentKeys.removeAt(idx)
        val targetIdx = (idx + 1).coerceAtMost(currentKeys.size)
        currentKeys.add(targetIdx, trimmed)

        // Save active keys
        val array = JSONArray()
        currentKeys.forEach { array.put(it) }

        // Record demotion timestamp
        val demotions = getDemotions().toMutableMap()
        demotions[trimmed] = System.currentTimeMillis()

        val demotionsJson = JSONObject()
        demotions.forEach { (k, v) -> demotionsJson.put(k, v) }

        prefs.edit()
            .putString(KEY_ACTIVE_KEYS, array.toString())
            .putString(KEY_DEMOTIONS, demotionsJson.toString())
            .apply()
    }

    /**
     * Checks if 18 hours have passed since the oldest demotion.
     * If 18 hours have elapsed, reverts keys to their original specified order.
     */
    @Synchronized
    fun checkAndApply18HourCooldown() {
        val demotions = getDemotions()
        if (demotions.isEmpty()) return

        val now = System.currentTimeMillis()
        val allExpired = demotions.values.all { demotedAt ->
            (now - demotedAt) >= DEMOTION_COOLDOWN_MS
        }

        if (allExpired) {
            // Revert back to original order!
            val original = prefs.getString(KEY_ORIGINAL_KEYS, null)
            if (original != null) {
                prefs.edit()
                    .putString(KEY_ACTIVE_KEYS, original)
                    .remove(KEY_DEMOTIONS)
                    .apply()
            }
        }
    }

    private fun getDemotions(): Map<String, Long> {
        val json = prefs.getString(KEY_DEMOTIONS, null) ?: return emptyMap()
        return try {
            val obj = JSONObject(json)
            val map = mutableMapOf<String, Long>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.optLong(k, 0L)
            }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    /**
     * Clears all configurations, keys, and demotion state.
     * Used when the user clicks "مسح ملف الإعدادات والمفاتيح" to change keys.
     */
    @Synchronized
    fun clearConfig() {
        prefs.edit()
            .remove(KEY_ORIGINAL_KEYS)
            .remove(KEY_ACTIVE_KEYS)
            .remove(KEY_DEMOTIONS)
            .putBoolean(KEY_CONFIG_INSTALLED, false)
            .putString(KEY_PROVIDER, PROVIDER_GROQ)
            .putString(KEY_BASE_URL, DEFAULT_GROQ_URL)
            .putString(KEY_MODEL, DEFAULT_GROQ_MODEL)
            .apply()
    }
}
