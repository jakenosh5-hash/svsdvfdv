package com.example.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/**
 * Security boundary for REM/RAM secrets. Keys are never stored in plain SharedPreferences,
 * logs, Room, intents, or notification payloads. Runtime code receives a key only at request time.
 */
class PersonaProfileStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        "always_busy_persona_profiles",
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context.applicationContext,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    data class Profile(
        val persona: String,
        val provider: String,
        val baseUrl: String,
        val model: String,
        val maxIterations: Int,
        val autonomous: Boolean,
        val keys: List<String>
    )

    fun saveProfile(profile: Profile) {
        require(profile.persona == AiPreferences.PERSONA_REM || profile.persona == AiPreferences.PERSONA_RAM)
        require(profile.maxIterations in 1..32)
        val editor = prefs.edit()
            .putString("${profile.persona}:provider", profile.provider)
            .putString("${profile.persona}:baseUrl", profile.baseUrl.trim().removeSuffix("/"))
            .putString("${profile.persona}:model", profile.model)
            .putInt("${profile.persona}:maxIterations", profile.maxIterations)
            .putBoolean("${profile.persona}:autonomous", profile.autonomous)
        for (slot in 0..2) {
            editor.putString("${profile.persona}:key:$slot", profile.keys.getOrNull(slot)?.trim().orEmpty())
        }
        editor.apply()
    }

    fun loadProfile(persona: String): Profile {
        require(persona == AiPreferences.PERSONA_REM || persona == AiPreferences.PERSONA_RAM)
        return Profile(
            persona = persona,
            provider = prefs.getString("$persona:provider", AiPreferences.PROVIDER_CUSTOM).orEmpty(),
            baseUrl = prefs.getString("$persona:baseUrl", "").orEmpty(),
            model = prefs.getString("$persona:model", "").orEmpty(),
            maxIterations = prefs.getInt("$persona:maxIterations", 8),
            autonomous = prefs.getBoolean("$persona:autonomous", true),
            keys = (0..2).map { prefs.getString("$persona:key:$it", "").orEmpty() }
        )
    }

    fun clearPersona(persona: String) {
        require(persona == AiPreferences.PERSONA_REM || persona == AiPreferences.PERSONA_RAM)
        val editor = prefs.edit()
        listOf("provider", "baseUrl", "model", "maxIterations", "autonomous").forEach { editor.remove("$persona:$it") }
        (0..2).forEach { editor.remove("$persona:key:$it") }
        editor.apply()
    }

    fun activeKeys(persona: String, now: Long = System.currentTimeMillis()): List<Pair<Int, String>> {
        return (0..2).mapNotNull { slot ->
            val key = prefs.getString("$persona:key:$slot", "").orEmpty()
            val cooldown = prefs.getLong("$persona:cooldown:$slot", 0L)
            key.takeIf { it.isNotBlank() && cooldown <= now }?.let { slot to it }
        }
    }

    fun demoteKey(persona: String, slot: Int, now: Long = System.currentTimeMillis()) {
        require(slot in 0..2)
        prefs.edit()
            .putLong("$persona:cooldown:$slot", now + AiPreferences.DEMOTION_COOLDOWN_MS)
            .putInt("$persona:failures:$slot", prefs.getInt("$persona:failures:$slot", 0) + 1)
            .apply()
    }
}
