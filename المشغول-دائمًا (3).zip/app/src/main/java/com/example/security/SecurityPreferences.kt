package com.example.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.SecureRandom
import android.util.Base64

/**
 * Manages database passphrase generation, hardware-encrypted storage,
 * and biometric authentication preferences.
 */
class SecurityPreferences(private val context: Context) {
    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        PREFS_NAME,
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context.applicationContext,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    init { _isLocked.value = false }

    fun isBiometricEnabled(): Boolean {
        return prefs.getBoolean(KEY_BIOMETRIC_ENABLED, false)
    }

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
        if (!enabled) {
            _isLocked.value = false
        }
    }

    fun unlockSession() {
        _isLocked.value = false
        updateLastActiveTime()
    }

    fun lockSession() {
        if (isBiometricEnabled()) {
            _isLocked.value = true
        }
    }

    fun updateLastActiveTime() {
        prefs.edit().putLong(KEY_LAST_ACTIVE_TIME, System.currentTimeMillis()).apply()
    }

    fun checkInactivityLock(timeoutMillis: Long = 5 * 60 * 1000L) {
        if (!isBiometricEnabled()) return
        val lastActive = prefs.getLong(KEY_LAST_ACTIVE_TIME, 0L)
        if (System.currentTimeMillis() - lastActive > timeoutMillis) {
            _isLocked.value = true
        }
    }

    /**
     * Retrieves or generates a 256-bit database passphrase encrypted with Android Keystore.
     */
    fun getOrCreateDatabasePassphrase(): ByteArray {
        val encryptedPassphrase = prefs.getString(KEY_DB_PASSPHRASE, null)
        return if (encryptedPassphrase != null) {
            try {
                val plainHex = KeystoreManager.decrypt(encryptedPassphrase)
                plainHex.toByteArray(Charsets.UTF_8)
            } catch (e: Exception) {
                // If Keystore key was invalidated, re-generate safely
                generateAndSaveNewPassphrase()
            }
        } else {
            generateAndSaveNewPassphrase()
        }
    }

    private fun generateAndSaveNewPassphrase(): ByteArray {
        val randomBytes = ByteArray(32)
        SecureRandom().nextBytes(randomBytes)
        val plainHex = Base64.encodeToString(randomBytes, Base64.NO_WRAP)
        val encrypted = KeystoreManager.encrypt(plainHex)
        prefs.edit().putString(KEY_DB_PASSPHRASE, encrypted).apply()
        return plainHex.toByteArray(Charsets.UTF_8)
    }

    companion object {
        private const val PREFS_NAME = "always_busy_security_prefs"
        private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
        private const val KEY_LAST_ACTIVE_TIME = "last_active_time"
        private const val KEY_DB_PASSPHRASE = "db_passphrase_encrypted"
    }
}
