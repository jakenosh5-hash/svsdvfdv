package com.example.services

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.example.domain.agent.AgentJobQueue
import kotlinx.coroutines.runBlocking
import org.json.JSONObject

class AgentFirebaseMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        val persona = data["persona"]?.takeIf { it == "REM" || it == "RAM" } ?: return
        val conversationId = data["conversation_id"]?.toLongOrNull() ?: return
        val prompt = data["prompt"]?.takeIf { it.isNotBlank() } ?: return
        runBlocking {
            AgentJobQueue(this@AgentFirebaseMessagingService).enqueue(
                persona = persona,
                kind = "FCM_AGENT_MESSAGE",
                payload = JSONObject().put("conversation_id", conversationId).put("prompt", prompt),
                idempotencyKey = data["idempotency_key"] ?: "fcm:${message.messageId ?: prompt.hashCode()}",
                conversationId = conversationId
            )
        }
    }
}
