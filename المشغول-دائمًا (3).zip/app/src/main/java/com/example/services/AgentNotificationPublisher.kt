package com.example.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.example.AlwaysBusyApp
import com.example.MainActivity
import com.example.domain.agent.AgentJobQueue
import kotlinx.coroutines.launch
import org.json.JSONObject

class AgentNotificationPublisher(private val context: Context) {
    companion object {
        const val CHANNEL_ID = "always_busy_agent"
        const val ACTION_REPLY = "com.example.action.AGENT_REPLY"
        const val ACTION_BUSY = "com.example.action.AGENT_BUSY"
        const val ACTION_SNOOZE = "com.example.action.AGENT_SNOOZE"
        const val ACTION_READ = "com.example.action.AGENT_READ"
        const val EXTRA_PLAN_ID = "notification_plan_id"
        const val EXTRA_PERSONA = "persona"
        const val EXTRA_CONVERSATION_ID = "conversation_id"
        const val REMOTE_INPUT_KEY = "agent_reply"

        fun createChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = context.getSystemService(NotificationManager::class.java)
                manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Always Busy Agent", NotificationManager.IMPORTANCE_HIGH))
            }
        }
    }

    fun publish(planId: Long, persona: String, conversationId: Long, title: String, body: String, tone: String, actionsJson: String) {
        require(title.isNotBlank() && body.isNotBlank())
        createChannel(context)
        val common = Intent(context, AgentNotificationActionReceiver::class.java)
            .putExtra(EXTRA_PLAN_ID, planId)
            .putExtra(EXTRA_PERSONA, persona)
            .putExtra(EXTRA_CONVERSATION_ID, conversationId)
        val replyIntent = PendingIntent.getBroadcast(context, requestCode(planId, 1), common.setAction(ACTION_REPLY), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        val busyIntent = PendingIntent.getBroadcast(context, requestCode(planId, 2), common.setAction(ACTION_BUSY), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snoozeIntent = PendingIntent.getBroadcast(context, requestCode(planId, 3), common.setAction(ACTION_SNOOZE), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val readIntent = PendingIntent.getBroadcast(context, requestCode(planId, 4), common.setAction(ACTION_READ), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val remoteInput = RemoteInput.Builder(REMOTE_INPUT_KEY).setLabel("رد مباشر").build()
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .addAction(NotificationCompat.Action.Builder(0, "رد", replyIntent).addRemoteInput(remoteInput).build())
            .addAction(NotificationCompat.Action.Builder(0, "أنا مشغول الآن", busyIntent).build())
            .addAction(NotificationCompat.Action.Builder(0, "تأجيل", snoozeIntent).build())
            .setDeleteIntent(readIntent)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(planId.toInt(), notification)
    }

    private fun requestCode(planId: Long, action: Int) = (planId * 10 + action).toInt()
}

class AgentNotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val app = context.applicationContext as AlwaysBusyApp
                val planId = intent.getLongExtra(AgentNotificationPublisher.EXTRA_PLAN_ID, -1L)
                val persona = intent.getStringExtra(AgentNotificationPublisher.EXTRA_PERSONA) ?: return@launch
                val conversationId = intent.getLongExtra(AgentNotificationPublisher.EXTRA_CONVERSATION_ID, -1L)
                val text = androidx.core.app.RemoteInput.getResultsFromIntent(intent)?.getCharSequence(AgentNotificationPublisher.REMOTE_INPUT_KEY)?.toString()
                val event = when (intent.action) {
                    AgentNotificationPublisher.ACTION_REPLY -> "REMOTE_INPUT"
                    AgentNotificationPublisher.ACTION_BUSY -> "USER_BUSY"
                    AgentNotificationPublisher.ACTION_SNOOZE -> "SNOOZE"
                    AgentNotificationPublisher.ACTION_READ -> "MARK_AS_READ"
                    else -> return@launch
                }
                val payload = JSONObject().apply {
                    put("event", event)
                    put("plan_id", planId)
                    put("conversation_id", conversationId)
                    if (!text.isNullOrBlank()) put("reply", text)
                }
                val queue = AgentJobQueue(context)
                queue.enqueue(persona, "NOTIFICATION_EVENT", payload, "notification:$planId:$event:${text ?: ""}", conversationId)
                if (event == "MARK_AS_READ") app.container.database.agentRuntimeDao().markPlanRead(planId)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
