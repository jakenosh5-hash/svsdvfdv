package com.example.services

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.AlwaysBusyApp
import com.example.domain.agent.AgentJobWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AgentAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val result = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val jobId = intent.getLongExtra("job_id", -1L)
                if (jobId > 0) {
                    WorkManager.getInstance(context).enqueue(
                        OneTimeWorkRequestBuilder<AgentJobWorker>()
                            .setInputData(androidx.work.workDataOf("job_id" to jobId))
                            .addTag("alarm-agent-job:$jobId")
                            .build()
                    )
                }
            } finally {
                result.finish()
            }
        }
    }
}

class AgentBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val result = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = (context.applicationContext as AlwaysBusyApp).container.database.agentRuntimeDao()
                dao.allScheduled().forEach { task ->
                    val jobId = dao.getJobByIdempotencyKey("schedule:${task.id}")?.id
                    if (jobId != null) schedule(context, jobId, task.dueAt)
                }
            } finally {
                result.finish()
            }
        }
    }

    private fun schedule(context: Context, jobId: Long, dueAt: Long) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, AgentAlarmReceiver::class.java).putExtra("job_id", jobId)
        val pending = PendingIntent.getBroadcast(context, jobId.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (android.os.Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pending)
        } else {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pending)
        }
    }
}
