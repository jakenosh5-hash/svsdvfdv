package com.example.services

import com.example.data.local.AppDatabase
import com.example.data.local.entities.AiConversationEntity
import com.example.data.local.entities.AiMemoryItemEntity
import com.example.data.local.entities.AiMessageEntity
import com.example.domain.backup.BackupAndExportEngine
import com.example.domain.command.CommandBus
import com.example.domain.command.CommandParser
import com.example.domain.command.CommandResult
import com.example.domain.gateway.AiToolCallDispatcher
import com.example.domain.gateway.AppInternalGateway
import com.example.domain.memory.CumulativeMemoryEngine
import com.example.domain.models.AuditActor
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

interface IAiAutomationService {
    val gateway: AppInternalGateway
    val commandBus: CommandBus
    val toolCallDispatcher: AiToolCallDispatcher
    val memoryEngine: CumulativeMemoryEngine
    val backupEngine: BackupAndExportEngine

    fun getActiveConversations(): Flow<List<AiConversationEntity>>
    fun getMessages(conversationId: Long): Flow<List<AiMessageEntity>>
    fun getAllMemories(): Flow<List<AiMemoryItemEntity>>

    suspend fun createConversation(title: String = "جلسة تفكير وتنفيذ جديدة", persona: String = "REM"): Long
    suspend fun updateConversationPersona(conversationId: Long, persona: String)
    suspend fun deleteConversation(conversationId: Long)
    suspend fun sendUserMessage(conversationId: Long, text: String): AiMessageEntity
    suspend fun executeTerminalCommand(input: String): CommandResult
    suspend fun saveMemory(category: String, key: String, content: String, importance: Int = 3): Long
    suspend fun deleteMemory(id: Long)
}

class AiAutomationServiceImpl(
    private val database: AppDatabase,
    override val gateway: AppInternalGateway,
    override val commandBus: CommandBus,
    override val toolCallDispatcher: AiToolCallDispatcher,
    override val memoryEngine: CumulativeMemoryEngine,
    override val backupEngine: BackupAndExportEngine
) : IAiAutomationService {

    private val aiDao = database.aiDao()

    override fun getActiveConversations(): Flow<List<AiConversationEntity>> =
        aiDao.getActiveConversations()

    override fun getMessages(conversationId: Long): Flow<List<AiMessageEntity>> =
        aiDao.getMessagesForConversation(conversationId)

    override fun getAllMemories(): Flow<List<AiMemoryItemEntity>> =
        aiDao.getAllMemories()

    override suspend fun createConversation(title: String, persona: String): Long {
        return aiDao.insertConversation(
            AiConversationEntity(
                title = title,
                persona = persona,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    override suspend fun updateConversationPersona(conversationId: Long, persona: String) {
        val conv = aiDao.getConversationById(conversationId) ?: return
        aiDao.updateConversation(conv.copy(persona = persona, updatedAt = System.currentTimeMillis()))
    }

    override suspend fun deleteConversation(conversationId: Long) {
        aiDao.deleteMessagesForConversation(conversationId)
        aiDao.deleteConversation(conversationId)
    }

    override suspend fun sendUserMessage(conversationId: Long, text: String): AiMessageEntity {
        // 1. Record user message
        val userMsgId = aiDao.insertMessage(
            AiMessageEntity(
                conversationId = conversationId,
                sender = "USER",
                content = text,
                timestamp = System.currentTimeMillis()
            )
        )

        // 2. Check if user text directly implies an automation command or intent
        val trimmed = text.trim()
        val assistantResponse: AiMessageEntity

        if (trimmed.startsWith("/") || isDirectIntent(trimmed)) {
            // Autonomous Execution Engine intercepts intent
            val cmdText = if (trimmed.startsWith("/")) trimmed.removePrefix("/") else convertIntentToCommand(trimmed)
            val result = executeTerminalCommand(cmdText)

            val toolCallsJson = JSONObject().apply {
                put("executed_command", cmdText)
                put("action_type", result.actionType)
            }.toString()

            val toolResultJson = result.outputJson

            val replyText = if (result.isSuccess) {
                "${result.outputUser}\n\n(تم التنفيذ تلقائياً عبر منفذ الأوامر الخلفي)"
            } else {
                "${result.outputUser}\n\n(فشل التنفيذ: ${result.errorCode})"
            }

            assistantResponse = AiMessageEntity(
                conversationId = conversationId,
                sender = "ASSISTANT",
                content = replyText,
                toolCallsJson = toolCallsJson,
                toolResultJson = toolResultJson,
                timestamp = System.currentTimeMillis()
            )
        } else {
            // Conversational Reasoning & System Context Synthesizer
            val replyText = "لم يتم إعداد مزود الذكاء الاصطناعي لهذه الجلسة. لم أُنشئ أو أنفذ أي قيمة أو عملية مفترضة. أضف مزوداً ومفاتيح مستقلة للشخصية ثم أعد الطلب."

            assistantResponse = AiMessageEntity(
                conversationId = conversationId,
                sender = "ASSISTANT",
                content = replyText,
                timestamp = System.currentTimeMillis()
            )
        }

        val assistantId = aiDao.insertMessage(assistantResponse)

        // 3. Trigger cumulative memory distillation
        val allMessages = aiDao.getMessagesList(conversationId)
        memoryEngine.distillAndStoreMemoriesFromConversation(conversationId, allMessages)

        return assistantResponse.copy(id = assistantId)
    }

    override suspend fun executeTerminalCommand(input: String): CommandResult {
        return try {
            val command = CommandParser.parse(input)
            commandBus.execute(command, actor = AuditActor.AI_AGENT)
        } catch (e: Exception) {
            val errJson = JSONObject().put("status", "error").put("message", e.message).toString()
            CommandResult(
                isSuccess = false,
                outputUser = "خطأ في بناء الأمر: ${e.message}",
                outputJson = errJson,
                actionType = "PARSE_ERROR",
                errorCode = "SYNTAX_ERROR"
            )
        }
    }

    override suspend fun saveMemory(category: String, key: String, content: String, importance: Int): Long {
        return gateway.saveMemory(category, key, content, importance)
    }

    override suspend fun deleteMemory(id: Long) {
        aiDao.deleteMemory(id)
    }

    private fun isDirectIntent(text: String): Boolean {
        val lower = text.lowercase()
        return lower.startsWith("أنشئ مهمة") || lower.startsWith("اضف مهمة") ||
                lower.startsWith("سجل مصروف") || lower.startsWith("سجل دخل") ||
                lower.startsWith("سدد دين") || lower.startsWith("أضف دين") ||
                lower.startsWith("كم الرصيد") || lower.startsWith("فهرس النظام")
    }

    private fun convertIntentToCommand(text: String): String {
        return when {
            text.startsWith("أنشئ مهمة") || text.startsWith("اضف مهمة") -> {
                val title = text.removePrefix("أنشئ مهمة").removePrefix("اضف مهمة").trim()
                "task add \"$title\" priority:high"
            }
            text.startsWith("سجل مصروف") -> {
                val parts = text.removePrefix("سجل مصروف").trim().split(" ")
                val amount = parts.firstOrNull()?.takeIf { it.toDoubleOrNull() != null }
                    ?: return ""
                "finance expense $amount currency:SYP category:عام"
            }
            text.startsWith("سجل دخل") -> {
                val parts = text.removePrefix("سجل دخل").trim().split(" ")
                val amount = parts.firstOrNull()?.takeIf { it.toDoubleOrNull() != null }
                    ?: return ""
                "finance income $amount currency:SYP category:دخل"
            }
            text.startsWith("كم الرصيد") -> "balance"
            text.startsWith("فهرس النظام") -> "snapshot"
            else -> text
        }
    }

}
