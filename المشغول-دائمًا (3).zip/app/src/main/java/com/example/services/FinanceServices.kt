package com.example.services

import android.content.Context
import com.example.data.local.dao.*
import com.example.data.local.entities.*
import com.example.domain.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Unified financial balance representation across primary (SYP) and secondary (USD) currencies.
 */
data class CurrencyBalance(
    val sypIncome: Double = 0.0,
    val sypExpense: Double = 0.0,
    val sypNet: Double = 0.0,
    val usdIncome: Double = 0.0,
    val usdExpense: Double = 0.0,
    val usdNet: Double = 0.0
)

interface IFinanceService {
    fun getAllTransactions(): Flow<List<FinanceTransactionEntity>>
    fun getTransactionsByCurrency(currency: CurrencyType): Flow<List<FinanceTransactionEntity>>
    fun getCategories(): Flow<List<CategoryEntity>>
    fun getBalanceSummary(): Flow<CurrencyBalance>
    suspend fun recordTransaction(
        type: TransactionType,
        amount: Double,
        currency: CurrencyType,
        categoryId: Long,
        note: String? = null,
        projectId: Long? = null,
        isRecurring: Boolean = false,
        recurrenceRule: String? = null
    ): Long
    suspend fun deleteTransaction(tx: FinanceTransactionEntity)
    fun getBudgetsForMonth(yearMonth: String): Flow<List<BudgetEntity>>
    suspend fun setBudget(categoryId: Long, monthlyLimit: Double, currency: CurrencyType, yearMonth: String): Long
    fun getAllAssets(): Flow<List<AssetEntity>>
    suspend fun saveAsset(
        name: String,
        category: String,
        currentValue: Double,
        purchaseCost: Double?,
        currency: CurrencyType,
        note: String? = null,
        assetId: Long? = null
    ): Long
    suspend fun deleteAsset(asset: AssetEntity)
    fun getLatestExchangeRate(): Flow<ExchangeRateEntity?>
    suspend fun updateExchangeRate(rate: Double, note: String? = null): Long
}

class FinanceServiceImpl(
    private val financeDao: FinanceDao,
    private val auditService: IAuditService
) : IFinanceService {

    override fun getAllTransactions(): Flow<List<FinanceTransactionEntity>> =
        financeDao.getAllTransactions()

    override fun getTransactionsByCurrency(currency: CurrencyType): Flow<List<FinanceTransactionEntity>> =
        financeDao.getTransactionsByCurrency(currency)

    override fun getCategories(): Flow<List<CategoryEntity>> =
        financeDao.getAllCategories()

    override fun getBalanceSummary(): Flow<CurrencyBalance> {
        return financeDao.getAllTransactions().map { txs ->
            var sypIncome = 0.0
            var sypExpense = 0.0
            var usdIncome = 0.0
            var usdExpense = 0.0

            for (tx in txs) {
                when (tx.currency) {
                    CurrencyType.SYP -> {
                        if (tx.type == TransactionType.INCOME) sypIncome += tx.amount
                        else if (tx.type == TransactionType.EXPENSE) sypExpense += tx.amount
                    }
                    CurrencyType.USD -> {
                        if (tx.type == TransactionType.INCOME) usdIncome += tx.amount
                        else if (tx.type == TransactionType.EXPENSE) usdExpense += tx.amount
                    }
                }
            }

            CurrencyBalance(
                sypIncome = sypIncome,
                sypExpense = sypExpense,
                sypNet = sypIncome - sypExpense,
                usdIncome = usdIncome,
                usdExpense = usdExpense,
                usdNet = usdIncome - usdExpense
            )
        }
    }

    override suspend fun recordTransaction(
        type: TransactionType,
        amount: Double,
        currency: CurrencyType,
        categoryId: Long,
        note: String?,
        projectId: Long?,
        isRecurring: Boolean,
        recurrenceRule: String?
    ): Long {
        val tx = FinanceTransactionEntity(
            type = type,
            amount = amount,
            currency = currency,
            categoryId = categoryId,
            projectId = projectId,
            transactionDate = System.currentTimeMillis(),
            note = note,
            isRecurring = isRecurring,
            recurrenceRule = recurrenceRule
        )
        val id = financeDao.insertTransaction(tx)
        auditService.logEvent(
            entityType = "FINANCE_TRANSACTION",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"amount\": $amount, \"currency\": \"$currency\", \"type\": \"$type\" }"
        )
        return id
    }

    override suspend fun deleteTransaction(tx: FinanceTransactionEntity) {
        financeDao.deleteTransaction(tx)
        auditService.logEvent(
            entityType = "FINANCE_TRANSACTION",
            entityId = tx.id,
            action = AuditAction.DELETE,
            payloadBefore = "{ \"amount\": ${tx.amount}, \"currency\": \"${tx.currency}\" }"
        )
    }

    override fun getBudgetsForMonth(yearMonth: String): Flow<List<BudgetEntity>> =
        financeDao.getBudgetsForMonth(yearMonth)

    override suspend fun setBudget(
        categoryId: Long,
        monthlyLimit: Double,
        currency: CurrencyType,
        yearMonth: String
    ): Long {
        val budget = BudgetEntity(
            categoryId = categoryId,
            monthlyLimit = monthlyLimit,
            currency = currency,
            yearMonth = yearMonth
        )
        val id = financeDao.insertBudget(budget)
        auditService.logEvent(
            entityType = "BUDGET",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"limit\": $monthlyLimit, \"yearMonth\": \"$yearMonth\" }"
        )
        return id
    }

    override fun getAllAssets(): Flow<List<AssetEntity>> =
        financeDao.getAllAssets()

    override suspend fun saveAsset(
        name: String,
        category: String,
        currentValue: Double,
        purchaseCost: Double?,
        currency: CurrencyType,
        note: String?,
        assetId: Long?
    ): Long {
        val asset = AssetEntity(
            id = assetId ?: 0,
            name = name,
            category = category,
            currentValue = currentValue,
            purchaseCost = purchaseCost,
            currency = currency,
            lastValuedAt = System.currentTimeMillis(),
            note = note
        )
        val id = if (assetId != null && assetId > 0) {
            financeDao.updateAsset(asset)
            assetId
        } else {
            financeDao.insertAsset(asset)
        }
        auditService.logEvent(
            entityType = "ASSET",
            entityId = id,
            action = if (assetId != null && assetId > 0) AuditAction.UPDATE else AuditAction.CREATE,
            payloadAfter = "{ \"name\": \"$name\", \"currentValue\": $currentValue }"
        )
        return id
    }

    override suspend fun deleteAsset(asset: AssetEntity) {
        financeDao.deleteAsset(asset)
        auditService.logEvent(
            entityType = "ASSET",
            entityId = asset.id,
            action = AuditAction.DELETE,
            payloadBefore = "{ \"name\": \"${asset.name}\" }"
        )
    }

    override fun getLatestExchangeRate(): Flow<ExchangeRateEntity?> =
        financeDao.getLatestExchangeRateFlow()

    override suspend fun updateExchangeRate(rate: Double, note: String?): Long {
        val entity = ExchangeRateEntity(
            baseCurrency = "USD",
            targetCurrency = "SYP",
            rate = rate,
            recordedAt = System.currentTimeMillis(),
            note = note
        )
        val id = financeDao.insertExchangeRate(entity)
        auditService.logEvent(
            entityType = "EXCHANGE_RATE",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"rate\": $rate }"
        )
        return id
    }
}

// -----------------------------------------------------------------------------
// DEBT SERVICE
// -----------------------------------------------------------------------------

interface IDebtService {
    fun getAllDebts(): Flow<List<DebtEntity>>
    fun getDebtsByType(type: DebtType): Flow<List<DebtEntity>>
    fun getDebtsByStatus(status: DebtStatus): Flow<List<DebtEntity>>
    suspend fun createDebt(
        type: DebtType,
        personName: String,
        amount: Double,
        currency: CurrencyType = CurrencyType.SYP,
        dueDate: Long? = null,
        phoneNumber: String? = null,
        note: String? = null
    ): Long
    suspend fun recordPartialPayment(debtId: Long, amount: Double, note: String? = null): Long
    suspend fun deleteDebt(debtId: Long)
}

class DebtServiceImpl(
    private val debtDao: DebtDao,
    private val auditService: IAuditService
) : IDebtService {

    override fun getAllDebts(): Flow<List<DebtEntity>> =
        debtDao.getAllDebts()

    override fun getDebtsByType(type: DebtType): Flow<List<DebtEntity>> =
        debtDao.getDebtsByType(type)

    override fun getDebtsByStatus(status: DebtStatus): Flow<List<DebtEntity>> =
        debtDao.getDebtsByStatus(status)

    override suspend fun createDebt(
        type: DebtType,
        personName: String,
        amount: Double,
        currency: CurrencyType,
        dueDate: Long?,
        phoneNumber: String?,
        note: String?
    ): Long {
        val debt = DebtEntity(
            personName = personName,
            phoneNumber = phoneNumber,
            type = type,
            originalAmount = amount,
            remainingAmount = amount,
            currency = currency,
            dueDate = dueDate,
            note = note,
            status = DebtStatus.ACTIVE
        )
        val id = debtDao.insertDebt(debt)
        auditService.logEvent(
            entityType = "DEBT",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"person\": \"$personName\", \"amount\": $amount, \"type\": \"$type\" }"
        )
        return id
    }

    override suspend fun recordPartialPayment(debtId: Long, amount: Double, note: String?): Long {
        val payment = DebtPaymentEntity(
            debtId = debtId,
            amount = amount,
            paymentDate = System.currentTimeMillis(),
            receiptNote = note
        )
        debtDao.applyDebtPayment(payment)
        auditService.logEvent(
            entityType = "DEBT_PAYMENT",
            entityId = debtId,
            action = AuditAction.UPDATE,
            payloadAfter = "{ \"paymentAmount\": $amount }"
        )
        return payment.id
    }

    override suspend fun deleteDebt(debtId: Long) {
        val debt = debtDao.getDebtById(debtId) ?: return
        debtDao.deleteDebt(debt)
        auditService.logEvent(
            entityType = "DEBT",
            entityId = debtId,
            action = AuditAction.DELETE,
            payloadBefore = "{ \"person\": \"${debt.personName}\" }"
        )
    }
}

// -----------------------------------------------------------------------------
// TIME TRACKING SERVICE
// -----------------------------------------------------------------------------

interface ITimeTrackingService {
    fun getAllEntries(): Flow<List<TimeEntryEntity>>
    suspend fun getRunningEntry(): TimeEntryEntity?
    suspend fun startTimer(taskId: Long, notes: String? = null): Long
    suspend fun stopTimer(): TimeEntryEntity?
    suspend fun logManualTime(taskId: Long, durationMinutes: Int, notes: String? = null): Long
}

class TimeTrackingServiceImpl(
    private val timeEntryDao: TimeEntryDao,
    private val auditService: IAuditService
) : ITimeTrackingService {

    override fun getAllEntries(): Flow<List<TimeEntryEntity>> =
        timeEntryDao.getAllEntries()

    override suspend fun getRunningEntry(): TimeEntryEntity? =
        timeEntryDao.getRunningEntry()

    override suspend fun startTimer(taskId: Long, notes: String?): Long {
        // Stop any currently running timer first
        stopTimer()

        val entry = TimeEntryEntity(
            taskId = taskId,
            startTime = System.currentTimeMillis(),
            endTime = null,
            durationSeconds = 0L,
            notes = notes
        )
        val id = timeEntryDao.insertTimeEntry(entry)
        auditService.logEvent(
            entityType = "TIME_ENTRY",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"taskId\": $taskId, \"action\": \"START_TIMER\" }"
        )
        return id
    }

    override suspend fun stopTimer(): TimeEntryEntity? {
        val running = timeEntryDao.getRunningEntry() ?: return null
        val now = System.currentTimeMillis()
        val durationSec = ((now - running.startTime) / 1000L).coerceAtLeast(1L)
        val updated = running.copy(
            endTime = now,
            durationSeconds = durationSec
        )
        timeEntryDao.updateTimeEntry(updated)
        auditService.logEvent(
            entityType = "TIME_ENTRY",
            entityId = running.id,
            action = AuditAction.UPDATE,
            payloadAfter = "{ \"durationSeconds\": $durationSec, \"action\": \"STOP_TIMER\" }"
        )
        return updated
    }

    override suspend fun logManualTime(taskId: Long, durationMinutes: Int, notes: String?): Long {
        val now = System.currentTimeMillis()
        val durationSec = durationMinutes * 60L
        val startTime = now - (durationSec * 1000L)
        val entry = TimeEntryEntity(
            taskId = taskId,
            startTime = startTime,
            endTime = now,
            durationSeconds = durationSec,
            notes = notes
        )
        val id = timeEntryDao.insertTimeEntry(entry)
        auditService.logEvent(
            entityType = "TIME_ENTRY",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"taskId\": $taskId, \"manualMinutes\": $durationMinutes }"
        )
        return id
    }
}

// -----------------------------------------------------------------------------
// GOAL SERVICE
// -----------------------------------------------------------------------------

interface IGoalService {
    fun getAllGoals(): Flow<List<GoalEntity>>
    suspend fun createGoal(
        title: String,
        description: String? = null,
        horizon: GoalHorizon = GoalHorizon.MEDIUM_TERM,
        targetValue: Double = 100.0,
        targetDate: Long? = null,
        metricType: String = "PERCENTAGE"
    ): Long
    suspend fun updateGoalProgress(goalId: Long, currentValue: Double)
    suspend fun deleteGoal(goalId: Long)
}

class GoalServiceImpl(
    private val goalDao: GoalDao,
    private val auditService: IAuditService
) : IGoalService {

    override fun getAllGoals(): Flow<List<GoalEntity>> =
        goalDao.getAllGoals()

    override suspend fun createGoal(
        title: String,
        description: String?,
        horizon: GoalHorizon,
        targetValue: Double,
        targetDate: Long?,
        metricType: String
    ): Long {
        val goal = GoalEntity(
            title = title,
            description = description,
            targetValue = targetValue,
            currentValue = 0.0,
            metricType = metricType,
            targetDate = targetDate,
            horizon = horizon,
            status = GoalStatus.IN_PROGRESS
        )
        val id = goalDao.insertGoal(goal)
        auditService.logEvent(
            entityType = "GOAL",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"title\": \"$title\", \"targetValue\": $targetValue }"
        )
        return id
    }

    override suspend fun updateGoalProgress(goalId: Long, currentValue: Double) {
        val goal = goalDao.getGoalById(goalId) ?: return
        val newStatus = if (currentValue >= goal.targetValue) GoalStatus.ACHIEVED else GoalStatus.IN_PROGRESS
        val updated = goal.copy(
            currentValue = currentValue,
            status = newStatus,
            updatedAt = System.currentTimeMillis()
        )
        goalDao.updateGoal(updated)
        auditService.logEvent(
            entityType = "GOAL",
            entityId = goalId,
            action = AuditAction.UPDATE,
            payloadAfter = "{ \"currentValue\": $currentValue, \"status\": \"$newStatus\" }"
        )
    }

    override suspend fun deleteGoal(goalId: Long) {
        val goal = goalDao.getGoalById(goalId) ?: return
        goalDao.deleteGoal(goal)
        auditService.logEvent(
            entityType = "GOAL",
            entityId = goalId,
            action = AuditAction.DELETE,
            payloadBefore = "{ \"title\": \"${goal.title}\" }"
        )
    }
}

// -----------------------------------------------------------------------------
// DEVICE CALENDAR SERVICE
// -----------------------------------------------------------------------------

interface IDeviceCalendarService {
    fun hasCalendarPermission(): Boolean
    fun exportTaskToCalendar(task: TaskEntity): Long?
}

class DeviceCalendarServiceImpl(
    private val context: Context
) : IDeviceCalendarService {

    override fun hasCalendarPermission(): Boolean {
        val readPerm = androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_CALENDAR
        )
        val writePerm = androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.WRITE_CALENDAR
        )
        return readPerm == android.content.pm.PackageManager.PERMISSION_GRANTED &&
                writePerm == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    override fun exportTaskToCalendar(task: TaskEntity): Long? {
        if (!hasCalendarPermission() || task.dueDate == null) return null
        return try {
            val startTime = task.dueDate
            val durationMinutes = task.durationMinutes ?: 60
            val endTime = startTime + (durationMinutes * 60 * 1000L)

            val values = android.content.ContentValues().apply {
                put(android.provider.CalendarContract.Events.DTSTART, startTime)
                put(android.provider.CalendarContract.Events.DTEND, endTime)
                put(android.provider.CalendarContract.Events.TITLE, task.title)
                put(android.provider.CalendarContract.Events.DESCRIPTION, task.description ?: "")
                put(android.provider.CalendarContract.Events.CALENDAR_ID, 1)
                put(
                    android.provider.CalendarContract.Events.EVENT_TIMEZONE,
                    java.util.TimeZone.getDefault().id
                )
            }
            val uri = context.contentResolver.insert(
                android.provider.CalendarContract.Events.CONTENT_URI,
                values
            )
            uri?.lastPathSegment?.toLongOrNull()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

// -----------------------------------------------------------------------------
// TASK REMINDER SCHEDULER
// -----------------------------------------------------------------------------

class TaskReminderScheduler(private val context: Context) {

    fun scheduleExactReminder(taskId: Long, title: String, triggerAtMillis: Long) {
        if (triggerAtMillis <= System.currentTimeMillis()) return
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager
                ?: return
            val intent = android.content.Intent(context, AgentAlarmReceiver::class.java).apply {
                action = "com.example.action.TASK_REMINDER"
                putExtra("task_id", taskId)
                putExtra("task_title", title)
            }
            val flags = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            } else {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
            }
            val pendingIntent = android.app.PendingIntent.getBroadcast(
                context,
                taskId.toInt(),
                intent,
                flags
            )

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    android.app.AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    android.app.AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelReminder(taskId: Long) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager
                ?: return
            val intent = android.content.Intent(context, AgentAlarmReceiver::class.java).apply {
                action = "com.example.action.TASK_REMINDER"
            }
            val flags = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            } else {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
            }
            val pendingIntent = android.app.PendingIntent.getBroadcast(
                context,
                taskId.toInt(),
                intent,
                flags
            )
            alarmManager.cancel(pendingIntent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
