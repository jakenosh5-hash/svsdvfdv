package com.example.services

import android.content.Context
import com.example.data.local.dao.NoteDao
import com.example.data.local.dao.ProjectDao
import com.example.data.local.dao.TaskDao
import com.example.data.local.dao.TemplateDao
import com.example.data.local.entities.*
import com.example.domain.models.AuditAction
import com.example.domain.models.TaskPriority
import com.example.domain.models.TaskStatus
import com.example.domain.models.TimeHorizon
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

interface ITaskService {
    fun getTodayTasks(): Flow<List<TaskEntity>>
    fun getTasksByHorizon(horizon: TimeHorizon): Flow<List<TaskEntity>>
    fun getTasksInDateRange(startTime: Long, endTime: Long): Flow<List<TaskEntity>>
    fun getAllTasks(): Flow<List<TaskEntity>>
    fun getProjects(): Flow<List<ProjectEntity>>
    fun getSubtasks(parentTaskId: Long): Flow<List<TaskEntity>>
    suspend fun getTaskTreeProgress(parentTaskId: Long): Pair<Int, Int> // (completedCount, totalCount)
    
    suspend fun createTask(
        title: String,
        description: String? = null,
        priority: TaskPriority = TaskPriority.IMPORTANT_NOT_URGENT,
        timeHorizon: TimeHorizon = TimeHorizon.DAILY,
        dueDate: Long? = null,
        dueTimeMinutes: Int? = null,
        durationMinutes: Int? = null,
        tags: String? = null,
        projectId: Long? = null,
        parentTaskId: Long? = null,
        templateId: Long? = null,
        isRecurring: Boolean = false,
        recurrenceRule: String? = null,
        customValues: Map<Long, String>? = null,
        imageUri: String? = null,
        reminderTime: Long? = null,
        isReminderEnabled: Boolean = false
    ): Long

    suspend fun updateTaskStatus(taskId: Long, newStatus: TaskStatus)
    suspend fun toggleTaskComplete(taskId: Long)
    suspend fun deleteTask(taskId: Long)
    suspend fun createProject(name: String, description: String?, colorHex: String, iconName: String): Long
    suspend fun archiveProject(projectId: Long)
    fun calculateCalmScore(todayTasks: List<TaskEntity>): Int

    // --- Architectural Extension Points for Dynamic Templates & Custom Fields ---
    fun getAllTemplates(): Flow<List<TaskTemplateEntity>>
    suspend fun getTemplateById(id: Long): TaskTemplateEntity?
    fun getFieldsForTemplate(templateId: Long): Flow<List<TemplateFieldEntity>>
    suspend fun getFieldsForTemplateList(templateId: Long): List<TemplateFieldEntity>
    fun getCustomValuesForTask(taskId: Long): Flow<List<TaskCustomValueEntity>>
    suspend fun getCustomValuesForTaskList(taskId: Long): List<TaskCustomValueEntity>
    suspend fun createTemplate(template: TaskTemplateEntity, fields: List<TemplateFieldEntity>): Long
}

class TaskServiceImpl(
    private val taskDao: TaskDao,
    private val projectDao: ProjectDao,
    private val templateDao: TemplateDao,
    private val auditService: IAuditService,
    private val context: Context? = null
) : ITaskService {

    override fun getTodayTasks(): Flow<List<TaskEntity>> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startOfDay = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        val endOfDay = cal.timeInMillis
        return taskDao.getTodayTasks(startOfDay, endOfDay)
    }

    override fun getTasksByHorizon(horizon: TimeHorizon): Flow<List<TaskEntity>> =
        taskDao.getTasksByHorizon(horizon)

    override fun getTasksInDateRange(startTime: Long, endTime: Long): Flow<List<TaskEntity>> =
        taskDao.getTasksInDateRange(startTime, endTime)

    override fun getAllTasks(): Flow<List<TaskEntity>> = taskDao.getAllTasks()

    override fun getProjects(): Flow<List<ProjectEntity>> = projectDao.getActiveProjects()

    override fun getSubtasks(parentTaskId: Long): Flow<List<TaskEntity>> =
        taskDao.getSubtasks(parentTaskId)

    override suspend fun getTaskTreeProgress(parentTaskId: Long): Pair<Int, Int> {
        val subtasks = taskDao.getSubtasksList(parentTaskId)
        if (subtasks.isEmpty()) return Pair(0, 0)
        val completed = subtasks.count { it.status == TaskStatus.COMPLETED }
        return Pair(completed, subtasks.size)
    }

    override suspend fun createTask(
        title: String,
        description: String?,
        priority: TaskPriority,
        timeHorizon: TimeHorizon,
        dueDate: Long?,
        dueTimeMinutes: Int?,
        durationMinutes: Int?,
        tags: String?,
        projectId: Long?,
        parentTaskId: Long?,
        templateId: Long?,
        isRecurring: Boolean,
        recurrenceRule: String?,
        customValues: Map<Long, String>?,
        imageUri: String?,
        reminderTime: Long?,
        isReminderEnabled: Boolean
    ): Long {
        val task = TaskEntity(
            title = title,
            description = description,
            priority = priority,
            timeHorizon = timeHorizon,
            dueDate = dueDate,
            dueTimeMinutes = dueTimeMinutes,
            durationMinutes = durationMinutes,
            tags = tags,
            projectId = projectId,
            parentTaskId = parentTaskId,
            templateId = templateId,
            isRecurring = isRecurring,
            recurrenceRule = recurrenceRule,
            imageUri = imageUri,
            reminderTime = reminderTime,
            isReminderEnabled = isReminderEnabled
        )
        val id = taskDao.insertTask(task)

        // Schedule exact alarm reminder if enabled
        if (isReminderEnabled && reminderTime != null && reminderTime > System.currentTimeMillis() && context != null) {
            try {
                TaskReminderScheduler(context).scheduleExactReminder(id, title, reminderTime)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Save custom field values if provided
        if (templateId != null && customValues != null && customValues.isNotEmpty()) {
            val entities = customValues.map { (fieldId, valueStr) ->
                TaskCustomValueEntity(
                    taskId = id,
                    fieldId = fieldId,
                    valueText = valueStr,
                    valueNumber = valueStr.toDoubleOrNull()
                )
            }
            templateDao.insertCustomValues(entities)
        }

        auditService.logEvent(
            entityType = "TASK",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"title\": \"$title\", \"priority\": \"$priority\", \"isRecurring\": $isRecurring, \"templateId\": $templateId }"
        )
        return id
    }

    override suspend fun updateTaskStatus(taskId: Long, newStatus: TaskStatus) {
        val current = taskDao.getTaskById(taskId) ?: return
        val completedAt = if (newStatus == TaskStatus.COMPLETED) System.currentTimeMillis() else null
        taskDao.updateTaskStatus(taskId, newStatus, completedAt, System.currentTimeMillis())
        
        // Recurrence Engine: If completed and is recurring, automatically spawn the next instance!
        if (newStatus == TaskStatus.COMPLETED && current.isRecurring && current.recurrenceRule != null) {
            spawnNextRecurrence(current)
        }

        auditService.logEvent(
            entityType = "TASK",
            entityId = taskId,
            action = if (newStatus == TaskStatus.COMPLETED) AuditAction.COMPLETE else AuditAction.UPDATE,
            payloadAfter = "{ \"status\": \"$newStatus\" }"
        )
    }

    private suspend fun spawnNextRecurrence(completedTask: TaskEntity) {
        val currentDue = completedTask.dueDate ?: System.currentTimeMillis()
        val cal = Calendar.getInstance()
        cal.timeInMillis = currentDue

        when (completedTask.recurrenceRule?.uppercase()) {
            "DAILY" -> cal.add(Calendar.DAY_OF_YEAR, 1)
            "WEEKLY" -> cal.add(Calendar.WEEK_OF_YEAR, 1)
            "MONTHLY" -> cal.add(Calendar.MONTH, 1)
            "YEARLY" -> cal.add(Calendar.YEAR, 1)
            else -> cal.add(Calendar.DAY_OF_YEAR, 1)
        }

        val nextTask = completedTask.copy(
            id = 0L,
            status = TaskStatus.PENDING,
            completedAt = null,
            dueDate = cal.timeInMillis,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        val nextId = taskDao.insertTask(nextTask)
        auditService.logEvent(
            entityType = "TASK",
            entityId = nextId,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"action\": \"SPAWN_RECURRENCE\", \"parentRecurrenceTask\": ${completedTask.id} }"
        )
    }

    override suspend fun toggleTaskComplete(taskId: Long) {
        val current = taskDao.getTaskById(taskId) ?: return
        val newStatus = if (current.status == TaskStatus.COMPLETED) TaskStatus.PENDING else TaskStatus.COMPLETED
        updateTaskStatus(taskId, newStatus)
    }

    override suspend fun deleteTask(taskId: Long) {
        val current = taskDao.getTaskById(taskId) ?: return
        taskDao.deleteTask(current)
        auditService.logEvent(
            entityType = "TASK",
            entityId = taskId,
            action = AuditAction.DELETE,
            payloadBefore = "{ \"title\": \"${current.title}\" }"
        )
    }

    override suspend fun createProject(
        name: String,
        description: String?,
        colorHex: String,
        iconName: String
    ): Long {
        val project = ProjectEntity(
            name = name,
            description = description,
            colorHex = colorHex,
            iconName = iconName
        )
        val id = projectDao.insertProject(project)
        auditService.logEvent(
            entityType = "PROJECT",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"name\": \"$name\" }"
        )
        return id
    }

    override suspend fun archiveProject(projectId: Long) {
        val project = projectDao.getProjectById(projectId) ?: return
        val updated = project.copy(status = "ARCHIVED", updatedAt = System.currentTimeMillis())
        projectDao.updateProject(updated)
        auditService.logEvent(
            entityType = "PROJECT",
            entityId = projectId,
            action = AuditAction.UPDATE,
            payloadAfter = "{ \"status\": \"ARCHIVED\" }"
        )
    }

    override fun calculateCalmScore(todayTasks: List<TaskEntity>): Int {
        if (todayTasks.isEmpty()) return 100 // Clean slate, peace of mind

        val total = todayTasks.size
        val completed = todayTasks.count { it.status == TaskStatus.COMPLETED }
        val completionRate = (completed.toFloat() / total.toFloat()) * 50f

        val loadPoints = when {
            total in 1..5 -> 35f
            total in 6..8 -> 25f
            total in 9..12 -> 15f
            else -> 5f // Too many tasks, chronic feeling of busyness
        }

        val urgentImportant = todayTasks.filter { it.priority == TaskPriority.URGENT_IMPORTANT }
        val urgentScore = if (urgentImportant.isEmpty()) {
            15f
        } else {
            val completedUrgent = urgentImportant.count { it.status == TaskStatus.COMPLETED }
            (completedUrgent.toFloat() / urgentImportant.size.toFloat()) * 15f
        }

        return (completionRate + loadPoints + urgentScore).toInt().coerceIn(0, 100)
    }

    // --- Template Extension Points ---
    override fun getAllTemplates(): Flow<List<TaskTemplateEntity>> =
        templateDao.getAllTemplates()

    override suspend fun getTemplateById(id: Long): TaskTemplateEntity? =
        templateDao.getTemplateById(id)

    override fun getFieldsForTemplate(templateId: Long): Flow<List<TemplateFieldEntity>> =
        templateDao.getFieldsForTemplate(templateId)

    override suspend fun getFieldsForTemplateList(templateId: Long): List<TemplateFieldEntity> =
        templateDao.getFieldsForTemplateList(templateId)

    override fun getCustomValuesForTask(taskId: Long): Flow<List<TaskCustomValueEntity>> =
        templateDao.getCustomValuesForTask(taskId)

    override suspend fun getCustomValuesForTaskList(taskId: Long): List<TaskCustomValueEntity> =
        templateDao.getCustomValuesForTaskList(taskId)

    override suspend fun createTemplate(
        template: TaskTemplateEntity,
        fields: List<TemplateFieldEntity>
    ): Long {
        val templateId = templateDao.insertTemplate(template)
        val fieldsWithId = fields.map { it.copy(templateId = templateId) }
        templateDao.insertFields(fieldsWithId)
        auditService.logEvent(
            entityType = "TASK_TEMPLATE",
            entityId = templateId,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"name\": \"${template.name}\", \"fieldsCount\": ${fields.size} }"
        )
        return templateId
    }
}

interface INoteService {
    fun getActiveNotes(): Flow<List<NoteEntity>>
    fun searchNotes(query: String): Flow<List<NoteEntity>>
    suspend fun saveNote(
        title: String,
        contentMarkdown: String,
        tags: String? = null,
        projectId: Long? = null,
        taskId: Long? = null,
        debtId: Long? = null
    ): Long
    suspend fun togglePinNote(noteId: Long)
    suspend fun archiveNote(noteId: Long)
    suspend fun deleteNote(noteId: Long)
}

class NoteServiceImpl(
    private val noteDao: NoteDao,
    private val auditService: IAuditService
) : INoteService {
    override fun getActiveNotes(): Flow<List<NoteEntity>> = noteDao.getActiveNotes()
    override fun searchNotes(query: String): Flow<List<NoteEntity>> = noteDao.searchNotes(query)

    override suspend fun saveNote(
        title: String,
        contentMarkdown: String,
        tags: String?,
        projectId: Long?,
        taskId: Long?,
        debtId: Long?
    ): Long {
        val note = NoteEntity(
            title = title,
            contentMarkdown = contentMarkdown,
            tags = tags,
            projectId = projectId,
            taskId = taskId,
            debtId = debtId
        )
        val id = noteDao.insertNote(note)
        auditService.logEvent(
            entityType = "NOTE",
            entityId = id,
            action = AuditAction.CREATE,
            payloadAfter = "{ \"title\": \"$title\" }"
        )
        return id
    }

    override suspend fun togglePinNote(noteId: Long) {
        val note = noteDao.getNoteById(noteId) ?: return
        val updated = note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis())
        noteDao.updateNote(updated)
        auditService.logEvent(
            entityType = "NOTE",
            entityId = noteId,
            action = AuditAction.UPDATE,
            payloadAfter = "{ \"isPinned\": ${updated.isPinned} }"
        )
    }

    override suspend fun archiveNote(noteId: Long) {
        val note = noteDao.getNoteById(noteId) ?: return
        val updated = note.copy(isArchived = true, updatedAt = System.currentTimeMillis())
        noteDao.updateNote(updated)
        auditService.logEvent(
            entityType = "NOTE",
            entityId = noteId,
            action = AuditAction.UPDATE,
            payloadAfter = "{ \"isArchived\": true }"
        )
    }

    override suspend fun deleteNote(noteId: Long) {
        val note = noteDao.getNoteById(noteId) ?: return
        noteDao.deleteNote(note)
        auditService.logEvent(
            entityType = "NOTE",
            entityId = noteId,
            action = AuditAction.DELETE,
            payloadBefore = "{ \"title\": \"${note.title}\" }"
        )
    }
}
