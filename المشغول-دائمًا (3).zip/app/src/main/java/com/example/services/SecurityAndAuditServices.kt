package com.example.services

import com.example.data.local.dao.AuditLogDao
import com.example.data.local.dao.SecurityScopeDao
import com.example.data.local.entities.AuditLogEntity
import com.example.data.local.entities.SecurityScopeEntity
import com.example.domain.models.AuditAction
import com.example.domain.models.AuditActor
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

interface IAuditService {
    suspend fun logEvent(
        entityType: String,
        entityId: Long,
        action: AuditAction,
        actor: AuditActor = AuditActor.USER,
        payloadBefore: String? = null,
        payloadAfter: String? = null
    ): Long

    fun getRecentLogs(): Flow<List<AuditLogEntity>>
    fun getLogsForEntity(entityType: String, entityId: Long): Flow<List<AuditLogEntity>>
}

class AuditServiceImpl(private val dao: AuditLogDao) : IAuditService {
    override suspend fun logEvent(
        entityType: String,
        entityId: Long,
        action: AuditAction,
        actor: AuditActor,
        payloadBefore: String?,
        payloadAfter: String?
    ): Long = dao.insertAuditLog(
        AuditLogEntity(
            entityType = entityType,
            entityId = entityId,
            action = action,
            actor = actor,
            payloadBeforeJson = payloadBefore,
            payloadAfterJson = payloadAfter
        )
    )

    override fun getRecentLogs(): Flow<List<AuditLogEntity>> = dao.getRecentAuditLogs()

    override fun getLogsForEntity(entityType: String, entityId: Long): Flow<List<AuditLogEntity>> =
        dao.getLogsForEntity(entityType, entityId)
}

interface ISecurityScopeService {
    fun getAllScopes(): Flow<List<SecurityScopeEntity>>
    suspend fun isScopeGranted(scopeName: String): Boolean
    suspend fun setScopeGranted(scopeName: String, isGranted: Boolean)
}

class SecurityScopeServiceImpl(private val dao: SecurityScopeDao) : ISecurityScopeService {
    override fun getAllScopes(): Flow<List<SecurityScopeEntity>> = dao.getAllScopes()

    override suspend fun isScopeGranted(scopeName: String): Boolean =
        dao.getScope(scopeName)?.isGranted ?: false

    override suspend fun setScopeGranted(scopeName: String, isGranted: Boolean) {
        val current = dao.getScope(scopeName)
        if (current != null) {
            dao.updateScope(current.copy(isGranted = isGranted, grantedAt = System.currentTimeMillis()))
        } else {
            dao.insertScope(
                SecurityScopeEntity(
                    scopeName = scopeName,
                    description = "صلاحية مضافة يدويًا",
                    isGranted = isGranted
                )
            )
        }
    }
}

fun IAuditService.recentAuditSnapshot(limit: Int = 20): String =
    "سجل التدقيق متاح محليًا؛ عدد الأحداث الأخيرة المطلوب عرضها: $limit"
