package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette (P1-T02: Emerald Clean Architecture)
val EmeraldDarkPrimary = Color(0xFF1B5E20)
val EmeraldMediumSecondary = Color(0xFF2E7D32)
val EmeraldLightTertiary = Color(0xFF4CAF50)
val EmeraldMintAccent = Color(0xFF81C784)
val EmeraldSoftContainer = Color(0xFFE8F5E9)

val PureWhiteBackground = Color(0xFFFFFFFF)
val CleanLightSurface = Color(0xFFF8FAF9)
val CleanLightSurfaceVariant = Color(0xFFEFF3F1)

val TextPrimaryDark = Color(0xFF191C1B)
val TextSecondaryDark = Color(0xFF404944)
val OutlineLight = Color(0xFF707973)

// Dark Palette (P1-T02: Dark Luxury Emerald)
val DarkBackground = Color(0xFF111413)
val DarkSurface = Color(0xFF1A1F1D)
val DarkSurfaceVariant = Color(0xFF242A27)

val DarkEmeraldPrimary = Color(0xFF81C784)
val DarkEmeraldSecondary = Color(0xFFA5D6A7)
val DarkEmeraldTertiary = Color(0xFFC8E6C9)

val TextPrimaryLight = Color(0xFFE1E3DF)
val TextSecondaryLight = Color(0xFFC0C8C3)
val OutlineDark = Color(0xFF8A938D)

// Status & Indicators
val StateSuccess = Color(0xFF2E7D32)
val StateError = Color(0xFFBA1A1A)
val StateWarning = Color(0xFFE65100)
val StateInfo = Color(0xFF0277BD)

// Legacy compatibility aliases
val Purple80 = DarkEmeraldPrimary
val PurpleGrey80 = DarkEmeraldSecondary
val Pink80 = DarkEmeraldTertiary
val Purple40 = EmeraldDarkPrimary
val PurpleGrey40 = EmeraldMediumSecondary
val Pink40 = EmeraldLightTertiary
