package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DarkEmeraldPrimary,
    onPrimary = Color(0xFF00390E),
    primaryContainer = Color(0xFF005318),
    onPrimaryContainer = Color(0xFF9DF7A2),
    secondary = DarkEmeraldSecondary,
    onSecondary = Color(0xFF1E3523),
    secondaryContainer = Color(0xFF344C38),
    onSecondaryContainer = Color(0xFFCEECCF),
    tertiary = DarkEmeraldTertiary,
    background = DarkBackground,
    onBackground = TextPrimaryLight,
    surface = DarkSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = OutlineDark,
    error = StateError
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldMediumSecondary,
    onPrimary = Color.White,
    primaryContainer = EmeraldSoftContainer,
    onPrimaryContainer = Color(0xFF002106),
    secondary = EmeraldDarkPrimary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD6E8D6),
    onSecondaryContainer = Color(0xFF0F1F13),
    tertiary = EmeraldLightTertiary,
    background = CleanLightSurface,
    onBackground = TextPrimaryDark,
    surface = PureWhiteBackground,
    onSurface = TextPrimaryDark,
    surfaceVariant = CleanLightSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = OutlineLight,
    error = StateError
)

@Composable
fun AlwaysBusyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Preserve bespoke Emerald theme by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    AlwaysBusyTheme(
        darkTheme = darkTheme,
        dynamicColor = dynamicColor,
        content = content
    )
}
