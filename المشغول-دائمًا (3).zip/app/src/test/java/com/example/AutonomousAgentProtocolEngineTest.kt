package com.example

import com.example.domain.agent.AutonomousAgentProtocolEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AutonomousAgentProtocolEngineTest {
    @Test
    fun `parses user message and executable actions without leaking protocol`() {
        val result = AutonomousAgentProtocolEngine.parseResponse(
            """
            <<<USER_MESSAGE>>>
            تم تسجيل المهمة بنجاح.
            <<<END_USER_MESSAGE>>>
            <<<BOT_ACTIONS>>>
            MEMORY_STORE: index="العمل" section="المهام" query="طلب" summary="إنشاء مهمة" importance=8 tags="مهمة"
            APP_EXECUTE: task add "مراجعة الخطة" priority:high
            <<<END_BOT_ACTIONS>>>
            """.trimIndent()
        )

        assertEquals("تم تسجيل المهمة بنجاح.", result.userMessage)
        assertEquals(2, result.actions.size)
        assertTrue(result.actions.any { it is AutonomousAgentProtocolEngine.AgentAction.MemoryStore })
        assertTrue(result.actions.any { it is AutonomousAgentProtocolEngine.AgentAction.AppExecute })
        assertTrue(!result.userMessage.contains("BOT_ACTIONS"))
    }

    @Test
    fun `removes unclosed action block from visible response`() {
        val result = AutonomousAgentProtocolEngine.parseResponse(
            "رد واضح للمستخدم\n<<<BOT_ACTIONS>>>\nAPP_EXECUTE: destructive command"
        )

        assertEquals("رد واضح للمستخدم", result.userMessage)
        assertTrue(result.actions.isEmpty())
    }

    @Test
    fun `recognizes search as follow up action`() {
        val result = AutonomousAgentProtocolEngine.parseResponse(
            """
            <<<USER_MESSAGE>>>سأبحث في ذاكرتك.<<<END_USER_MESSAGE>>>
            <<<BOT_ACTIONS>>>
            INDEX_SEARCH: query="ميزانية الشهر"
            <<<END_BOT_ACTIONS>>>
            """.trimIndent()
        )

        assertTrue(result.requiresFollowUp)
        assertTrue(result.searchOrFetchAction is AutonomousAgentProtocolEngine.AgentAction.IndexSearch)
    }
}
