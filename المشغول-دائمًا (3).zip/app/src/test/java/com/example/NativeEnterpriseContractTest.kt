package com.example

import com.example.domain.agent.AutonomousAgentProtocolEngine
import com.example.domain.gateway.ToolCallingSchemas
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** Pure JVM contract tests; no network, API keys, or Gradle build required to inspect the rules. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NativeEnterpriseContractTest {
    @Test
    fun protocolNeverLeaksInternalActionBlocks() {
        val parsed = AutonomousAgentProtocolEngine.parseResponse(
            """<<<USER_MESSAGE>>>تم<<<END_USER_MESSAGE>>>
                <<<BOT_ACTIONS>>>APP_EXECUTE: finance expense 10 currency:SYP category:عام<<<END_BOT_ACTIONS>>>"""
        )
        assertTrue(parsed.userMessage == "تم")
        assertFalse(parsed.userMessage.contains("BOT_ACTIONS"))
        assertTrue(parsed.actions.isNotEmpty())
    }

    @Test
    fun toolCatalogUsesRequiredFieldsForFinancialWrites() {
        val tools = ToolCallingSchemas.getAllToolDefinitions()
        assertTrue(tools.contains("record_transaction"))
        assertTrue(tools.contains("amount"))
        assertTrue(tools.contains("currency"))
        assertTrue(tools.contains("required"))
    }

    @Test
    fun malformedFinancialInputIsNotConvertedToDefaultAmount() {
        val input = "سجل مصروف"
        val amount = input.removePrefix("سجل مصروف").trim().split(" ").firstOrNull()?.toDoubleOrNull()
        assertTrue(amount == null)
    }
}
