# الخطة الهندسية Enterprise Grade النهائية
## Always Busy Life OS — Autonomous Proactive AI Platform

## 0. الغرض من هذه الوثيقة

هذه الوثيقة هي **المرجع الوحيد للتنفيذ**. تجمع متطلبات آخر ست رسائل، وتفصل بوضوح بين:

- ما يجب الحفاظ عليه.
- ما يجب إصلاحه.
- ما يجب إخفاؤه من UI العادي دون حذفه.
- ما يجب إزالته لأنه سلوك غير مرغوب.
- ما يجب إضافته لتحقيق الوكيل الاستباقي الحقيقي.
- شروط القبول التي تمنع إعلان نجاح وهمي.

المشروع Android Native، والمطلوب ليس Chat UI فقط. المطلوب منصة وكيل شخصي استباقي يعمل من الخلفية، يتواصل مع LLM عبر API، يقرأ ويبحث ويلخص وينظم وينفذ ويتابع ويصدر إشعارات مولدة من الذكاء، حتى عند إغلاق التطبيق.

## 1. تعريف المنتج النهائي

```text
Always Busy Life OS
= تطبيق إنتاجية محلي
+ عقل AI عبر API
+ وكيل تنفيذي خلفي
+ ذاكرة وفهارس خاصة
+ خطط متعددة الخطوات
+ جدولة ومتابعة
+ إشعارات يولد محتواها الذكاء
+ رد تفاعلي من Notification
+ شخصيتان مستقلتان REM وRAM
+ وصول كامل للقدرات المفوضة
+ تشغيل قابل للاستئناف والاعتماد
```

### 1.1 ما يراه المستخدم

- محادثة شبيهة بـTelegram.
- فقاعات رسائل.
- Copy.
- Reply.
- تحديد وضغط مطول.
- حالات الإرسال والفشل وإعادة المحاولة.
- رسائل الذكاء النهائية.
- حالة عامة مثل “أراجع بياناتك” دون كشف العقل الداخلي.
- إشعارات بأسلوب الرسائل.
- Reply من لوحة الإشعارات.
- أزرار `I'm busy now`, `Snooze`, `Mark as read` عند قرار الذكاء بإظهارها.

### 1.2 ما يعمل في الخلفية ولا يظهر للمستخدم العادي

- System Prompt.
- Reasoning الخام.
- الذاكرة.
- الفهارس والأبواب.
- Observation records.
- Tool arguments الحساسة.
- نتائج البحث الداخلية.
- سجل التدقيق التفصيلي.
- حالة Job الداخلية.
- مخططات الخطط.
- مفاتيح API.
- ترتيب Failover للمفاتيح.
- تفاصيل provider/model الداخلية.

تظل هذه الأشياء محفوظة ويجوز عرضها في شاشة Developer/Admin منفصلة إذا احتاجها المطور، لكنها لا تحذف ولا تُعرض في تجربة المستخدم العادية.

## 2. مصفوفة التوافق مع آخر ست رسائل

### المتطلب 1: فحص عميق لاختصار أو تخمين

**القرار:** كل مرحلة لها ملفات ورموز واختبارات. لا يُقبل وصف “تم” دون دليل بناء أو اختبار.

**تنفيذ:**

- ملف/دالة مستهدفة لكل بند.
- تقرير diff.
- تقرير declarations/usages.
- مخرجات Gradle.
- اختبارات Worker وRoom وNotification وLLM.

### المتطلب 2: العقل والذاكرة والفهارس خلفية

**القرار:** الحفاظ على البيانات والخدمات، لكن فصلها عن UI العادي.

**لا يُحذف:**

- `AutonomousKnowledgeService`.
- `CumulativeMemoryEngine`.
- `AiMemoryItemEntity`.
- Knowledge indexes/sections.
- Audit/Scopes/Backup.

**يتغير:**

- لا تُمرر raw memory أو catalog أو reasoning إلى Composable الإنتاجي.
- تُنقل أدوات الإدارة إلى Developer/Admin surface أو تبقى خلف feature flag.

### المتطلب 3: AI يستطيع إرسال أوامر للتطبيق بلا Dialog لكل عملية

**القرار:** إزالة confirmation التفاعلي من مسار الوكيل المفوض، وليس إزالة validation.

**يبقى:**

- Schema validation.
- Business validation.
- Idempotency.
- Transaction.
- Audit actor = `AI_AGENT`.
- Limits داخلية.
- Kill switch.
- Dead-letter.

**يُزال من Autonomous Path:**

- `NeedsConfirmation` كشرط لكل عملية.
- UI Dialog للعمليات التي فوض بها `FULL_AUTONOMOUS`.

### المتطلب 4: الذاكرة تعود كملخص من API ثم يصنفها التطبيق ويخزنها

**القرار:** هذا هو المسار الأساسي.

```text
LLM retrieves
→ LLM returns MemorySummary
→ app validates source references
→ app selects index/section/category
→ app stores summary
→ no user confirmation
→ no normal UI exposure
```

المسار المحلي الحالي في `CumulativeMemoryEngine` الذي يعتمد على كلمات مثل “أفضل/عادة/قررت” يصبح fallback محدودًا أو يزال من التخزين التلقائي بعد تشغيل المسار الجديد. لا يجوز وجود مسارين يتصارعان على الذاكرة دون سياسة واضحة.

### المتطلب 5: الوكيل يملك صلاحية واسعة ويتواصل مع التطبيق قدر الحاجة

**القرار:** بناء `AgentPermissionProfile.FULL_AUTONOMOUS` ودورة Tool Loop متعددة الخطوات.

“قدر الحاجة” يعني:

- عدد متغير من Tool Calls.
- observations متتابعة.
- متابعة حتى final response أو stop condition.
- لا loop لا نهائية.
- لا حد مصطنع باستدعاءين فقط.

### المتطلب 6: الإشعار نفسه يولد عبر طلب LLM

**القرار:** Notification ليست Template ثابتة.

```text
Trigger
→ AgentJob(SCHEDULE_TRIGGER)
→ private context
→ LLM
→ Tool Calls عند الحاجة
→ NotificationPlan
→ validator
→ publisher
```

الذكاء يقرر:

- هل يُرسل إشعارًا.
- عنوانه ونصه ونبرته.
- هل يظهر Reply.
- هل يظهر `I'm busy now`.
- هل يؤجل.
- هل ينفذ شيئًا قبل الإشعار.
- هل ينشئ متابعة جديدة.

### المتطلب 7: مهمة بعد عدة ساعات وتطبيق مغلق

**القرار:**

- `AlarmManager` للحدث الزمني.
- `BroadcastReceiver` لاستقبال الحدث.
- `WorkManager CoroutineWorker` للاتصال وLLM.
- Room لحالة المهمة.
- Boot/timezone recovery.
- Exact/inexact fallback.

### المتطلب 8: Reply من لوحة الإشعارات

**القرار:**

```text
RemoteInput
→ NotificationReplyReceiver
→ AgentJob(NOTIFICATION_REPLY)
→ LLM
→ Tool Calls عند الحاجة
→ NotificationPlan جديدة
→ تحديث Notification + conversation
```

### المتطلب 9: `I'm busy now`

**القرار:** Event حقيقي إلى الوكيل:

```json
{
  "event": "USER_BUSY",
  "scheduled_task_id": 42,
  "conversation_id": 17,
  "message": "I'm busy now",
  "requested_action": "continue_later"
}
```

لا يكون مجرد `onClick` يغير النص محليًا.

### المتطلب 10: ثلاث مفاتيح لـREM وثلاثة لـRAM

**القرار:** نعم، هذا أفضل من pool واحد عالمي، بشرط أن تكون العزلة حقيقية.

المصدر الحالي يحتوي قائمة مفاتيح عامة مع Failover، و`activePersona` عامة، وconversation persona، لكنه لا يملك pool مستقلًا لكل شخصية. يجب تطويره إلى ملفي مزود مستقلين:

```text
REM profile: 3 keys
RAM profile: 3 keys
```

مع Failover وCooldown مستقل لكل شخصية.

## 3. ما الذي لا يجوز حذفه

### 3.1 وظائف التطبيق الأساسية

لا تحذف أيًا من:

- المهام.
- المشاريع.
- القوالب.
- الحقول المخصصة.
- الملاحظات.
- الأهداف.
- تتبع الوقت.
- التقويم.
- المالية.
- الأصول والميزانيات.
- الديون.
- التذكيرات.
- النسخ والاستعادة.
- الملاحظات المعرفية.
- المحادثات.
- الرسائل.
- Copy/Reply.
- Scopes/Audit.
- Backup.
- Rem/Ram profiles.

### 3.2 مكونات AI

لا تحذف باعتبارها غير ضرورية:

- `AutonomousAgentCoordinator`.
- `AutonomousAgentProtocolEngine`.
- `CumulativeMemoryEngine`.
- `AutonomousKnowledgeService`.
- `AppInternalGateway`.
- `CommandBus`.
- `AiToolCallDispatcher`.
- `ToolCallingSchemas`.
- `LlmApiClient`.
- `AiAutomationServiceImpl`.

لكن بعضها سيعاد توصيله أو يتحول إلى facade أو يُستبدل تدريجيًا بعد إثبات البديل، مع إبقاء الوظيفة لا الاسم.

### 3.3 واجهات الإدارة

لا تحذف شاشة المعرفة أو Terminal أو Scopes/Audit من المصدر. إذا كان المقصود إخفاءها عن المستخدم العادي:

- انقلها إلى Developer/Admin mode.
- أو اجعلها خلف Build flag/role.
- أو افصلها عن شاشة المحادثة.

المطلوب **إخفاء العرض العادي**، وليس فقدان وظائف الإدارة.

## 4. ما الذي يزال أو يتغير فقط لأنه غير مرغوب

هذه ليست وظائف يريد المستخدم الاحتفاظ بها، بل سلوكيات يجب إزالتها:

1. confirmation التفاعلي لكل Tool Call.
2. عرض memory/index/reasoning في UI العادي.
3. fallback AI النصي الثابت كمسار إنتاجي.
4. Regex protocol كمسار نهائي وحيد بعد بناء Tool Calling الحقيقي.
5. افتراض مبلغ `10000` عند نقص البيانات.
6. إعلان “تم التنفيذ” دون نتيجة فعلية.
7. استخدام Coroutine داخل Activity كحل خلفي.
8. `fallbackToDestructiveMigration()` في الإنتاج.
9. إيقاف البيومترية وفتح الجلسة تلقائيًا في `DashboardViewModel` إذا كان ذلك سلوكًا غير مقصود.
10. تخزين مفاتيح API غير محمية.

كل حذف أو deprecation يجب أن يكون في diff موثق، مع اختبار أن الوظيفة المرادفة ما زالت موجودة.

## 5. المعمارية النهائية

```text
┌──────────────────────────────────────────────────────────────┐
│ User surfaces                                                │
│ Chat UI / Notification / RemoteInput / FCM                  │
└──────────────────────────────┬───────────────────────────────┘
                               │ enqueue only
┌──────────────────────────────▼───────────────────────────────┐
│ Agent Runtime                                                 │
│ AgentRuntime / JobQueue / Worker / Lease / Retry / Cancel    │
└──────────────────────────────┬───────────────────────────────┘
                               │
┌──────────────────────────────▼───────────────────────────────┐
│ Turn Orchestrator                                             │
│ Context → LLM → Tool Calls → Observations → Follow-up Loop   │
└──────────────────────────────┬───────────────────────────────┘
                               │
┌──────────────────────────────▼───────────────────────────────┐
│ LLM Gateway                                                   │
│ Persona profile / provider / model / 3-key failover           │
│ Structured tools / tool results / retry / timeout             │
└──────────────────────────────┬───────────────────────────────┘
                               │
┌──────────────────────────────▼───────────────────────────────┐
│ Tool Registry + Policy                                        │
│ Typed schemas / validation / idempotency / audit              │
└──────────────────────────────┬───────────────────────────────┘
                               │
┌──────────────────────────────▼───────────────────────────────┐
│ Internal Capability Gateway                                   │
│ Tasks / Projects / Finance / Debts / Notes / Goals / Time     │
│ Calendar / Templates / Memory / Knowledge / Plans / Notify    │
└──────────────────────────────┬───────────────────────────────┘
                               │
┌──────────────────────────────▼───────────────────────────────┐
│ Room + Android runtime                                        │
│ State / migrations / alarms / workers / notifications / audit  │
└──────────────────────────────────────────────────────────────┘
```

## 6. تقسيم REM وRAM ومفاتيح API

### 6.1 الوضع الحالي المثبت

`AiPreferences.kt` يحتوي:

- قائمة مفاتيح عامة `getActiveKeys()`.
- `saveThreeKeySlots()`.
- `getThreeKeySlots()`.
- `saveKeySlots(List<String>)`.
- Failover وdemotion لمدة 18 ساعة.
- `activePersona` واحدة عامة.
- provider/baseUrl/model واحدة عامة.

هذا يعني أن الوضع الحالي لا يعزل REM عن RAM. تغيير الشخصية لا يختار pool مستقلًا.

### 6.2 التصميم المطلوب

إنشاء profile لكل شخصية:

```kotlin
enum class AiPersona {
    REM,
    RAM
}

data class PersonaAiProfile(
    val persona: AiPersona,
    val provider: String,
    val baseUrl: String,
    val model: String,
    val keySlots: List<SecureApiKeySlot>,
    val autonomousEnabled: Boolean,
    val maxIterations: Int,
    val notificationEnabled: Boolean
)
```

يفضل تخزينها في Room/Encrypted storage بدل SharedPreferences العامة، مع encryption لكل key.

### 6.3 جدول المفاتيح

```text
ai_persona_profiles
- persona PRIMARY KEY
- provider
- base_url
- model
- active
- max_iterations
- notification_enabled
- created_at
- updated_at

ai_persona_api_keys
- id
- persona
- slot_index 0..2
- encrypted_key
- fingerprint
- status ACTIVE | DEMOTED | INVALID | DISABLED
- failure_count
- demoted_at
- last_success_at
- created_at
- updated_at
UNIQUE(persona, slot_index)
```

### 6.4 قواعد REM/RAM

- REM تملك 3 slots مستقلة.
- RAM تملك 3 slots مستقلة.
- لا يشارك Failover حالة الشخصية الأخرى.
- فشل مفتاح REM لا يغير RAM.
- Cooldown مستقل لكل profile/key.
- Provider/model/baseUrl يمكن أن تكون مستقلة لكل شخصية.
- كل conversation تحفظ persona وقت الإنشاء.
- كل AgentJob تحفظ persona حتى لا يرسل الرد إلى pool خاطئ بعد تبديل الشخصية.
- كل Notification تحفظ persona وconversationId.
- اختيار الشخصية من UI يغير المحادثة الجديدة، ولا يغير هوية Job قيد التشغيل.
- Worker يستعيد profile من `job.persona`, وليس من `activePersona` الحالية.
- RAM وREM يمكن تشغيلهما بالتوازي مع limits مستقلة.
- إذا لم يملك profile أي مفتاح، يظهر فشل واضح ويستخدم fallback غير AI معلّم، لا يتم استخدام مفتاح الشخصية الأخرى تلقائيًا إلا بسياسة صريحة.

### 6.5 هل 3+3 أفضل؟

نعم، لأسباب Enterprise:

- عزل فشل provider.
- عزل الحصة والاستهلاك.
- عزل شخصية REM عن RAM.
- منع تبديل personality من تغيير مسار Job قائم.
- إمكانية نموذج مختلف لكل شخصية.
- إمكانية سياسة notification مختلفة.
- تتبع استخدام كل شخصية.
- تدوير أسرار مستقل.

لكن يجب الانتباه: ستة مفاتيح لا تعني ستة نماذج أو ستة حسابات بالضرورة؛ هذا يعتمد على provider. النظام يجب أن يقبل مزودًا/نموذجًا واحدًا لكل profile مع 3 مفاتيح، أو يتيح provider/model لكل slot مستقبلًا إذا احتجنا failover بين providers.

### 6.6 API key security

- لا تحط المفتاح في `BuildConfig` للإنتاج.
- لا تسجل المفتاح في logs.
- لا تعرضه كاملًا في UI.
- استخدم Android Keystore لتشفير التخزين.
- اعرض fingerprint وآخر 4 أحرف فقط.
- لا تضع مفاتيح REM في Prompt أو Notification.
- عند تسريب مفتاح سابق، ألغِه وأصدر مفاتيح جديدة.
- كل طلب يحمل correlation ID لا secret.

## 7. Agent Jobs والخطط

### 7.1 AgentJob

```text
id
persona
conversationId
jobType
sourceId
status
priority
runAfter
attempt
maxAttempts
leaseUntil
idempotencyKey
networkRequired
lastError
createdAt
updatedAt
```

### 7.2 ScheduledAgentTask

```text
id
persona
conversationId
planId
title
instruction
conditionJson
scheduledAt
timezone
repeatRule
status
soundProfile
notificationMode
requiresNetwork
nextRunAt
lastTriggeredAt
attemptCount
maxAttempts
createdBy
createdAt
updatedAt
```

### 7.3 AgentPlan

```text
id
persona
conversationId
goal
stepsJson
currentStep
state
nextCheckAt
successCriteriaJson
failurePolicyJson
createdBy
updatedAt
```

الحالات:

```text
DRAFT
ACTIVE
WAITING_TIME
WAITING_EVENT
WAITING_REPLY
RUNNING
PAUSED
COMPLETED
FAILED
CANCELLED
```

## 8. Real Tool Calling

### 8.1 LLM request

```json
{
  "model": "persona-profile-model",
  "messages": [],
  "tools": [],
  "tool_choice": "auto",
  "temperature": 0.2,
  "stream": false
}
```

### 8.2 LLM response

يجب دعم:

- final content.
- one or multiple tool calls.
- provider-specific tool call formats.
- malformed JSON handling.
- refusal/error content.
- response correlation.

### 8.3 دورة التنفيذ

```text
create turn
→ select job persona
→ load that persona profile
→ build private context
→ send tools
→ receive final/tool_calls
→ validate schema
→ registry lookup
→ internal authorization
→ idempotency
→ Room transaction
→ audit AI_AGENT
→ persist ToolResult
→ send result to same LLM turn
→ continue
→ produce final response or NotificationPlan
```

### 8.4 أدوات القدرات

#### Read

```text
get_system_snapshot
search_tasks
get_task
search_projects
search_finance
get_balance
search_debts
search_notes
search_goals
search_time_entries
search_calendar
search_templates
search_knowledge
search_memories
search_conversations
get_plan_state
get_audit_summary
```

#### Write

```text
create_task
update_task
complete_task
delete_task
create_project
update_project
create_note
update_note
store_memory_summary
create_knowledge_index
create_knowledge_section
update_goal
create_time_entry
```

#### Schedule/plan

```text
create_scheduled_agent_task
update_scheduled_agent_task
cancel_scheduled_agent_task
snooze_scheduled_agent_task
list_scheduled_agent_tasks
create_follow_up_plan
pause_plan
resume_plan
complete_plan
```

#### Notification

```text
create_notification_plan
send_notification_message
ask_user_via_notification
process_notification_reply
mark_agent_message_read
```

#### Finance/debt

```text
record_transaction
update_exchange_rate
create_debt
record_debt_payment
```

كل أداة typed ومحددة في Registry. لا تستخدم `APP_EXECUTE` كنص حر في النسخة النهائية إلا كطبقة توافق مؤقتة أثناء migration، مع deprecation وtests.

## 9. NotificationPlan مولدة من الذكاء

### 9.1 العقد

```json
{
  "decision": "NOTIFY",
  "title": "مراجعة خطة المشروع",
  "body": "راجعت حالة الخطة، وهناك مهمتان مفتوحتان. هل نكمل الآن؟",
  "tone": "CALM_SUPPORTIVE",
  "conversation_id": 17,
  "persona": "REM",
  "scheduled_task_id": 42,
  "notification_mode": "MESSAGE_WITH_REPLY",
  "actions": [
    {"id":"reply","type":"REMOTE_INPUT","label":"Reply"},
    {"id":"busy","type":"SEND_EVENT","label":"I'm busy now","event":"USER_BUSY"},
    {"id":"snooze","type":"SNOOZE","label":"Snooze"}
  ],
  "next_follow_up": {"enabled":true,"after_minutes":120}
}
```

### 9.2 القرارات

```text
NOTIFY
NO_NOTIFICATION
ASK
EXECUTE_THEN_NOTIFY
RESCHEDULE
FAILED
```

### 9.3 Publisher

`NotificationPublisher` ينفذ NotificationPlan فقط. لا يؤلف النص للسيناريوهات الأساسية.

Fallback عند فشل API:

- محدود.
- معلّم `AI_UNAVAILABLE` داخليًا.
- لا يدعي أنه من الذكاء.
- لا يقرر خطة إنتاجية معقدة.
- يسجل السبب ويعيد المحاولة.

## 10. مثال كامل: التذكير بعد ساعات

```text
User says: ذكريني بعد أربع ساعات بمراجعة خطة المشروع
        ↓
LLM tool_call create_scheduled_agent_task
        ↓
App saves task + plan + persona + conversation
        ↓
Scheduler registers alarm
        ↓
App closes
        ↓
AlarmReceiver wakes
        ↓
Worker claims job with lease/idempotency
        ↓
Worker loads REM or RAM profile saved on task
        ↓
Context builder retrieves current plan/tasks/results
        ↓
LLM decides notification and content
        ↓
If needed, tool calls inspect or update data
        ↓
LLM returns NotificationPlan
        ↓
Validator checks plan
        ↓
Notification shown
        ↓
Reply/Busy/Snooze becomes new AgentJob
        ↓
Same persona/profile handles follow-up
```

## 11. Android background requirements

### 11.1 AlarmManager

- للموعد الزمني.
- exact فقط عندما تكون الدقة جوهرية.
- `canScheduleExactAlarms()`.
- `SCHEDULE_EXACT_ALARM` عند الحاجة.
- fallback إلى inexact عند الرفض.
- لا تنفذ LLM داخل Receiver.

### 11.2 WorkManager

- `CoroutineWorker` للاتصال بالـAPI.
- unique work لكل Job.
- retry/backoff.
- network constraint.
- input/output محدودان، والحالة التفصيلية في Room.
- long-running worker إذا احتاجت دورة أطول.

### 11.3 Recovery

- `BOOT_COMPLETED`.
- time/timezone change.
- app update.
- exact permission state change.
- database restore.
- إعادة جدولة كل SCHEDULED وWAITING jobs.
- عدم الاعتماد على Timer في الذاكرة.

## 12. Notification Reply

```text
Notification.Action.Builder
→ addRemoteInput(RemoteInput)
→ PendingIntent(NotificationReplyReceiver)
→ RemoteInput.getResultsFromIntent(intent)
→ validate length/encoding
→ save AgentJob(NOTIFICATION_REPLY)
→ Worker
→ profile-specific LLM
→ Tool Call if needed
→ NotificationPlan new
→ update conversation + notification
```

الأزرار:

- Reply.
- `I'm busy now`.
- Snooze.
- Mark as read.

كل button له action ID وidempotency key.

## 13. FCM والرسائل التي يبدأها الخادم

### القاعدة

Alarm محلي يجعل التطبيق يبدأ الاتصال. أما AI backend الذي يريد إرسال رسالة عشوائية، فيحتاج Push.

```text
AI backend
→ FCM
→ FirebaseMessagingService
→ validate push signature/data
→ AgentJob(PUSH_EVENT)
→ Notification generation turn
→ NotificationPlan
→ Notification
```

لا تضع raw prompt كاملًا في push. أرسل event ID وjob ID وsigned metadata، ثم يسحب التطبيق التفاصيل المصرح بها أو يتصل بالـAPI.

## 14. الذاكرة والفهارس

### 14.1 MemorySummary

```text
summary
category
indexId
sectionId
sourceMessageId
sourceEntityIdsJson
confidence
importance
tags
persona
createdBy=AI_AGENT
createdAt
```

### 14.2 العزل

يجب اتخاذ قرار واضح:

- الذاكرة العامة للنظام shared حيث تكون حقيقة موضوعية.
- تفضيلات الشخصية/النبرة memory scoped إلى persona.
- ذاكرة المستخدم المشتركة لا تكرر بلا داعٍ بين REM/RAM.
- Job وconversation وnotification ترتبط بـpersona.
- لا تسمح لذاكرة شخصية أن تغير شخصية الأخرى إلا عبر shared user memory policy.

### 14.3 Indexes

- تبقى بالخلفية.
- يمكن أن تكون shared أو persona-scoped حسب `scope`.
- لا تنشئ index جديدًا لكل رسالة.
- deduplication key.
- retention/expiry للـobservations.
- source references لمنع الهلوسة.

## 15. توحيد الكود الحالي

### 15.1 `AutonomousAgentCoordinator`

يتحول إلى `AgentTurnCoordinator` أو facade عليه، مع الحفاظ على الوظيفة:

- لا يعتمد على regex كعقد نهائي.
- لا ينفذ confirmation UI.
- يستخدم profile الخاص بالـjob.
- يدخل Tool Registry.
- يكرر الدورة حسب stop conditions.
- ينتج final response أو NotificationPlan.

### 15.2 `AutonomousAgentProtocolEngine`

- يبقى مؤقتًا للـlegacy migration/tests.
- يضاف Structured Protocol.
- يمنع تسريب tags.
- deprecate text markers بعد نجاح structured tools.

### 15.3 `AiAutomationServiceImpl`

- لا يبقى Agent path موازيًا.
- يتحول إلى facade للـAgentRuntime أو تزال dependency بعد نقل وظائفه.
- يزال `generateLocalAssistantInsight` من المسار الأساسي.
- يزال fallback `10000`.

### 15.4 `AiHubViewModel`

- UI state/events فقط.
- `sendMessage` يضع Job.
- `executeTerminal` يبقى Developer/Admin فقط.
- لا يحمل memory/index data إلى UI العادي.
- reply/copy يستمران.

### 15.5 `AiHubScreen`

- Chat first.
- لا تعرض reasoning أو raw context.
- لا تحذف الإدارة؛ افصلها.
- Telegram interaction tests.

### 15.6 `LlmApiClient`

- request/response models typed.
- profile-aware key selection.
- no global `activePersona` lookup أثناء worker.
- separate failure/demotion per persona/key.
- model/provider per profile.

## 16. Room and data integrity

- إزالة `fallbackToDestructiveMigration()` من الإنتاج.
- migrations لكل version.
- foreign keys.
- indexes للرسائل `(conversationId, timestamp)`.
- unique `(persona, slotIndex)` للمفاتيح.
- unique idempotency key للـjobs/tool calls.
- transactions بين Job status وToolResult وmessage.
- لا تحفظ “SUCCESS” قبل تنفيذ فعلي.
- Interrupted jobs تظهر ولا تختفي.
- استعادة backup تعيد plans/jobs/profile metadata دون أسرار خام.
- أسرار API لا تدخل backup غير مشفر.

## 17. الأمان والتدقيق

- `AI_AGENT` actor صحيح.
- لكل ToolCall audit event.
- لكل notification generation correlation ID.
- لكل provider request profile/persona/model ID دون key.
- encrypted key storage.
- redaction في logs.
- لا raw secrets في crash reports.
- allowlist للtools.
- input limits.
- output limits.
- loop/deadline limits.
- kill switch لـautonomous runtime.
- profile disable منفصل لـREM/RAM.
- revoke جميع keys من settings.

## 18. UI وTelegram behavior

لا تُحذف الوظائف المرئية المتفق عليها:

- نسخ الرسالة.
- الرد على رسالة معينة.
- quote preview.
- الانتقال للرسالة الأصلية.
- الضغط المطول.
- selection.
- retry.
- stop/cancel.
- streaming إذا نفذ بطريقة صحيحة.
- Markdown.
- RTL.
- long message handling.
- error state.
- unread/read.
- conversations.
- persona switch.

الممنوع فقط أن تكشف الواجهة:

- reasoning.
- raw index.
- memory internals.
- private observations.
- sensitive audit payload.

## 19. الاختبارات Enterprise Grade

### 19.1 Compile/static

- unresolved references.
- missing composables.
- API signatures.
- duplicate services.
- unused path review.
- source diff against original.

### 19.2 Unit

- JSON schemas.
- provider adapters.
- tool registry.
- parser legacy migration.
- idempotency.
- memory classifier.
- NotificationPlan validator.
- REM/RAM key rotation.
- independent cooldown.
- persona routing.

### 19.3 Integration

- LLM fake provider returns final.
- LLM returns 5 sequential tools.
- malformed tool call.
- duplicate call.
- provider 401/403/429.
- one REM key fails and second succeeds.
- REM fails do not demote RAM.
- RAM job never uses REM key.
- conversation persona remains stable during worker.
- notification generation after tool result.

### 19.4 Room

- migrations.
- jobs.
- plans.
- schedules.
- profile/key uniqueness.
- message/reply relation.
- backup/restore.
- interrupted transaction.

### 19.5 Worker/Android

- Activity closes.
- process killed.
- device reboot.
- Doze.
- no network.
- network returns.
- exact alarm permission granted/denied.
- timezone changed.
- duplicate alarm.
- cancel before trigger.
- retry after crash.

### 19.6 Notification

- AI-generated body changes with context.
- no hard-coded primary notification text.
- Reply.
- `I'm busy now`.
- Snooze.
- Mark read.
- same conversation update.
- persona avatar/name correct.
- duplicate push dedupe.

### 19.7 Security

- secret redaction.
- key encryption.
- key revocation.
- unauthorized capability rejected internally.
- audit actor.
- prompt injection in memory treated as data.
- tool arguments constrained.

## 20. مراحل التنفيذ وGates

### Gate 0 — Inventory and preservation

- original archive unchanged.
- current manifest.
- file/declaration diff.
- no accidental deletion.

### Gate 1 — Build

```bash
./gradlew clean :app:compileDebugKotlin --no-daemon
```

### Gate 2 — Data

- migrations pass.
- no destructive migration.
- backup/restore pass.

### Gate 3 — Runtime

- job survives Activity close/process restart.

### Gate 4 — Tools

- real structured tools pass.
- tool result returns to LLM.

### Gate 5 — REM/RAM

- 3+3 slots.
- independent failover.
- profile-specific model/provider.
- correct routing.

### Gate 6 — Scheduling

- reminder triggers closed app.
- reboot recovery.

### Gate 7 — Notifications

- LLM-generated NotificationPlan.
- RemoteInput reply.
- Busy/snooze.

### Gate 8 — Plans

- multi-step follow-up.
- pause/resume.
- success/failure criteria.

### Gate 9 — Release

```bash
./gradlew clean testDebugUnitTest --no-daemon
./gradlew :app:connectedDebugAndroidTest --no-daemon
./gradlew :app:assembleDebug --no-daemon
./gradlew :app:assembleRelease --no-daemon
```

## 21. معايير قبول غير قابلة للتفاوض

```text
[ ] لا وظائف أصلية حُذفت دون قرار موثق
[ ] لا ملف مصدر اختفى مقارنة بالأصل دون سبب
[ ] لا Stub أو return success فارغ
[ ] البناء النظيف ينجح
[ ] كل خدمة مرجعية لها تعريف وتنفيذ حقيقي
[ ] Room migrations حقيقية
[ ] لا destructive migration
[ ] AgentRuntime يعمل خارج Activity
[ ] Job يستمر بعد إغلاق التطبيق
[ ] Tool Calling منظم وليس Regex فقط
[ ] Tool results تعود إلى LLM
[ ] Loop متعددة الخطوات تعمل
[ ] لا confirmation لكل Tool Call
[ ] validation/idempotency/audit موجودة
[ ] الذاكرة والفهارس غير ظاهرة في UI العادي
[ ] MemorySummary من API يخزن داخليًا
[ ] الإشعار يطلب من LLM تحديد محتواه
[ ] NotificationPublisher لا يستخدم نصًا ثابتًا للمسار الأساسي
[ ] Reply من الإشعار يصل إلى LLM
[ ] I'm busy now يصل كحدث حقيقي
[ ] Snooze يعيد الجدولة فعليًا
[ ] التطبيق المغلق ينفذ الموعد
[ ] reboot يعيد جدولة المواعيد
[ ] exact alarm denial له fallback
[ ] FCM يعمل إذا كان نمط cloud push مفعّلًا
[ ] REM لها 3 مفاتيح مستقلة
[ ] RAM لها 3 مفاتيح مستقلة
[ ] فشل REM لا يغير RAM
[ ] Worker يختار profile المحفوظ في Job
[ ] لا مفاتيح في logs/APK/backup غير المشفر
[ ] كل فشل يظهر كفشل حقيقي
[ ] اختبارات UI وWorker وRoom وLLM تمر
```

## 22. النص الذي يُرسل للمبرمج

> المطلوب تنفيذ وثيقة Enterprise Grade لمشروع Always Busy Life OS كما هي، وليس اختصارها إلى تعديل واجهة أو Prompt. حافظ على كل وظائف المشروع الأصلية: المهام، المشاريع، القوالب، الحقول المخصصة، الملاحظات، الأهداف، الوقت، التقويم، المالية، الديون، المحادثات، النسخ، الذاكرة، الفهارس، Scopes/Audit، Copy/Reply وواجهات REM/RAM. ممنوع حذف أي وظيفة أو إنشاء Stub؛ أي عنصر مفقود يجب تنفيذه فعليًا أو فصل مستدعيه مع قرار diff موثق. المطلوب بناء AgentRuntime وAgentJobQueue وPersistent Worker، ثم Real Tool Calling باستخدام tools/tool_choice/tool_call_id/tool results ودورة متعددة الخطوات، مع AgentToolRegistry وtyped AppInternalGateway وidempotency وAI_AGENT audit. الذاكرة والفهارس وreasoning وobservations تبقى خلفية ولا تظهر للمستخدم العادي. الذاكرة الأساسية يجب أن تعود كـMemorySummary من LLM، ثم يتحقق التطبيق منها ويصنفها ويخزنها داخليًا دون confirmation UI. الوكيل يملك FULL_AUTONOMOUS profile ولا نطلب Dialog لكل Tool Call، لكن نحتفظ بالتحقق الداخلي والlimits والمعاملات ومنع التكرار والـdead-letter. عند إنشاء تذكير، يستدعي LLM create_scheduled_agent_task؛ عند الموعد يعمل AlarmManager/WorkManager حتى إن كان التطبيق مغلقًا، ثم يرسل التطبيق طلبًا جديدًا إلى LLM مع السياق، والـLLM هو الذي يقرر هل يرسل إشعارًا ومحتواه وعنوانه ونبرته وأفعاله ويعيد NotificationPlan. لا تضع نصوصًا ثابتة للمسار الأساسي داخل NotificationPublisher. Reply من الإشعار يستخدم RemoteInput ويصبح AgentJob جديدًا يعود إلى LLM. `I'm busy now` وSnooze وMark as read أحداث حقيقية تعيد الخطة أو موعدها عبر LLM. أضف Hybrid FCM إذا كان الخادم سيبدأ رسائل خارج المواعيد المحلية. أضف عزلًا حقيقيًا بين REM وRAM: 3 مفاتيح مستقلة لـREM و3 مفاتيح مستقلة لـRAM، provider/baseUrl/model وfailover/cooldown لكل profile، وفشل مفاتيح شخصية لا يؤثر على الأخرى، وJob يحتفظ بشخصيته ولا يستخدم activePersona العالمية أثناء التنفيذ. خزّن المفاتيح مشفرة ولا تسجلها. نفذ المراحل بالترتيب: inventory/preservation، compile blockers، Room/migrations، Agent Runtime، Real Tool Calling، Full Gateway، REM/RAM profiles، scheduling، AI-generated notifications، reply/push، multi-step plans، private memory، ثم الاختبارات والإطلاق. لا تعلن الجاهزية قبل clean compile وunit/instrumentation/release واختبارات التطبيق مغلقًا، reboot، Doze، Reply، Busy، Snooze، فشل الشبكة، duplicate tool call، فشل REM/RAM المستقل، واستعادة البيانات.

## 23. الحكم النهائي

الخطة السابقة كانت صحيحة لكنها مختصرة بالنسبة لمستوى Enterprise الذي تريده. هذه الوثيقة توسعها دون حذف جوهر المشروع، وتضيف صراحة:

- تدقيق آخر المتطلبات.
- سياسة عدم حذف الوظائف.
- فصل الخلفية عن UI.
- إشعار يولده الذكاء لحظة الحدث.
- Tool Calling متعدد الخطوات.
- Agent Runtime.
- جدولة قابلة للاستئناف.
- Reply من Notification.
- خطط متابعة.
- FCM.
- 3 مفاتيح REM + 3 مفاتيح RAM.
- عزل كامل للشخصيات والمفاتيح والـJobs.
- معايير اختبار وقبول Enterprise Grade.

لا تبدأ التنفيذ من الواجهة. ابدأ بـGate 0 ثم Gate 1، ولا تنتقل إلى الذكاء قبل أن يمر البناء وتثبت المحافظة على كل وظائف الأصل.
